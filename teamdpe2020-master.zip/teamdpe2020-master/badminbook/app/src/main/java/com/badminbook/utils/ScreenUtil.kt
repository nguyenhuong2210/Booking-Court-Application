package com.badminbook.utils

import android.app.Activity
import android.content.Context
import android.util.DisplayMetrics
import android.view.WindowManager

class ScreenUtil {

    companion object {
        fun getWidthScreen(context: Context): Int {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val dimension = DisplayMetrics()
            wm.defaultDisplay?.getMetrics(dimension)
            return dimension.widthPixels
        }

        fun getHeightScreen(context: Context): Int {
            val wm = context
                .getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val dimension = DisplayMetrics()
            wm.defaultDisplay?.getMetrics(dimension)
            return dimension.heightPixels
        }

        /**
         * Disable touch screen
         */
        fun disableTouchOnScreen(activity: Activity?, isDisable: Boolean) {
            if (activity == null) {
                return
            }
            if (isDisable) {
                activity.window.setFlags(
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                )
            } else {
                activity.window.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
            }
        }
    }
}
