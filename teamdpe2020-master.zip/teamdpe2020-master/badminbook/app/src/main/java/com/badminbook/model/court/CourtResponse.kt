package com.badminbook.model.court

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class CourtResponse(
    @SerializedName("ResultCode")
    val code: Int,
    @SerializedName("CurrentCourts")
    val courts: List<Court>
) : Parcelable
