package com.badminbook.model.center

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class CurrentCourtResponse(
    @SerializedName("ResultCode")
    val code: Int,
    @SerializedName("CurrentCenters")
    val currentCenters: List<CurrentCenter>
) : Parcelable
