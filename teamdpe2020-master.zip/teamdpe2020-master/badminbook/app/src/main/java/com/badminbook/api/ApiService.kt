package com.badminbook.api

import com.badminbook.model.booked.BookedRequest
import com.badminbook.model.booked.BookingResponse
import com.badminbook.model.center.CenterRequest
import com.badminbook.model.center.CurrentCourtResponse
import com.badminbook.model.city.CityRequest
import com.badminbook.model.city.CityResponse
import com.badminbook.model.court.CancelCourtRequest
import com.badminbook.model.court.CourtRequest
import com.badminbook.model.court.CourtResponse
import com.badminbook.model.slot.SlotRequest
import com.badminbook.model.slot.FreeSlotResponse
import retrofit2.Call
import retrofit2.http.*

interface ApiService {

    @GET("/api/users/getallcity")
    fun getCities(): Call<CityResponse>

    @POST("/api/users/getallcenterincity")
    fun getSportCenter(@Body cityRequest: CityRequest): Call<CurrentCourtResponse>

    @POST("/api/users/getallcourtincenter")
    fun getCourtInCenter(@Body centerRequest: CenterRequest): Call<CourtResponse>

    @POST("/api/users/getavalableslot")
    fun getAvailableSlot(@Body slotRequest: SlotRequest) : Call<FreeSlotResponse>

    @POST("/api/users/createbooking")
    fun bookCourt(@Body courtRequest: CourtRequest): Call<Void>

    @POST("/api/users/cancelbooking")
    fun cancelBooking(@Body courtCancel: CancelCourtRequest) : Call<Void>

    @POST("/api/users/getcourtbooking")
    fun getCourtBooking(@Body bookedRequest: BookedRequest) : Call<BookingResponse>
}
