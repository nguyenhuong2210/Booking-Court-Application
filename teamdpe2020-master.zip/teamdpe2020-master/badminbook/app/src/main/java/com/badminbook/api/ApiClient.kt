package com.badminbook.api

import com.google.gson.FieldNamingPolicy
import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class ApiClient private constructor() {

    private object Holder {
        val INSTANCE = ApiClient()
    }

    companion object {
        private const val CONNECT_TIMEOUT_MILLS = 1000L * 90

        @JvmStatic
        fun getInstance(): ApiClient {
            return Holder.INSTANCE
        }
    }

    private var api: ApiService? = null
    var retrofit: Retrofit? = null

    init {
        retrofit = Retrofit.Builder()
            .baseUrl("http://103.90.227.107:8001")
            .addConverterFactory(
                GsonConverterFactory.create(
                    GsonBuilder()
                        .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES)
                        .create()
                )
            )
            .client(getOkHttpClientBuilder()!!.build())
            .build()
        api = retrofit?.create(ApiService::class.java)
    }

    fun getApiService(): ApiService? {
        return api
    }

    private fun getOkHttpClientBuilder(): OkHttpClient.Builder? {
        val okHttpClientBuilder: OkHttpClient.Builder = OkHttpClient.Builder()
            .connectTimeout(CONNECT_TIMEOUT_MILLS, TimeUnit.MILLISECONDS)
            .readTimeout(CONNECT_TIMEOUT_MILLS, TimeUnit.MILLISECONDS)
            .writeTimeout(CONNECT_TIMEOUT_MILLS, TimeUnit.MILLISECONDS)
        okHttpClientBuilder.addInterceptor(HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
        return okHttpClientBuilder
    }

    /*private fun createAuthorizationInterceptor(): Interceptor {
        return Interceptor { chain -> // Customize request header, add access token to request.
            val original = chain.request()
            val requestBuilder =
                original.newBuilder().method(original.method(), original.body())
            // Checking access token before request.
            if (!TextUtils.isEmpty(accessToken)) {
                requestBuilder.header("Authorization", "Bearer $accessToken")
            }
            requestBuilder.header("app-version", "VERSION_NAME")
            requestBuilder.header("PLATFORM", "Android")
            val request = requestBuilder.build()
            val response = chain.proceed(request)
            when(response.code()) {
                HttpURLConnection.HTTP_BAD_REQUEST ,
                HttpURLConnection.HTTP_UNAUTHORIZED,
                HttpURLConnection.HTTP_NOT_FOUND -> {
                    Log.d(TAG, "OkHttpClient.Builder intercept() -> Error code: " + response.code())
                }
            }
            response
        }
    }*/
}
