package com.badminbook.model.city

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

/**
 * Data of list city.
 */
@Parcelize
data class City(
    @SerializedName("CityID")
    val id: Int,
    @SerializedName("CityName")
    val name: String?,
    var selected: Boolean
) : Parcelable
