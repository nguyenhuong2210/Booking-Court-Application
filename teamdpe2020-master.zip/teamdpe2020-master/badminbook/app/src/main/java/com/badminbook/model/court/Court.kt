package com.badminbook.model.court

import android.os.Parcelable
import com.badminbook.model.center.CurrentCenter
import com.badminbook.model.slot.FreeSlot
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

/**
 * Data of list city.
 */
@Parcelize
data class Court(
    @SerializedName("CourtID")
    val id: Int,
    @SerializedName("CourtName")
    val name: String?,
    var sportCenter: CurrentCenter,
    var availableTimes: List<FreeSlot>?
) : Parcelable
