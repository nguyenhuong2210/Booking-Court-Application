package com.badminbook.ui.time

import android.annotation.SuppressLint
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.badminbook.R
import com.badminbook.api.ApiClient
import com.badminbook.config.ConfigureKey
import com.badminbook.model.court.Court
import com.badminbook.model.court.CourtRequest
import com.badminbook.ui.home.HomeActivity
import com.badminbook.utils.TimeUtil
import kotlinx.android.synthetic.main.fragment_time.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

/**
 * Show list courts available
 */
class TimeFragment : Fragment() {

    private var date: String? = null
    private var court: Court? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_time, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        getData()
        setEvents()
    }

    private fun getData() {
        date = arguments?.getString(ConfigureKey.DATE_KEY)
        court = arguments?.getParcelable(ConfigureKey.COURT_KEY)
        court?.let {
            tvCourtName.text = it.name
            tvSportCenterName.text = it.sportCenter.name
        }
    }

    private fun setEvents() {
        tvStartTime.setOnClickListener {
            selectTime(tvStartTime, false)
        }

        tvEndTime.setOnClickListener {
            selectTime(tvEndTime, true)
        }

        btnBookTime.setOnClickListener {
            val bookCourt = CourtRequest(
                TimeUtil.getTimeDisplay(
                    date,
                    TimeUtil.FormatType.TYPE_3.value,
                    TimeUtil.FormatType.TYPE_1.value
                ),
                tvStartTime.text.toString().plus(":00"),
                tvEndTime.text.toString().plus(":00"),
                court?.id,
                "Player2" // default player
            )

            (activity as HomeActivity).showProgressBar(true)
            ApiClient.getInstance()
                .getApiService()
                ?.bookCourt(bookCourt)
                ?.enqueue(object : Callback<Void> {
                    override fun onFailure(call: Call<Void>, t: Throwable) {
                        Toast.makeText(activity, "${t.message}", Toast.LENGTH_SHORT).show()
                        (activity as HomeActivity).showProgressBar(false)
                    }

                    override fun onResponse(call: Call<Void>, response: Response<Void>) {
                        (activity as HomeActivity).clearBackStack()
                        (activity as HomeActivity).showProgressBar(false)
                    }
                })

        }
    }

    private fun selectTime(timeView: TextView, isTimeEnd: Boolean) {
        val times = timeView.text.toString().split(":")
        if (times.size > 1) {
            val hour = times[0].toInt()
            val minute = times[1].toInt()
            showTimer(timeView, hour, minute, isTimeEnd)
        }
    }

    @SuppressLint("SetTextI18n")
    private fun showTimer(timeView: TextView, _hour: Int, _minute: Int, isTimeEnd: Boolean) {
        val timeSetListener = TimePickerDialog.OnTimeSetListener { _, hour, minute ->
            val h = if (hour < 10) "0${hour}" else hour.toString()
            val m = if (minute < 10) "0${minute}" else minute.toString()
            if (isTimeEnd) {
                val startTimes = tvStartTime.text.toString().split(":")
                if (startTimes.size > 1) {
                    val sHour: Int = startTimes[0].toInt()
                    val sMinute = startTimes[1].toInt()
                    if (compareValues(sHour, hour) > 0
                        || (compareValues(sHour, hour) == 0 && compareValues(sMinute, minute) > 0)
                    ) {
                        Toast.makeText(activity, "Select time again", Toast.LENGTH_SHORT).show()
                        btnBookTime.isEnabled = !isInValidRangeTime()
                        return@OnTimeSetListener
                    }
                }
            }
            timeView.text = "${h}:${m}"
            btnBookTime.isEnabled = !isInValidRangeTime()
        }
        TimePickerDialog(
            activity,
            timeSetListener,
            _hour,
            _minute,
            true
        ).show()
    }

    private fun isInValidRangeTime(): Boolean {
        val startTimes = tvStartTime.text.toString().split(":")
        val endTimes = tvEndTime.text.toString().split(":")
        if (startTimes.size > 1 && endTimes.size > 1) {
            val sHour: Int = startTimes[0].toInt()
            val sMinute = startTimes[1].toInt()
            val eHour: Int = endTimes[0].toInt()
            val eMinute = endTimes[1].toInt()
            return (compareValues(sHour, eHour) > 0
                    || (compareValues(sHour, eHour) == 0 && compareValues(sMinute, eMinute) > 0))
        }
        return true
    }
}
