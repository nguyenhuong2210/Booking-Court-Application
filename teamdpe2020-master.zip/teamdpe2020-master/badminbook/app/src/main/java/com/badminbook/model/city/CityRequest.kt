package com.badminbook.model.city

import com.google.gson.annotations.SerializedName

data class CityRequest(
    @SerializedName("CityID")
    val cityId: Int?
)
