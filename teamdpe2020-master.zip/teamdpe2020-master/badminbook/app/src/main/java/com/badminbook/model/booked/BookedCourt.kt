package com.badminbook.model.booked

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

/**
 * Data of list city.
 */
@Parcelize
data class BookedCourt(
    @SerializedName("CourtID")
    val id: Int,
    @SerializedName("CourtName")
    val name: String?,
    @SerializedName("BookingID")
    val bookingId: Int,
    @SerializedName("PlayerID")
    val playerId: String,
    var sportCenter: String?
) : Parcelable
