package com.badminbook.model.city

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class CityResponse(
    @SerializedName("ResultCode")
    val code: Int,
    @SerializedName("CurrentCities")
    val cities: List<City>
) : Parcelable
