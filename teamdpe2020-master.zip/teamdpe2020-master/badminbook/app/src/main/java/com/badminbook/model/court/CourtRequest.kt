package com.badminbook.model.court

import com.google.gson.annotations.SerializedName

data class CourtRequest(
    @SerializedName("BookingDay")
    val bookingData: String?,
    @SerializedName("StartTime")
    val startTime: String?,
    @SerializedName("EndTime")
    val endTime: String?,
    @SerializedName("CourtID")
    val courtId: Int?,
    @SerializedName("PlayerID")
    val playerId: String?
)
