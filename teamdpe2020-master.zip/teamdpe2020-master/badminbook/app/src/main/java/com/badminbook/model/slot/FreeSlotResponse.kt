package com.badminbook.model.slot

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class FreeSlotResponse(
    @SerializedName("ResultCode")
    val code: Int,
    @SerializedName("CurrentFreeSlots")
    val slots: List<FreeSlot>
) : Parcelable
