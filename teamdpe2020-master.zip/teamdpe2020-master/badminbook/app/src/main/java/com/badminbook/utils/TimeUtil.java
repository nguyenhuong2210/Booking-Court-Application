package com.badminbook.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * @author dinhys
 */
public final class TimeUtil {

    public TimeUtil() {
        // no-op
    }

    public static String getDatetime(Calendar calendar, FormatType type) {
        try {
            SimpleDateFormat sdfJapan = new SimpleDateFormat(type.getValue(), Locale.ENGLISH);
            TimeZone tz = TimeZone.getTimeZone("Asia/Ho_Chi_Minh");
            sdfJapan.setTimeZone(tz);
            return sdfJapan.format(calendar.getTime());
        } catch (RuntimeException e) {
            return null;
        }
    }

    public static String getTimeDisplay(String date, String originFormat, String targetFormat) {
        SimpleDateFormat originDateFormat = new SimpleDateFormat(originFormat, Locale.ENGLISH);
        SimpleDateFormat targetDateFormat = new SimpleDateFormat(targetFormat, Locale.ENGLISH);
        try {
            Date originDate = originDateFormat.parse(date);
            String Result = targetDateFormat.format(originDate);
            System.out.println(Result);
            return Result;
        } catch (ParseException e) {
            return date;
        }
    }

    /**
     * This is define the format type of string date time.
     */
    public enum FormatType {
        TYPE_1("yyyy-MM-dd"),
        TYPE_2("yyyy/MM/dd"),
        TYPE_3("dd/MM/yyyy"),
        TYPE_4("dd MM yyyy"),
        TYPE_5("dd-MM-yyyy  hh:mm"),
        TYPE_6("dd MM yyyy  hh:mm"),
        TYPE_7("yyyy-MM-dd'T'HH:mm:ssZ"),
        TYPE_8("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"),
        TYPE_9("yyyy-MM-dd hh:mm:ss");

        final String value;

        FormatType(String val) {
            this.value = val;
        }

        public String getValue() {
            return this.value;
        }
    }
}
