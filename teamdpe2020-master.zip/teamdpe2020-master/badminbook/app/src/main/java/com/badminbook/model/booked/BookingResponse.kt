package com.badminbook.model.booked

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class BookingResponse(
    @SerializedName("ResultCode")
    val code: Int,
    @SerializedName("CurrentBookings")
    val bookedCourts: List<BookedCourt>
) : Parcelable
