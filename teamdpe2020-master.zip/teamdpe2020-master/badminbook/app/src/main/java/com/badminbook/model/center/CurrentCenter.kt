package com.badminbook.model.center

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class CurrentCenter(
    @SerializedName("CenterID")
    val id: Int,
    @SerializedName("CenterName")
    val name: String
) : Parcelable
