package com.badminbook.ui.court

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.badminbook.R
import com.badminbook.config.ConfigureKey
import com.badminbook.model.city.City
import com.badminbook.model.court.Court
import com.badminbook.ui.home.HomeActivity
import kotlinx.android.synthetic.main.fragment_court.*
import kotlinx.android.synthetic.main.fragment_time.*

/**
 * Show list courts available
 */
class CourtFragment : Fragment() {

    private var courts: MutableList<Court> = ArrayList()

    private var date: String? = null
    private var city: City? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_court, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        getData()

        initListCourts()
        getCourts()
    }

    private fun getData() {
        date = arguments?.getString(ConfigureKey.DATE_KEY)
        city = arguments?.getParcelable(ConfigureKey.CITY_KEY)
    }

    private fun initListCourts() {
        val courtAdapter = CourtAdapter(courts)
        courtAdapter.onItemClicked = this::handleItemClicked
        with(recyclerViewCourt) {
            layoutManager = LinearLayoutManager(context)
            addItemDecoration(CourtDecoration())
            adapter = courtAdapter
        }
    }

    private fun handleItemClicked(position: Int) {
        (activity as HomeActivity).showTimeScreen(courts[position], date)
    }

    private fun getCourts() {
        val courtList = arguments?.getParcelableArrayList<Court>(ConfigureKey.COURT_LIST_KEY)
        courtList?.let {
            courts.addAll(it)
        }
        recyclerViewCourt.adapter?.notifyDataSetChanged()
        updateUI()
    }

    private fun updateUI() {
        if (courts.isEmpty()) {
            tvEmpty.visibility = View.VISIBLE
            recyclerViewCourt.visibility = View.GONE
        } else {
            tvEmpty.visibility = View.GONE
            recyclerViewCourt.visibility = View.VISIBLE
        }
    }
}
