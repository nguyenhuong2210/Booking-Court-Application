package com.badminbook.model.slot

import com.google.gson.annotations.SerializedName

data class SlotRequest(
    @SerializedName("CenterID")
    val centerId: Int,
    @SerializedName("BookingDay")
    val bookingDay: String
)
