package com.badminbook.model.center

import com.google.gson.annotations.SerializedName

data class CenterRequest(
    @SerializedName("CenterID")
    val centerId: Int?
)
