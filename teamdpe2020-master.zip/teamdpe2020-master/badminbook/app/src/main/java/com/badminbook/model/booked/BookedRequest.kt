package com.badminbook.model.booked

import com.google.gson.annotations.SerializedName

data class BookedRequest(
    @SerializedName("CourtID")
    val courtId: Int,
    @SerializedName("BookingDay")
    val bookingDay: String
)
