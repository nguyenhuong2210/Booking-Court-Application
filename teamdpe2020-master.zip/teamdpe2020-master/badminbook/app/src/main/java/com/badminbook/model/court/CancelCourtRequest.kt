package com.badminbook.model.court

import com.google.gson.annotations.SerializedName

data class CancelCourtRequest(
    @SerializedName("BookingID")
    val bookingId: Int,
    @SerializedName("PlayerID")
    val playerId: String
)
