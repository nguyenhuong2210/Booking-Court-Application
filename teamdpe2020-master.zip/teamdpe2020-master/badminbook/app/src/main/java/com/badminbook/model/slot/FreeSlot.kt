package com.badminbook.model.slot

import android.os.Parcelable
import com.badminbook.model.center.CurrentCenter
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

/**
 * Data of list city.
 */
@Parcelize
data class FreeSlot(
    @SerializedName("CourtID")
    val id: Int,
    @SerializedName("StartTime")
    val startTime: String,
    @SerializedName("EndTime")
    var endTime: String
) : Parcelable
