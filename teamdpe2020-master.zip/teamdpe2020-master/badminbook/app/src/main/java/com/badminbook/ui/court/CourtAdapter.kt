package com.badminbook.ui.court

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.badminbook.R
import com.badminbook.model.court.Court
import com.badminbook.model.slot.FreeSlot
import kotlinx.android.synthetic.main.item_recycler_view_court.view.*

/**
 *  CityAdapter
 */
class CourtAdapter(private val courts: List<Court>?) :
    RecyclerView.Adapter<CourtAdapter.CourtViewHolder>() {

    internal var onItemClicked: (position: Int) -> Unit = {}

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): CourtViewHolder {
        return CourtViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.item_recycler_view_court, parent, false)
        )
    }

    override fun getItemCount(): Int = courts?.size ?: 0

    override fun onBindViewHolder(viewHolder: CourtViewHolder, position: Int) {
        viewHolder.onBindData(courts?.get(position))
    }

    /**
     * CourtViewHolder
     */
    inner class CourtViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        init {
            itemView.setOnClickListener { onItemClicked(adapterPosition) }
        }

        internal fun onBindData(court: Court?) {
            court?.let {
                itemView.tvCourtName.text = it.name
                itemView.tvSportCenterName.text = it.sportCenter.name
                it.availableTimes?.let { it1 ->
                    var timeAvailable = ""
                    for (time:FreeSlot in it1) {
                        timeAvailable = timeAvailable.plus("${time.startTime} ~ ${time.endTime}\n")
                    }
                    itemView.tvAvailableTime.text = timeAvailable
                }
            }
        }
    }
}
