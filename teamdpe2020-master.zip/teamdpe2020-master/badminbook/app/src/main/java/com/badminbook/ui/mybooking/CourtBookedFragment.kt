package com.badminbook.ui.mybooking

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.badminbook.R
import com.badminbook.api.ApiClient
import com.badminbook.model.booked.BookedCourt
import com.badminbook.model.booked.BookedRequest
import com.badminbook.model.booked.BookingResponse
import com.badminbook.model.court.CancelCourtRequest
import com.badminbook.ui.home.HomeActivity
import kotlinx.android.synthetic.main.fragment_court.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

/**
 * Show list courts available
 */
class CourtBookedFragment : Fragment() {

    private var bookedCourts: MutableList<BookedCourt> = ArrayList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_court, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initListCourts()
        getCourts()
    }

    private fun initListCourts() {
        val courtAdapter = CourtBookedAdapter(bookedCourts)
        courtAdapter.onItemClicked = this::handleCancelCourt
        with(recyclerViewCourt) {
            layoutManager = LinearLayoutManager(context)
            addItemDecoration(CourtBookedDecoration())
            adapter = courtAdapter
        }
    }

    private fun handleCancelCourt(position: Int) {
        (activity as HomeActivity).showProgressBar(true)
        ApiClient.getInstance()
            .getApiService()
            ?.cancelBooking(
                CancelCourtRequest(
                    bookedCourts[position].bookingId,
                    bookedCourts[position].playerId
                )
            )
            ?.enqueue(object : Callback<Void> {
                override fun onFailure(call: Call<Void>, t: Throwable) {
                    Toast.makeText(activity, "${t.message}", Toast.LENGTH_SHORT).show()
                    (activity as HomeActivity).showProgressBar(false)
                }

                override fun onResponse(call: Call<Void>, response: Response<Void>) {
                    bookedCourts.removeAt(position)
                    recyclerViewCourt.adapter?.notifyItemRemoved(position)
                    (activity as HomeActivity).showProgressBar(false)
                }
            })
    }

    private fun getCourts() {
        getBookedCourts()
    }

    private fun updateUI() {
        if (bookedCourts.isEmpty()) {
            tvEmpty.visibility = View.VISIBLE
            recyclerViewCourt.visibility = View.GONE
        } else {
            tvEmpty.visibility = View.GONE
            recyclerViewCourt.visibility = View.VISIBLE
        }
    }

    private fun getBookedCourts() {
        (activity as HomeActivity).showProgressBar(true)
        ApiClient.getInstance()
            .getApiService()
            ?.getCourtBooking(BookedRequest(1, "2020-05-05")) // don't know courtID
            ?.enqueue(object : Callback<BookingResponse> {
                override fun onFailure(call: Call<BookingResponse>, t: Throwable) {
                    Toast.makeText(activity, "${t.message}", Toast.LENGTH_SHORT).show()
                    (activity as HomeActivity).showProgressBar(false)
                }

                override fun onResponse(
                    call: Call<BookingResponse>,
                    response: Response<BookingResponse>
                ) {
                    if (response.isSuccessful) {
                        response.body()?.let {
                            bookedCourts.addAll(response.body()!!.bookedCourts)
                            recyclerViewCourt.adapter?.notifyDataSetChanged()
                            updateUI()
                        }
                    }
                    (activity as HomeActivity).showProgressBar(false)
                }
            })
    }
}
