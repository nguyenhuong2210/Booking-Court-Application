package com.badminbook.ui.home

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.badminbook.R
import com.badminbook.config.ConfigureKey.CITY_KEY
import com.badminbook.config.ConfigureKey.COURT_KEY
import com.badminbook.config.ConfigureKey.COURT_LIST_KEY
import com.badminbook.config.ConfigureKey.DATE_KEY
import com.badminbook.model.city.City
import com.badminbook.model.court.Court
import com.badminbook.ui.court.CourtFragment
import com.badminbook.ui.filter.FilterFragment
import com.badminbook.ui.mybooking.CourtBookedFragment
import com.badminbook.ui.time.TimeFragment
import com.badminbook.utils.ScreenUtil
import kotlinx.android.synthetic.main.activity_home.*
import java.util.ArrayList

/**
 * Home screen.
 */
class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        handleBackStackChange()
        addFragmentAvoidAnim(HomeFragment(), false)
        setEvents()
    }

    private fun setEvents() {
        imgBack.setOnClickListener {
            onBackPressed()
        }
    }

    private fun handleBackStackChange() {
        val fm = supportFragmentManager
        fm.addOnBackStackChangedListener {
            imgBack.visibility = if (fm.backStackEntryCount > 0) View.VISIBLE else View.GONE
            when (fm.findFragmentById(R.id.frContainer)) {
                is HomeFragment -> {
                    tvTitleCity.text = "Home Screen"
                }
                is FilterFragment -> {
                    tvTitleCity.text = "Filter Screen"
                }
                is CourtFragment -> {
                    tvTitleCity.text = "Court Screen"
                }
                is TimeFragment -> {
                    tvTitleCity.text = "Time Screen"
                }
                is CourtBookedFragment -> {
                    tvTitleCity.text = "My Booking"
                }
            }
        }
    }

    internal fun addFragment(fragment: Fragment, isAddToBackStack: Boolean) {
        val ft = supportFragmentManager.beginTransaction()
        ft.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left)
        ft.add(R.id.frContainer, fragment)
        if (isAddToBackStack) {
            ft.addToBackStack(fragment.javaClass.simpleName)
        }
        ft.commitAllowingStateLoss()
    }

    private fun addFragmentAvoidAnim(fragment: Fragment, isAddToBackStack: Boolean) {
        val ft = supportFragmentManager.beginTransaction()
        ft.add(R.id.frContainer, fragment)
        if (isAddToBackStack) {
            ft.addToBackStack(fragment.javaClass.simpleName)
        }
        ft.commitAllowingStateLoss()
    }

    internal fun showTimeScreen(court: Court, date: String?) {
        val bundle = Bundle()
        bundle.putParcelable(COURT_KEY, court)
        bundle.putString(DATE_KEY, date)
        val timeScreen = TimeFragment()
        timeScreen.arguments = bundle
        addFragment(timeScreen, true)
    }

    internal fun showCourtScreen(date: String, city: City?, courts: ArrayList<Court>?) {
        val bundle = Bundle()
        bundle.putString(DATE_KEY, date)
        bundle.putParcelable(CITY_KEY, city)
        bundle.putParcelableArrayList(COURT_LIST_KEY, courts)
        val courtScreen = CourtFragment()
        courtScreen.arguments = bundle
        addFragment(courtScreen, true)
    }

    internal fun showProgressBar(isShow: Boolean) {
        ScreenUtil.disableTouchOnScreen(this, isShow)
        if (progressBar != null) {
            progressBar.visibility = if (isShow) View.VISIBLE else View.GONE
        }
    }

    internal fun clearBackStack() {
        val fm = supportFragmentManager
        for (i in 0 until fm.backStackEntryCount) {
            fm.popBackStack()
        }
    }
}
