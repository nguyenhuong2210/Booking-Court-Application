package com.badminbook.ui.filter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.badminbook.R
import com.badminbook.model.city.City

/**
 *  CityAdapter
 */
class FilterCityAdapter(context: Context, private val cities: List<City>?) :
    BaseAdapter() {

    private var inflter: LayoutInflater = LayoutInflater.from(context)

    override fun getCount(): Int {
        return cities?.size ?: 0
    }

    override fun getItem(i: Int): Any? {
        return null
    }

    override fun getItemId(i: Int): Long {
        return 0
    }

    override fun getView(i: Int, view: View?, viewGroup: ViewGroup): View {
        val myView = inflter.inflate(R.layout.item_view_city, viewGroup, false)
        val tvCity = myView.findViewById<View>(R.id.tvCity) as TextView?
        tvCity?.text = cities?.get(i)?.name
        return myView
    }
}
