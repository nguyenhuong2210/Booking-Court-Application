package com.badminbook.ui.filter

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.badminbook.R
import com.badminbook.api.ApiClient
import com.badminbook.model.center.CenterRequest
import com.badminbook.model.center.CurrentCenter
import com.badminbook.model.center.CurrentCourtResponse
import com.badminbook.model.city.City
import com.badminbook.model.city.CityRequest
import com.badminbook.model.city.CityResponse
import com.badminbook.model.court.Court
import com.badminbook.model.court.CourtResponse
import com.badminbook.model.slot.FreeSlotResponse
import com.badminbook.model.slot.SlotRequest
import com.badminbook.ui.home.HomeActivity
import com.badminbook.utils.TimeUtil
import kotlinx.android.synthetic.main.fragment_filter.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*
import kotlin.collections.ArrayList

/**
 * Show list courts available
 */
class FilterFragment : Fragment() {

    private var cities: MutableList<City> = ArrayList()
    private val currentDate: Calendar = Calendar.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_filter, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        getCities()

        initViews()
        setEvents()
    }

    private fun initViews() {
        tvDate.text = getCurrentDate()
    }

    private fun setEvents() {
        tvDate.setOnClickListener {
            val datePicker = DatePickerDialog(
                activity as HomeActivity,
                DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
                    tvDate.text = dayOfMonth.toString()
                        .plus("/")
                        .plus(monthOfYear + 1)
                        .plus("/")
                        .plus(year)
                },
                currentDate.get(Calendar.YEAR),
                currentDate.get(Calendar.MONTH),
                currentDate.get(Calendar.DAY_OF_MONTH)
            )
            datePicker.show()
        }

        btnOk.setOnClickListener {
            // handle filter request
            getCenterInCity()
        }

        spinnerCity.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p0: AdapterView<*>?) {
                // avoid
            }

            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                if (cities.isNotEmpty()) {
                    for (city: City in cities) {
                        city.selected = false
                    }
                    cities[position].selected = true
                }
            }
        }
    }

    private fun getCitySelected(): City? {
        for (city: City in cities) {
            if (city.selected) {
                return city
            }
        }
        return null
    }

    private fun getCurrentDate() =
        TimeUtil.getDatetime(currentDate, TimeUtil.FormatType.TYPE_3)

    /**
     * Request list city
     */
    private fun getCities() {
        (activity as HomeActivity).showProgressBar(true)
        ApiClient.getInstance()
            .getApiService()
            ?.getCities()
            ?.enqueue(object : Callback<CityResponse> {
                override fun onFailure(call: Call<CityResponse>, t: Throwable) {
                    Toast.makeText(activity, "${t.message}", Toast.LENGTH_SHORT).show()
                    (activity as HomeActivity).showProgressBar(false)
                }

                override fun onResponse(
                    call: Call<CityResponse>,
                    response: Response<CityResponse>
                ) {
                    if (response.isSuccessful) {
                        response.body()?.let {
                            response.body()!!.cities.let {
                                cities.addAll(it)
                                // add spinner
                                activity?.let {
                                    val cityAdapter = FilterCityAdapter(
                                        activity as HomeActivity,
                                        cities
                                    )
                                    spinnerCity.adapter = cityAdapter
                                }
                            }
                        }
                    }
                    (activity as HomeActivity).showProgressBar(false)
                }
            })
    }

    private fun getCenterInCity() {
        val city = getCitySelected()
        city?.let {
            (activity as HomeActivity).showProgressBar(true)
            ApiClient.getInstance()
                .getApiService()
                ?.getSportCenter(CityRequest(it.id))
                ?.enqueue(object : Callback<CurrentCourtResponse> {
                    override fun onFailure(call: Call<CurrentCourtResponse>, t: Throwable) {
                        Toast.makeText(activity, "${t.message}", Toast.LENGTH_SHORT).show()
                        (activity as HomeActivity).showProgressBar(false)
                    }

                    override fun onResponse(
                        call: Call<CurrentCourtResponse>,
                        response: Response<CurrentCourtResponse>
                    ) {
                        if (response.isSuccessful) {
                            response.body()?.let {
                                getCourtInCenter(city, ArrayList(response.body()!!.currentCenters))
                            }
                        }
                    }
                })
        }
    }

    private fun getCourtInCenter(city: City, centers: List<CurrentCenter>) {
        centers.let {
            if (it.isNotEmpty()) {
                ApiClient.getInstance()
                    .getApiService()
                    ?.getCourtInCenter(CenterRequest(it[0].id)) // update later
                    ?.enqueue(object : Callback<CourtResponse> {
                        override fun onFailure(call: Call<CourtResponse>, t: Throwable) {
                            Toast.makeText(activity, "${t.message}", Toast.LENGTH_SHORT).show()
                            (activity as HomeActivity).showProgressBar(false)
                        }

                        override fun onResponse(
                            call: Call<CourtResponse>,
                            response: Response<CourtResponse>
                        ) {
                            if (response.isSuccessful) {
                                response.body()?.let {
                                    val courts = ArrayList<Court>(response.body()!!.courts)
                                    courts.let {
                                        if (courts.isNotEmpty()) {
                                            for (courtItem: Court in courts) {
                                                courtItem.sportCenter = centers[0]
                                            }
                                        }
                                    }
                                    if (courts.isEmpty()) {
                                        (activity as HomeActivity).showCourtScreen(
                                            tvDate.text.toString(),
                                            city,
                                            courts
                                        )
                                    } else {
                                        getFreeSlot(centers[0].id, courts, city)
                                    }
                                }
                            }
                        }
                    })
            }
        }
    }

    private fun getFreeSlot(centerId: Int, courts: ArrayList<Court>, city: City) {
        ApiClient.getInstance()
            .getApiService()
            ?.getAvailableSlot(
                SlotRequest(
                    centerId,
                    TimeUtil.getTimeDisplay(
                        tvDate.text.toString(),
                        TimeUtil.FormatType.TYPE_3.value,
                        TimeUtil.FormatType.TYPE_1.value
                    )
                )
            )
            ?.enqueue(object : Callback<FreeSlotResponse> {
                override fun onFailure(call: Call<FreeSlotResponse>, t: Throwable) {
                    Toast.makeText(activity, "${t.message}", Toast.LENGTH_SHORT).show()
                    (activity as HomeActivity).showProgressBar(false)
                }

                override fun onResponse(
                    call: Call<FreeSlotResponse>,
                    response: Response<FreeSlotResponse>
                ) {
                    if (response.isSuccessful) {
                        response.body()?.let {
                            val availableSlot = ArrayList(response.body()!!.slots)
                            for (courtItem: Court in courts) {
                                courtItem.availableTimes = availableSlot
                            }
                        }
                        (activity as HomeActivity).showCourtScreen(
                            tvDate.text.toString(),
                            city,
                            courts
                        )
                    }
                    (activity as HomeActivity).showProgressBar(false)
                }
            })
    }
}
