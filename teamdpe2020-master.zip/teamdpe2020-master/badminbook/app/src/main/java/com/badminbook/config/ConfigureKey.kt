package com.badminbook.config

object ConfigureKey {
    const val COURT_KEY = "COURT_KEY"
    const val DATE_KEY = "DATE_KEY"
    const val CITY_KEY = "CITY_KEY"
    const val COURT_LIST_KEY = "COURT_LIST_KEY"
}
