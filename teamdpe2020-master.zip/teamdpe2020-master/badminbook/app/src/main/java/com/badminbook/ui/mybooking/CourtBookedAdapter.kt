package com.badminbook.ui.mybooking

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.badminbook.R
import com.badminbook.model.booked.BookedCourt
import com.badminbook.model.court.Court
import kotlinx.android.synthetic.main.item_recycler_view_court.view.tvCourtName
import kotlinx.android.synthetic.main.item_recycler_view_court.view.tvSportCenterName
import kotlinx.android.synthetic.main.item_recycler_view_court_booked.view.*

/**
 *  CityAdapter
 */
class CourtBookedAdapter(private val courts: List<BookedCourt>?) :
    RecyclerView.Adapter<CourtBookedAdapter.CourtBookedViewHolder>() {

    internal var onItemClicked: (position: Int) -> Unit = {}

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): CourtBookedViewHolder {
        return CourtBookedViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.item_recycler_view_court_booked, parent, false)
        )
    }

    override fun getItemCount(): Int = courts?.size ?: 0

    override fun onBindViewHolder(viewHolder: CourtBookedViewHolder, position: Int) {
        viewHolder.onBindData(courts?.get(position))
    }

    /**
     * CourtViewHolder
     */
    inner class CourtBookedViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        init {
            itemView.btnCancel.setOnClickListener { onItemClicked(adapterPosition) }
        }

        internal fun onBindData(court: BookedCourt?) {
            court?.let {
                itemView.tvCourtName.text = it.name
                itemView.tvSportCenterName.text = it.sportCenter
            }
        }
    }
}
