package Struct;

public class City {
    public int CityID;
    public String CityName;
}
