package Struct;

public class Center {
    public int CenterID;
    public String CenterName;
}
