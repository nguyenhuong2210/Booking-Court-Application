package Struct;

public class Court {
    public int CourtID;
    public String CourtName;
}
