package Server.API;

public class Constants {
    public static final String ContentType = "Content-Type";
    public static final String ApplicationJSON = "application/json";
}
