package Server.API.Users.Response;

public class CreateCityCenterResponse {
    public CreateCityCenterResponse(int ResultCode) { this.ResultCode = ResultCode; }
    public int ResultCode;
    public int CenterID;
}
