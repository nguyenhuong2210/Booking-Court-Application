package Server.API.Users.Response;

public class CreatePlayerResponse {
    public CreatePlayerResponse(int ResultCode) { this.ResultCode = ResultCode; }
    public int ResultCode;
}
