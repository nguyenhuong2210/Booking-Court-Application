package Server.API.Users.Response;

public class CancelBookingResponse {
    public CancelBookingResponse(int ResultCode) { this.ResultCode = ResultCode; }
    public int ResultCode;
}
