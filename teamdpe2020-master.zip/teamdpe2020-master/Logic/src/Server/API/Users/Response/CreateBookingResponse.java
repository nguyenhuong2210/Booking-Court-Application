package Server.API.Users.Response;

public class CreateBookingResponse {
    public CreateBookingResponse(int ResultCode) { this.ResultCode = ResultCode; }
    public int ResultCode;
    public int BookingID;
}
