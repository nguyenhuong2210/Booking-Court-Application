package Server.API.Users.Response;

public class CreateCityCenterCourtResponse {
    public CreateCityCenterCourtResponse(int ResultCode) { this.ResultCode = ResultCode; }
    public int ResultCode;
    public int CourtID;
}
