package Server.API.Users.Response;

public class CreateCityResponse {
    public CreateCityResponse(int ResultCode) { this.ResultCode = ResultCode; }
    public int ResultCode;
    public int CityID;
}
