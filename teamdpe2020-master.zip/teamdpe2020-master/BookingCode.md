# Day 11

###  Team D

### Solution for Problem 1:
* __The Logic-Tier will encrypt the BookingID + PlayerID + TimeStamp getting from the Database-Tier into the Booking Code.__
* __The Booking Code is brought to the Present-Tier and the Present-Tier will deliver it to the Player.__
* __When the Player want to confirm his booking, he will enter the Booking Code in the app or show it to the staff at the course.__
* __The Booking Code will be decrypted at the Logic-Tier in order to get the BookingID. With that BookingID, the information that linked with it will be withrawed from the Database.__
