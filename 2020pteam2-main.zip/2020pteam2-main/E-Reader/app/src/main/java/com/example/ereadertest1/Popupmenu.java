package com.example.ereadertest1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;

public class Popupmenu extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.popup_test);

    }
    public void showPopup(View v){
        PopupMenu popup = new PopupMenu(this, v);
        popup.setOnMenuItemClickListener(this);
        // for Custome menu
        //popup.getMenu().add(groupId, itemId, order, title);
        /*
        popupMenu.getMenu().add(1, R.id.slot1, 1, "slot1");
        popupMenu.getMenu().add(1,R.id.slot2,2,"slot2");
        popupMenu.getMenu().add(1,R.id.slot3,3,"slot3");
        popupMenu.show();*/
        //if have a list just use for loop to add
        popup.inflate((R.menu.menu));
        popup.show();
    }


    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()){
            case R.id.item1:
                Toast.makeText(this, "Clicked Item 1", Toast.LENGTH_SHORT).show();
                //TODO: Do something here
                return true;
            case  R.id.item2:
                Toast.makeText(this, "Clicked Item 2", Toast.LENGTH_SHORT).show();
                //TODO: Do something here
                return true;
            case  R.id.item3:
                Toast.makeText(this, "Clicked Item 3", Toast.LENGTH_SHORT).show();
                //TODO: Do something here
                return true;
            default:
                return false;
        }
    }
}


