package com.example.io_test1.CustomXMLParser.Tags;

import com.example.io_test1.CustomXMLParser.Tags.Tags.BoldTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BookTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BookmarkTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.ChapterTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.CompoundTagContent;
import com.example.io_test1.CustomXMLParser.Tags.Tags.FontTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.HighlightTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.ItalicTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.PagebreakTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTagContent;

public interface ITagVisitor<ReturnType> {
    ReturnType visit(ITagContent tagContent);

    ReturnType visitTag(CompoundTagContent tag);

    ReturnType visitTag(SimpleTagContent tag);

    ReturnType visitTag(SimpleTag tag);

    ReturnType visitTag(BookTag tag);

    ReturnType visitTag(ChapterTag tag);

    ReturnType visitTag(BoldTag tag);

    ReturnType visitTag(ItalicTag tag);

    ReturnType visitTag(HighlightTag tag);

    ReturnType visitTag(BookmarkTag tag);

    ReturnType visitTag(PagebreakTag tag);

    ReturnType visitTag(FontTag tag);
}
