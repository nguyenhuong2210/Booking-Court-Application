package com.example.io_test1.CustomXMLParser.Tags;

import com.example.io_test1.CustomXMLParser.CustomBookType.IBookElement;

import java.util.Iterator;

public interface ITagContent extends IBookElement {
    String getText();

    Iterator<ITagContent> getIterator();

    ITagContent getContent();

    <ReturnType> ReturnType accept(ITagVisitor<ReturnType> tagVisitor);
}
