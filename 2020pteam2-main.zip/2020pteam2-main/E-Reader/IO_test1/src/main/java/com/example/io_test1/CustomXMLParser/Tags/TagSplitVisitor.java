package com.example.io_test1.CustomXMLParser.Tags;

import com.example.io_test1.CustomXMLParser.Tags.Tags.BookmarkTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.CompoundTagContent;

import java.util.Iterator;

public class TagSplitVisitor extends TagVisitorBase {
    // Splits tags with multiple nested tags into separate tags
    // note: this may not arguably need to be a visitor at all
    // i.e: <b>text1 <i>text2</i> text3</b> -> <b>text1</b><b><i> text2</i></b><b> text3</b>

    @Override
    protected CompoundTagContent visitTagIterator(Iterator<ITagContent> iterator){
        CompoundTagContent result = new CompoundTagContent();
        for (; iterator.hasNext(); ) {
            ITagContent tagContent = iterator.next();

            if (tagContent == null){
                return null;
            }

            ITagContent t = visit(tagContent);
            if (t != null){
                result.add(t);
            }
        }
        return result;
    }

    @Override
    protected ITagContent visitChildTags(TagBase tag){
        CompoundTagContent result = new CompoundTagContent();
        for (Iterator<ITagContent> it = visitTagIterator(tag.getContent().getIterator()).getIterator(); it.hasNext(); ) {
            ITagContent tagContent = it.next();
            for (Iterator<ITagContent> iter = tagContent.getIterator(); iter.hasNext(); ) {
                ITagContent inner = iter.next();
                TagBase t = tag.shallowCopy();
                t.setContent(inner);
                result.add(t);
            }
        }

        if (result.getSize() == 1){
            return result.getContentAt(0);
        } else if (result.getSize() > 1) {
            return result;
        } else {
            return tag;
        }
    }

    @Override
    public ITagContent visitTag(BookmarkTag tag) {
        // This should never be split into multiple tags, resulting in multiple bookmarks
        return tag;
    }
}
