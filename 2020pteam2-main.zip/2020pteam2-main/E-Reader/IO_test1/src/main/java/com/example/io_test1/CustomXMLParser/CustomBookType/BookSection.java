package com.example.io_test1.CustomXMLParser.CustomBookType;

import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.StaticLayout;
import android.text.TextPaint;

import com.example.io_test1.CustomXMLParser.Tags.ITagContent;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BoldTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BookTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BookmarkTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.ChapterTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.CompoundTagContent;
import com.example.io_test1.CustomXMLParser.Tags.Tags.FontTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.HighlightTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.ItalicTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.PagebreakTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTagContent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

public class BookSection extends CompoundBookElement implements IBookElement, IBookVisitor<IBookElement> {
    protected CustomBook outerBook;
    protected BookSection parentSection;
    protected ArrayList<CustomBookLabel> bookmarks;
    protected ArrayList<CustomBookLabel> bookLabels;
    private SpannableStringBuilder remainingBuffer;
    private ArrayList<CustomBookLabel> nextAddBookLabels;
    private int currentIndex, addStart, addEnd;
    private CustomPage nextPage;
    private boolean stop;

    public BookSection(BookSection parent){
        this.parentSection = parent;
        this.bookmarks = new ArrayList<>();
        this.bookLabels = new ArrayList<>();
        this.remainingBuffer = new SpannableStringBuilder();

        this.nextAddBookLabels = new ArrayList<>();
    }

    @Override
    public void reload(){
        this.currentIndex = 0;
        this.addStart = 0;
        this.addEnd = 0;
        this.nextAddBookLabels.clear();
        this.remainingBuffer = new SpannableStringBuilder();
        this.stop = false;
        for (IBookElement e: this.elements) {
            e.reload();
        }
    }

    public void setParentSection(BookSection parent){
        this.parentSection = parent;
    }

    public void addBookmark(CustomBookLabel bookLabel){
        bookLabel.setParentSection(this);
        this.outerBook.addBookmark(bookLabel);
        this.bookmarks.add(bookLabel);
    }

    public void removeBookmark(CustomBookLabel bookLabel) {
        bookLabel.setParentSection(null);
        this.outerBook.removeBookmark(bookLabel);
        this.bookmarks.remove(bookLabel);
    }

    public void sortBookmark(){
        Collections.sort(this.bookmarks, new Comparator<CustomBookLabel>() {
            public int compare(CustomBookLabel label1, CustomBookLabel label2) {
                int start1 = label1.getTag().getRawContentStartIndex();
                int start2 = label2.getTag().getRawContentStartIndex();
                // Integer.compare() requires api 19
                return (start1>start2 ? 1 : (start1==start2 ? 0 : -1));
            }
        });
    }

    public void addBookLabel(CustomBookLabel bookLabel){
        this.outerBook.addBookLabel(bookLabel);
        this.bookLabels.add(bookLabel);
    }

    public boolean hasNext() {
        return (this.remainingBuffer.length() > 0 || this.currentIndex < this.elements.size());
    }

    public CustomPage next() {
        if (hasNext()){
            SpannableStringBuilder appendText = new SpannableStringBuilder();
            this.addStart = this.currentIndex;
            this.addEnd = 0;
            this.stop = false;

            if (this.remainingBuffer.length() > 0){
                if (fitPage(appendText)){
                    this.stop = true;
                }
                this.addStart -= 1;
            }

            while (this.currentIndex < this.elements.size() && !this.stop){
                IBookElement e = visit(this.elements.get(this.currentIndex));
                if (e != null){
                    this.remainingBuffer.append(e.getDisplayText());
                }
                this.currentIndex += 1;
                if (this.remainingBuffer.length() > 0){
                    if (fitPage(appendText)){
                        break;
                    }
                }
            }

            this.addEnd = Math.max(this.addStart, this.currentIndex - 1);

            if (appendText.length() > 0){
                this.nextPage = new CustomPage(this, this.addStart, this.addEnd);
                this.nextPage.setDisplayLength(appendText.length());
                this.nextPage.setExcessLength(this.remainingBuffer.length());
                this.nextPage.setDisplayText(appendText);

                for (CustomBookLabel next: this.nextAddBookLabels) {
                    next.setPage(this.nextPage);
                }
                this.nextAddBookLabels.clear();

            }

            return this.nextPage;
        } else {
            return null;
        }
    }

    private boolean fitPage(SpannableStringBuilder appendText){
        TextPaint textPaint = this.outerBook.textPaint;
        int pageWidth = this.outerBook.pageWidth;
        int pageHeight = this.outerBook.pageHeight;
        float spacingMul = this.outerBook.spacingMul;
        float spacingAdd = this.outerBook.spacingAdd;
        // hard coded margin to account for error
        // TODO: get rid of this, accept as input instead
        pageHeight -= 50;
        pageWidth -= 50;

        // there is a bug of not spanning tags correctly when buffer size is too small
        // caused by appending more subsequences after the first one
        // seems like every subsequences after the first one get casted to a normal string
        int charBufferSize = 4000;
        int addCount;
        boolean pageFull = false;
        CharSequence tempText;
        while (!pageFull){
            addCount = Math.min(this.remainingBuffer.length(), charBufferSize);
            tempText = this.remainingBuffer.subSequence(0, addCount);
            appendText.append(tempText);

            // ref:
            // https://stackoverflow.com/questions/7549182/android-paint-measuretext-vs-gettextbounds/7579469#7579469
            StaticLayout layout = new StaticLayout(
                    appendText,
                    textPaint,
                    pageWidth,
                    Layout.Alignment.ALIGN_NORMAL,
                    spacingMul,
                    spacingAdd,
                    true);
            if (layout.getLineBottom(layout.getLineCount() - 1) > pageHeight){
                int lastVisibleLine;
                int lastVisibleChar;
                for (lastVisibleLine = layout.getLineCount() - 1; lastVisibleLine >= 0; lastVisibleLine--){
                    if (layout.getLineBottom(lastVisibleLine) < pageHeight){
                        break;
                    }
                }
                lastVisibleChar = layout.getLineEnd(lastVisibleLine);
                addCount = Math.max(addCount - (appendText.length() - lastVisibleChar), 0);
                appendText.delete(lastVisibleChar, appendText.length());
                pageFull = true;
            }

            this.remainingBuffer.delete(0, addCount);

            if (this.remainingBuffer.length() == 0){
                break;
            }
        }
        return pageFull;
    }

    @Override
    public <ReturnType, VisitorType extends IBookVisitor<ReturnType>> ReturnType accept(VisitorType bookVisitor) {
        return bookVisitor.visitElement(this);
    }

    @Override
    public IBookElement visit(IBookElement element){
        return element.accept(this);
    }

    @Override
    public IBookElement visit(ITagContent tagContent) {
        return tagContent.accept(this);
    }

    //region Tag Visits
    private void visitChildrenTags(ITagContent tagContent){
        for (Iterator<ITagContent> it = tagContent.getContent().getIterator(); it.hasNext(); ) {
            ITagContent child = it.next();
            visit(child);
        }
    }

    @Override
    public ITagContent visitTag(CompoundTagContent tag){
        visitChildrenTags(tag);
        return tag;
    }

    @Override
    public ITagContent visitTag(SimpleTagContent tag){
        return tag;
    }

    @Override
    public ITagContent visitTag(SimpleTag tag){
        visitChildrenTags(tag);
        return tag;
    }

    @Override
    public ITagContent visitTag(BookTag tag){
        visitChildrenTags(tag);
        return tag;
    }

    @Override
    public ITagContent visitTag(ChapterTag tag){
        visitChildrenTags(tag);
        return tag;
    }

    @Override
    public ITagContent visitTag(BoldTag tag){
        visitChildrenTags(tag);
        return tag;
    }

    @Override
    public ITagContent visitTag(ItalicTag tag){
        visitChildrenTags(tag);
        return tag;
    }

    @Override
    public ITagContent visitTag(HighlightTag tag) {
        visitChildrenTags(tag);
        return tag;
    }

    @Override
    public ITagContent visitTag(BookmarkTag tag){
        if (tag.isDeleted) return tag;

        visitChildrenTags(tag);

        // pretty inefficient way of doing this but it should work fine
        // a better way would probably be making the BookLabel IBookElement themselves
        // so visiting it can just add itself
        for (CustomBookLabel label : this.bookmarks){
            if (label.getTag() == tag){
                this.nextAddBookLabels.add(label);
                break;
            }
        }

        return tag;
    }

    @Override
    public ITagContent visitTag(PagebreakTag tag) {
        this.stop = true;
        visitChildrenTags(tag);
        return tag;
    }

    @Override
    public IBookElement visitTag(FontTag tag) {
        return tag;
    }
    //endregion

    //region Element Visits
    @Override
    public IBookElement visitElement(BookSection bookSection) {
        this.stop = true;
        if (this.currentIndex == this.addStart) {
            this.nextPage = bookSection.next();
        }
        if (bookSection.hasNext()) {
            this.currentIndex -= 1;
        }
        return null;
    }

    @Override
    public IBookElement visitElement(BookChapter bookChapter) {
        this.stop = true;
        if (this.currentIndex == this.addStart) {
            this.nextPage = bookChapter.next();
        }
        if (bookChapter.hasNext()) {
            this.currentIndex -= 1;
        }
        return null;
    }

    @Override
    public IBookElement visitElement(CompoundBookElement bookElement) {
        return bookElement;
    }
    //endregion
}
