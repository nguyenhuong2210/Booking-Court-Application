package com.example.io_test1.CustomXMLParser.Tags;

import com.example.io_test1.CustomXMLParser.Tags.ITagContent;
import com.example.io_test1.CustomXMLParser.Tags.TagVisitorBase;
import com.example.io_test1.CustomXMLParser.Tags.Tags.CompoundTagContent;
import com.example.io_test1.CustomXMLParser.Tags.Tags.HighlightTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTagContent;

import java.util.Iterator;
import java.util.Stack;

public class TagHighlightVisitor extends TagVisitorBase {
    private boolean highlight, alwaysHighlight;
    private int highlightStart, highlightEnd;
    private Stack<Boolean> stack;

    public TagHighlightVisitor(){
        this.highlightStart = 0;
        this.highlightEnd = 0;
        this.stack = new Stack<>();
        this.alwaysHighlight = false;
    }

    public void setAlwaysHighlight(boolean alwaysHighlight) {
        this.alwaysHighlight = alwaysHighlight;
    }

    public void setHighlightStart(int highlightStart) {
        this.highlightStart = highlightStart;
    }

    public void setHighlightEnd(int highlightEnd) {
        this.highlightEnd = highlightEnd;
    }

    public ITagContent setHighlight(ITagContent tagContent, boolean highlight, int highlightStart, int highlightEnd) {
        this.highlight = highlight;
        this.stack.clear();
        this.stack.add(this.highlight);
        this.highlightStart = highlightStart;
        this.highlightEnd = highlightEnd;
        return visit(tagContent);
    }

    @Override
    public ITagContent visit(ITagContent tagContent) {
        return tagContent.accept(this);
    }

    @Override
    protected CompoundTagContent visitTagIterator(Iterator<ITagContent> iterator) {
        CompoundTagContent result = new CompoundTagContent();
        for (; iterator.hasNext(); ) {
            ITagContent tagContent = iterator.next();

            if (tagContent.getRawContentStartIndex() < this.highlightEnd &&
                    tagContent.getRawContentEndIndex() >= this.highlightStart){
                this.stack.add(this.stack.peek());
                ITagContent t = visit(tagContent);
                if (t != null) {
                    result.add(t);
                }
                this.stack.pop();
            } else {
                result.add(tagContent);
            }

        }
        return result;
    }

    @Override
    public ITagContent visitTag(SimpleTagContent tag) {
        if (this.stack.peek() || this.alwaysHighlight){
            HighlightTag highlightTag = new HighlightTag();
            highlightTag.setContent(tag);
            return highlightTag;
        } else {
            return tag;
        }
    }

    @Override
    public ITagContent visitTag(HighlightTag tag) {
        this.stack.pop();
        this.stack.add(false);
        return visit(tag.getContent());
    }
}
