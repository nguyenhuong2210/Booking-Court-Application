package com.example.io_test1.CustomXMLParser.Tags;

import com.example.io_test1.CustomXMLParser.Tags.Tags.BoldTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BookTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BookmarkTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.ChapterTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.CompoundTagContent;
import com.example.io_test1.CustomXMLParser.Tags.Tags.FontTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.HighlightTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.ItalicTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.PagebreakTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTagContent;

import java.util.Iterator;

public abstract class TagVisitorBase implements ITagVisitor<ITagContent> {
    @Override
    public ITagContent visit(ITagContent tagContent) {
        return tagContent.accept(this);
    }

    protected CompoundTagContent visitTagIterator(Iterator<ITagContent> iterator){
        CompoundTagContent result = new CompoundTagContent();
        for (; iterator.hasNext(); ) {
            ITagContent tagContent = iterator.next();

            ITagContent t = visit(tagContent);
            if (t != null){
                result.add(t);
            }
        }
        return result;
    }

    protected ITagContent visitChildTags(TagBase tag){
        CompoundTagContent result = visitTagIterator(tag.getContent().getIterator());

        if (result.getSize() == 1){
            tag.setContent(result.getContentAt(0));
        } else if (result.getSize() > 1) {
            tag.setContent(result);
        }

        return tag;
    }

    @Override
    public ITagContent visitTag(CompoundTagContent tag) {
        return visitTagIterator(tag.getIterator());
    }

    @Override
    public ITagContent visitTag(SimpleTagContent tag) {
        return tag;
    }

    @Override
    public ITagContent visitTag(SimpleTag tag) {
        return visitChildTags(tag);
    }

    @Override
    public ITagContent visitTag(BookTag tag) {
        return visitChildTags(tag);
    }

    @Override
    public ITagContent visitTag(ChapterTag tag) {
        return visitChildTags(tag);
    }

    @Override
    public ITagContent visitTag(BoldTag tag) {
        return visitChildTags(tag);
    }

    @Override
    public ITagContent visitTag(ItalicTag tag) {
        return visitChildTags(tag);
    }

    @Override
    public ITagContent visitTag(HighlightTag tag) {
        return visitChildTags(tag);
    }

    @Override
    public ITagContent visitTag(BookmarkTag tag) {
        return visitChildTags(tag);
    }

    @Override
    public ITagContent visitTag(PagebreakTag tag) {
        return visitChildTags(tag);
    }

    @Override
    public ITagContent visitTag(FontTag tag) {
        return visitChildTags(tag);
    }
}
