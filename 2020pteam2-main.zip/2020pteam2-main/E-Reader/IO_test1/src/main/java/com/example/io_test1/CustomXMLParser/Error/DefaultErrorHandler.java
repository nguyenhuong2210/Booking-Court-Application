package com.example.io_test1.CustomXMLParser.Error;

import org.antlr.v4.runtime.BaseErrorListener;
import org.antlr.v4.runtime.RecognitionException;
import org.antlr.v4.runtime.Recognizer;
import org.antlr.v4.runtime.misc.ParseCancellationException;

public class DefaultErrorHandler extends BaseErrorListener {
    public static final DefaultErrorHandler INSTANCE = new DefaultErrorHandler();

    private DefaultErrorHandler(){

    }

    @Override
    public void syntaxError(
            Recognizer<?, ?> recognizer,
            Object offendingSymbol,
            int line, int charPositionInLine,
            String msg,
            RecognitionException e) throws ParseCancellationException {
        super.syntaxError(recognizer, offendingSymbol, line, charPositionInLine, msg, e);
        throw new ParseCancellationException(msg);
    }
}
