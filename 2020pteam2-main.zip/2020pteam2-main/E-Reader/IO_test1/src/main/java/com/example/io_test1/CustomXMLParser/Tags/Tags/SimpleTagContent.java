package com.example.io_test1.CustomXMLParser.Tags.Tags;

import com.example.io_test1.CustomXMLParser.CustomBookType.IBookVisitor;
import com.example.io_test1.CustomXMLParser.Tags.ITagContent;
import com.example.io_test1.CustomXMLParser.Tags.ITagVisitor;

import java.util.Collections;
import java.util.Iterator;

public class SimpleTagContent implements ITagContent {
    private CharSequence content;
    private int rawStartPos, rawEndPos;

    public SimpleTagContent(CharSequence _content, int _start, int _stop) {
        this.content = _content;
        this.rawStartPos = _start;
        this.rawEndPos = _stop;
    }

    public SimpleTagContent(CharSequence _content) {
        this.content = _content;
        this.rawStartPos = Integer.MAX_VALUE;
        this.rawEndPos = -1;
    }

    @Override
    public String getText() {
        return this.content.toString();
    }

    @Override
    public CharSequence getRawText() {
        return this.content;
    }

    @Override
    public CharSequence getDisplayText() {
        return this.content;
    }

    @Override
    public Iterator<ITagContent> getIterator() {
        return Collections.singleton((ITagContent)this).iterator();
    }

    @Override
    public ITagContent getContent() {
        return this;
    }

    @Override
    public void reload() {
        // do nothing
    }

    @Override
    public int getRawContentStartIndex() {
        return this.rawStartPos;
    }

    @Override
    public int getRawContentEndIndex() {
        return this.rawEndPos;
    }

    @Override
    public <ReturnType> ReturnType accept(ITagVisitor<ReturnType> tagVisitor) {
        return tagVisitor.visitTag(this);
    }

    @Override
    public <ReturnType, VisitorType extends IBookVisitor<ReturnType>> ReturnType accept(VisitorType bookVisitor) {
        return bookVisitor.visitTag(this);
    }
}
