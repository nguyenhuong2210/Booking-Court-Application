package com.example.io_test1.CustomXMLParser.CustomBookType;

import android.text.SpannableStringBuilder;

import java.util.ArrayList;

public class CompoundBookElement implements IBookElement {
    protected ArrayList<IBookElement> elements;

    public CompoundBookElement(){
        this.elements = new ArrayList<>();
    }

    @Override
    public void reload() {
        for (IBookElement e: this.elements) {
            e.reload();
        }
    }

    @Override
    public CharSequence getRawText() {
        StringBuilder result = new StringBuilder();
        for (IBookElement _content: this.elements) {
            result.append(_content.getRawText());
        }
        return result;
    }

    @Override
    public CharSequence getDisplayText() {
        SpannableStringBuilder stringBuilder = new SpannableStringBuilder();
        for (IBookElement e: this.elements) {
            stringBuilder.append(e.getDisplayText());
        }
        return stringBuilder;
    }

    @Override
    public int getRawContentStartIndex() {
        int result = Integer.MAX_VALUE;
        if (this.elements.size() > 0){
            // not sure if this is really necessary since it should all be in order
            for (IBookElement e: this.elements) {
                if (e.getRawContentStartIndex() < result){
                    result = e.getRawContentStartIndex();
                }
            }
        }
        return result;
    }

    @Override
    public int getRawContentEndIndex() {
        int result = -1;
        if (this.elements.size() > 0){
            // not sure if this is really necessary since it should all be in order
            for (IBookElement e: this.elements) {
                if (e.getRawContentEndIndex() > result){
                    result = e.getRawContentEndIndex();
                }
            }
        }
        return result;
    }

    public int getElementsCount(){
        return this.elements.size();
    }

    public void addElement(IBookElement element){
        this.elements.add(element);
    }

    public IBookElement getElement(int index){
        return this.elements.get(index);
    }

    public void setElements(int index, IBookElement element) {
        this.elements.set(index, element);
    }

    @Override
    public <ReturnType, VisitorType extends IBookVisitor<ReturnType>> ReturnType accept(VisitorType bookVisitor) {
        return bookVisitor.visitElement(this);
    }
}
