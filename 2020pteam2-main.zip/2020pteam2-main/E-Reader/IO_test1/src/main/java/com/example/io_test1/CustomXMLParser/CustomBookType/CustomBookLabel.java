package com.example.io_test1.CustomXMLParser.CustomBookType;

import com.example.io_test1.CustomXMLParser.Tags.TagBase;

public class CustomBookLabel {
    private BookSection parentSection;
    private CustomPage atPage;
    private TagBase tag;

    public CustomBookLabel(TagBase tagBase) {
        this.atPage = null;
        this.tag = tagBase;
    }

    public void setParentSection(BookSection parentSection) {
        this.parentSection = parentSection;
    }

    public BookSection getParentSection() {
        return parentSection;
    }

    public int isAtPage() {
        if (this.atPage == null){
            return -1;
        } else {
            return this.atPage.getPageNumber();
        }
    }

    public void setPage(CustomPage page){
        this.atPage = page;
    }

    public TagBase getTag() {
        return tag;
    }
}
