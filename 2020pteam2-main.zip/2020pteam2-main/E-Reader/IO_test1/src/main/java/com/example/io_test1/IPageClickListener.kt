package com.example.io_test1

import android.view.View

interface IPageClickListener {
    fun pageClicked(v: View, pageNumber: Int, characterIndex: Int)
}