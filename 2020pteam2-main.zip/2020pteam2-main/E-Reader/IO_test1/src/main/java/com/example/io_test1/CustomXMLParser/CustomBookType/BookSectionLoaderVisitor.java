package com.example.io_test1.CustomXMLParser.CustomBookType;

import com.example.io_test1.CustomXMLParser.Tags.ITagContent;
import com.example.io_test1.CustomXMLParser.Tags.TagBase;
import com.example.io_test1.CustomXMLParser.Tags.TagSplitVisitor;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BookTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BookmarkTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.ChapterTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.FontTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.PagebreakTag;

import java.util.Iterator;
import java.util.Stack;

public class BookSectionLoaderVisitor extends TagSplitVisitor {
    // should probably be refactor into having a TagSplitVisitor instead of inheriting it
    private Stack<BookSection> sectionStack;
    private boolean insideNestedSection = false;

    public BookSectionLoaderVisitor(){
        this.sectionStack = new Stack<>();
    }

    public void loadTag(BookSection parent, ITagContent tag){
        this.sectionStack.clear();
        this.sectionStack.add(parent);
        insideNestedSection = false;
        visit(tag);
    }

    private void addNewElement(IBookElement element){
        this.sectionStack.peek().addElement(element);
    }

    private BookSection startNewSection(BookSection section){
        section.outerBook = this.sectionStack.peek().outerBook;
        section.setParentSection(this.sectionStack.peek());
        this.sectionStack.add(section);
        return section;
    }

    private void endLastSection(){
        this.sectionStack.pop();
    }

    private void addAllChildTags(TagBase tag){
        for (Iterator<ITagContent> childIter = tag.getContent().getIterator(); childIter.hasNext(); ) {
            ITagContent child = childIter.next();
            ITagContent content = visit(child);
            if (content != null){
                for (Iterator<ITagContent> iter = content.getIterator(); iter.hasNext(); ) {
                    ITagContent inner = iter.next();
                    addNewElement(inner);
                }
            }
        }
    }

    //region Tag Visitors
    @Override
    public ITagContent visitTag(BookTag tag){
        if (this.insideNestedSection) {
            this.sectionStack.pop();
        }
        this.insideNestedSection = false;
        addAllChildTags(tag);
        return null;
    }

    @Override
    public ITagContent visitTag(ChapterTag tag) {
        if (this.insideNestedSection) {
            this.sectionStack.pop();
        }
        this.insideNestedSection = false;
        BookSection lastTop;
        lastTop = this.sectionStack.peek();
        lastTop.addElement(startNewSection(new BookChapter(null)));
        this.sectionStack.peek().addBookLabel(new CustomBookLabel(tag));
        addAllChildTags(tag);
        endLastSection();
        return null;
    }

    @Override
    public ITagContent visitTag(BookmarkTag tag){
        this.sectionStack.peek().addBookmark(new CustomBookLabel(tag));
        return tag;
    }

    @Override
    public ITagContent visitTag(FontTag tag) {
        CustomBook book = this.sectionStack.peek().outerBook;
        book.textPaint.setTextSize(tag.getSize());
        book.fontName = tag.getFontType();
        return null;
    }

    @Override
    public ITagContent visitTag(PagebreakTag tag) {
        addNewElement(tag);
        return null;
    }
    //endregion
}
