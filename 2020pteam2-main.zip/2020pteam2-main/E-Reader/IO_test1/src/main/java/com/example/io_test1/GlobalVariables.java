package com.example.io_test1;

import java.util.HashMap;

public class GlobalVariables {
    // I swear to god this is one of the better way of passing information around in an app
    // yes it's really mentioned as a viable method by a google android software engineer
    // Parcelables is a pain to implement in a big scale
    // Serializable is slow on android, unless it's an external api
    // android why
    // ref:
    // https://stackoverflow.com/questions/2139134/how-to-send-an-object-from-one-android-activity-to-another-using-intents

    public static HashMap<String, Object> globalObjects = new HashMap<>();
    public static final String FILENAME = "filename";
    public static final String BOOK = "book";
    public static final String DISPLAY = "display";
    public static final String UTILITY = "utility";
}
