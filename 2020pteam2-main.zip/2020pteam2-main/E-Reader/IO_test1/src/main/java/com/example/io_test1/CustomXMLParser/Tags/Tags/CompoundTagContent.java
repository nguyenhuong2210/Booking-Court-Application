package com.example.io_test1.CustomXMLParser.Tags.Tags;

import android.text.SpannableStringBuilder;

import com.example.io_test1.CustomXMLParser.CustomBookType.IBookVisitor;
import com.example.io_test1.CustomXMLParser.Tags.ITagContent;
import com.example.io_test1.CustomXMLParser.Tags.ITagVisitor;

import java.util.ArrayList;
import java.util.Iterator;

public class CompoundTagContent implements ITagContent {
    private ArrayList<ITagContent> contents;

    public CompoundTagContent(){
        this.contents = new ArrayList<>();
    }

    public void add(ITagContent _content){
        if (_content != null) this.contents.add(_content);
    }

    @Override
    public String getText() {
        StringBuilder result = new StringBuilder();
        for (ITagContent _content: this.contents) {
            result.append(_content.getText());
        }
        return result.toString();
    }

    @Override
    public CharSequence getRawText() {
        StringBuilder result = new StringBuilder();
        for (ITagContent _content: this.contents) {
            result.append(_content.getRawText());
        }
        return result;
    }

    @Override
    public CharSequence getDisplayText() {
        SpannableStringBuilder stringBuilder = new SpannableStringBuilder();
        for (ITagContent _content: this.contents) {
            stringBuilder.append(_content.getDisplayText());
        }
        return stringBuilder;
    }

    public int getSize(){
        return this.contents.size();
    }

    public ITagContent getContentAt(int index){
        if (index < this.contents.size()){
            return this.contents.get(index);
        } else {
            return null;
        }
    }

    @Override
    public Iterator<ITagContent> getIterator() {
        return this.contents.iterator();
    }

    @Override
    public ITagContent getContent() {
        return this;
    }

    @Override
    public <ReturnType> ReturnType accept(ITagVisitor<ReturnType> tagVisitor) {
        return tagVisitor.visitTag(this);
    }

    @Override
    public <ReturnType, VisitorType extends IBookVisitor<ReturnType>> ReturnType accept(VisitorType bookVisitor) {
        return bookVisitor.visitTag(this);
    }

    @Override
    public void reload() {
        for (ITagContent _content: this.contents) {
            _content.reload();
        }
    }

    @Override
    public int getRawContentStartIndex() {
        int result = Integer.MAX_VALUE;
        if (this.contents.size() > 0){
            // not sure if this is really necessary since it should all be in order
            for (ITagContent _content: this.contents) {
                if (_content.getRawContentStartIndex() < result){
                    result = _content.getRawContentStartIndex();
                }
            }
        }
        return result;
    }

    @Override
    public int getRawContentEndIndex() {
        int result = -1;
        if (this.contents.size() > 0){
            // not sure if this is really necessary since it should all be in order
            for (ITagContent _content: this.contents) {
                if (_content.getRawContentEndIndex() > result){
                    result = _content.getRawContentEndIndex();
                }
            }
        }
        return result;
    }
}
