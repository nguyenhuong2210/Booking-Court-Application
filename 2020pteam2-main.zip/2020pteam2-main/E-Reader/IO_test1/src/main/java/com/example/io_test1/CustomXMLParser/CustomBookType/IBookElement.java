package com.example.io_test1.CustomXMLParser.CustomBookType;

public interface IBookElement {
    void reload();

    CharSequence getRawText();

    CharSequence getDisplayText();

    int getRawContentStartIndex();

    int getRawContentEndIndex();

    <ReturnType, VisitorType extends IBookVisitor<ReturnType>> ReturnType accept(VisitorType bookVisitor);
}
