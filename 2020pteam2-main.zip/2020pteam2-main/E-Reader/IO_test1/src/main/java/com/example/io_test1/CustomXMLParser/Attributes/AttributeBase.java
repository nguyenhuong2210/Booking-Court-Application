package com.example.io_test1.CustomXMLParser.Attributes;

public class AttributeBase {
    protected String name;
    protected String value;

    public AttributeBase(String _name, String _value) {
        this.name = _name;
        this.value = _value;
    }

    public String getName(){
        return this.name;
    }

    public String getValue(){
        return this.value;
    }
}
