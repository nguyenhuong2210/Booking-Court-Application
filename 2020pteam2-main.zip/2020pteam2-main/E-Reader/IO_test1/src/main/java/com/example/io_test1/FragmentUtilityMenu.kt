package com.example.io_test1

import android.app.AlertDialog
import android.content.DialogInterface
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.example.io_test1.CustomXMLParser.CustomBookType.CustomBook


class FragmentUtilityMenu : Fragment() {
    private lateinit var displaySetting: IDisplaySetting
    private lateinit var book: CustomBook

    private lateinit var bookmarkSpinner: Spinner
    private lateinit var deleteBookmarkSpinner: Spinner
    public var currentPage = -1

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        this.displaySetting = GlobalVariables.globalObjects[GlobalVariables.DISPLAY] as IDisplaySetting;
        this.book = GlobalVariables.globalObjects[GlobalVariables.BOOK] as CustomBook;

        val view = inflater.inflate(R.layout.layout_utility, container, false)

        val utilityGroup = view.findViewById<ViewGroup>(R.id.UtilityGroup)
        utilityGroup.visibility = View.INVISIBLE

        // Bind listeners
        // using if's to limit variable scope for easier copy-pasting
        // this can't use var instead because the onClick function updates with the var
        // so it would all point to the same last onClick function
        if (true) {
            val bindView = view.findViewById<View>(R.id.buttonToggle)
            bindView.setOnClickListener {onClick(bindView)}
        }

        if (true) {
            val bindView = view.findViewById<View>(R.id.buttonJump)
            bindView.setOnClickListener {onClick(bindView)}
        }

        if (true) {
            val bindView = view.findViewById<View>(R.id.buttonSaveAs)
            bindView.setOnClickListener {onClick(bindView)}
        }

        if (true) {
            val button = view.findViewById<Button>(R.id.buttonSelectStart)
            button.setOnClickListener {onClick(button)}
        }

        if (true) {
            val button = view.findViewById<Button>(R.id.buttonSelectEnd)
            button.setOnClickListener {onClick(button)}
            button.isEnabled = false;
        }

        if (true) {
            val bindView = view.findViewById<View>(R.id.buttonHighlight)
            bindView.setOnClickListener {onClick(bindView)}
            bindView.visibility = View.INVISIBLE;
        }

        if (true) {
            val bindView = view.findViewById<View>(R.id.buttonUnhighlight)
            bindView.setOnClickListener {onClick(bindView)}
            bindView.visibility = View.INVISIBLE;
        }

        if (true) {
            val bindView = view.findViewById<View>(R.id.buttonCopy)
            bindView.setOnClickListener {onClick(bindView)}
            bindView.visibility = View.INVISIBLE;
        }

        if (true) {
            val bindView = view.findViewById<View>(R.id.buttonSelectCancel)
            bindView.setOnClickListener {onClick(bindView)}
            bindView.visibility = View.INVISIBLE;
        }

        if (true) {
            val bindView = view.findViewById<View>(R.id.buttonBookmark)
            bindView.setOnClickListener {onClick(bindView)}
        }

        if (true) {
            val bindView = view.findViewById<View>(R.id.buttonDeleteBookmark)
            bindView.setOnClickListener {onClick(bindView)}
        }

        val seekOffset = 30;
        val seek: SeekBar = view.findViewById<SeekBar>(R.id.textSizeSeekBar)
        seek.progress = this.book.textPaint.textSize.toInt() - seekOffset;
        seek.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seek: SeekBar, progress: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(seek: SeekBar) {}
            override fun onStopTrackingTouch(seek: SeekBar) {
                // write custom code for progress is stopped
                val newSize = (seekOffset + seek.progress).toFloat()
                Log.d("page", "text size $newSize")
                buttonCancelClick();
                displaySetting.setTextSize(newSize)
            }
        })

        // TODO: accept lists from input instead of re-creating them

        val fontArrayList = ArrayList<String>()
        val fontDict = this.displaySetting.fontDict;
        var fontIndex = 0;
        for ((fontCount, fontName:String) in fontDict.keys.withIndex()){
            fontArrayList.add(fontName)
            // using equals because == may behave unexpectedly with string
            if (this.book.fontName.equals(fontName)) {
                fontIndex = fontCount
            }
        }
        val fontSpinner = view.findViewById<Spinner>(R.id.fontSpinner)
        fontSpinner.adapter = ArrayAdapter(activity!!.applicationContext, android.R.layout.simple_spinner_item, fontArrayList);

        fontSpinner.setSelection(fontIndex)

        fontSpinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent:AdapterView<*>, view: View, position: Int, id: Long){
                val typeFaceName = parent.getItemAtPosition(position).toString()
                displaySetting.setTypeFace(typeFaceName);
            }
            override fun onNothingSelected(parent: AdapterView<*>){
            }
        }


        //chapter1 -> pos 1 -> real chap 0
        val chapterArrayList = ArrayList<String>()
        //for (i in 1 until 3) -> 1,2
        chapterArrayList.add("Select chapter")
        for (i in 1 until book.tableOfContent.size + 1){
            chapterArrayList.add("Chapter $i")
        }
        val chapterSpinner = view.findViewById<Spinner>(R.id.chapterSpinner)
        chapterSpinner.adapter = ArrayAdapter(activity!!.applicationContext, android.R.layout.simple_spinner_item, chapterArrayList);
        chapterSpinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent:AdapterView<*>, view: View, position: Int, id: Long){
				if (position > 0){
                    displaySetting.bookLabelJump(book.tableOfContent.get(position - 1))

                    val MAKE_A_SELECTION = 0 //whatever index that is the normal starting point of the spinner.
                    chapterSpinner.setSelection(MAKE_A_SELECTION)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>){
            }
        }

        //bookmark 1 -> pos 1 -> real bookmark 0

        bookmarkSpinner = view.findViewById<Spinner>(R.id.bookmarkSpinner)
        loadBookmarkSpinner(bookmarkSpinner)
        bookmarkSpinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent:AdapterView<*>, view: View, position: Int, id: Long){
                if (position > 0){
                    displaySetting.bookLabelJump(book.bookmarks[position - 1])

                    val MAKE_A_SELECTION = 0 //whatever index that is the normal starting point of the spinner.
                    bookmarkSpinner.setSelection(MAKE_A_SELECTION)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>){}
        }

        val pageNumberView = view?.findViewById<TextView>(R.id.pageNumber)
        pageNumberView?.post {
            pageNumberView.text = Integer.toString(this.currentPage)
        }

        return view
    }


    private fun onClick(_view : View) {
        when(_view.id){
            R.id.buttonToggle -> {
                toggleVisibility()
            }
            R.id.buttonJump -> {
                buttonSelectJumpClick()
            }
            R.id.buttonSaveAs -> {
                this.displaySetting.saveAs()
            }
            R.id.buttonSelectStart -> {
                buttonSelectStartClick();
            }
            R.id.buttonSelectEnd -> {
                buttonSelectEndClick();
            }
            R.id.buttonHighlight -> {
                buttonHighlightClick();
            }
            R.id.buttonUnhighlight -> {
                buttonUnhighlightClick();
            }
            R.id.buttonCopy -> {
                buttonCopyClick();
            }
            R.id.buttonBookmark -> {
                buttonBookmarkClick();
            }
            R.id.buttonDeleteBookmark -> {
                buttonDeleteBookmarkClick();
            }
            R.id.buttonSelectCancel -> {
                buttonCancelClick()
            }
        }
    }

    public fun setViewCurrentPage(pageIndex: Int){
        val pageNumberView = view?.findViewById<TextView>(R.id.pageNumber)
        this.currentPage = pageIndex
        if (pageNumberView != null) {
            pageNumberView.text = Integer.toString(pageIndex)
        }
    }

    private fun buttonSelectStartClick(){
        val buttonStart = this.view!!.findViewById<Button>(R.id.buttonSelectStart)
        val buttonEnd = this.view!!.findViewById<Button>(R.id.buttonSelectEnd)
        val highlight = view!!.findViewById<View>(R.id.buttonHighlight)
        val unhighlight = view!!.findViewById<View>(R.id.buttonUnhighlight)
        val copy = view!!.findViewById<View>(R.id.buttonCopy)
        val cancel = view!!.findViewById<View>(R.id.buttonSelectCancel)
        buttonStart.isEnabled = false
        buttonEnd.isEnabled = true
        this.displaySetting.selectStart(true);
        this.displaySetting.selectEnd(false);

        cancel.visibility = View.VISIBLE
        highlight.visibility = View.VISIBLE
        unhighlight.visibility = View.VISIBLE
        copy.visibility = View.VISIBLE
    }

    private fun buttonSelectEndClick(){
        val buttonStart = this.view!!.findViewById<Button>(R.id.buttonSelectStart)
        val buttonEnd = this.view!!.findViewById<Button>(R.id.buttonSelectEnd)
        val highlight = view!!.findViewById<View>(R.id.buttonHighlight)
        val unhighlight = view!!.findViewById<View>(R.id.buttonUnhighlight)
        val copy = view!!.findViewById<View>(R.id.buttonCopy)
        val cancel = view!!.findViewById<View>(R.id.buttonSelectCancel)
        buttonStart.isEnabled = true;
        buttonEnd.isEnabled = false;
        this.displaySetting.selectStart(false);
        this.displaySetting.selectEnd(true);

        cancel.visibility = View.VISIBLE
        highlight.visibility = View.VISIBLE
        unhighlight.visibility = View.VISIBLE
        copy.visibility = View.VISIBLE
    }

    private fun buttonHighlightClick(){
        val highlight = view!!.findViewById<View>(R.id.buttonHighlight);
        if (highlight.visibility != View.INVISIBLE){
            this.displaySetting.highlightSelected();
            buttonCancelClick();
        }
    }

    private fun buttonUnhighlightClick(){
        val unhighlight = view!!.findViewById<View>(R.id.buttonUnhighlight);
        if (unhighlight.visibility != View.INVISIBLE){
            this.displaySetting.unhighlightSelected();
            buttonCancelClick();
        }
    }

    private fun buttonCopyClick(){
        val copy = view!!.findViewById<View>(R.id.buttonCopy);
        if (copy.visibility != View.INVISIBLE){
            this.displaySetting.copySelected();
        }
    }

    private fun buttonSelectJumpClick(){
        val builder: AlertDialog.Builder = AlertDialog.Builder(context)
        val view: View = LayoutInflater.from(context).inflate(R.layout.popup_jump, null)
        val jumpPageNumber = view.findViewById<View>(R.id.pageJumpIndex) as TextView

        builder.setPositiveButton("Jump") { dialogInterface, i ->
            // input 1 -> jump to page 0
            try {
                val pageIndex = jumpPageNumber.text.toString().toInt() - 1
                this.displaySetting.pageJump(pageIndex)
            } catch (e: NumberFormatException){
                Toast.makeText(context,"Invalid input", Toast.LENGTH_SHORT).show()
            }
        }

        builder.setNegativeButton("Cancel") { dialogInterface, i ->
        }

        builder.setView(view)
        builder.show()
    }

    private fun buttonBookmarkClick(){
        val builder: AlertDialog.Builder = AlertDialog.Builder(context)
        val view: View = LayoutInflater.from(context).inflate(R.layout.popup_create, null)
        val bookmarkName = view.findViewById<View>(R.id.textFilename) as TextView

        builder.setPositiveButton("Create") { dialogInterface, i ->
            this.displaySetting.setBookmark(bookmarkName.text)
            loadBookmarkSpinner(bookmarkSpinner)
        }

        builder.setNegativeButton("Cancel") { dialogInterface, i ->
        }

        builder.setView(view)
        builder.show()
    }

    private fun buttonDeleteBookmarkClick(){
        val builder: AlertDialog.Builder = AlertDialog.Builder(context)
        val view: View = LayoutInflater.from(context).inflate(R.layout.popup_delete_bookmark, null)

        deleteBookmarkSpinner = view.findViewById<Spinner>(R.id.deleteBookmarkSpinner) as Spinner
        loadDeleteBookmarkSpinner(deleteBookmarkSpinner)

        builder.setPositiveButton("Delete", DialogInterface.OnClickListener { dialogInterface, i ->
            if (!(book.bookmarks).isEmpty()){
            val selectedBookmarkPosition: Int = deleteBookmarkSpinner.selectedItemPosition
            Toast.makeText(context, "Bookmark " + book.bookmarks[selectedBookmarkPosition].tag.content.text + " is deleted",Toast.LENGTH_SHORT).show()
            this.displaySetting.deleteBookmark(book.bookmarks[selectedBookmarkPosition])
            loadBookmarkSpinner(bookmarkSpinner)}
        })

        builder.setNegativeButton("Cancel", DialogInterface.OnClickListener { dialogInterface, i ->
            Toast.makeText(context, "Cancel", Toast.LENGTH_SHORT).show()
        })

        builder.setView(view)
        builder.show()
    }

    private fun buttonCancelClick(){
        val cancel = view!!.findViewById<View>(R.id.buttonSelectCancel);
        if (cancel.visibility != View.INVISIBLE){
            val buttonStart = this.view!!.findViewById<Button>(R.id.buttonSelectStart)
            val buttonEnd = this.view!!.findViewById<Button>(R.id.buttonSelectEnd)
            val highlight = view!!.findViewById<View>(R.id.buttonHighlight);
            val unhighlight = view!!.findViewById<View>(R.id.buttonUnhighlight);
            val copy = view!!.findViewById<View>(R.id.buttonCopy);
            buttonStart.isEnabled = true;
            buttonEnd.isEnabled = false;
            cancel.visibility = View.INVISIBLE;
            highlight.visibility = View.INVISIBLE;
            unhighlight.visibility = View.INVISIBLE;
            copy.visibility = View.INVISIBLE;
            this.displaySetting.selectStart(false);
            this.displaySetting.selectEnd(false);
            this.displaySetting.selectCancel();
        }
    }

    private fun toggleVisibility(){
        val utilityGroup = this.view?.findViewById<ViewGroup>(R.id.UtilityGroup)
        if (utilityGroup?.visibility != View.VISIBLE){
            utilityGroup?.visibility = View.VISIBLE
        } else {
            utilityGroup.visibility = View.INVISIBLE
        }
    }

    private fun loadBookmarkSpinner(spinner: Spinner){
        val bookmarkArrayList = ArrayList<String>()
        bookmarkArrayList.add("Select bookmark to jump to")
        if (book.bookmarks.size > 0) {
            for (i in 1 until book.bookmarks.size + 1) {
                var temp = book.bookmarks[i - 1].tag.content.text
                temp = temp.substring(0, minOf(30,temp.length))
                if (temp.isEmpty()){
                    temp = "Unnamed Bookmark " + i;
                }
                bookmarkArrayList.add(temp)
            }
        }
        spinner.adapter = ArrayAdapter(activity!!.applicationContext, android.R.layout.simple_spinner_item, bookmarkArrayList);
    }

    private fun loadDeleteBookmarkSpinner(spinner: Spinner){
        val deleteBookmarkArrayList = ArrayList<String>()
        if (book.bookmarks.size > 0) {
            for (i in 0 until book.bookmarks.size) {
                var temp = book.bookmarks[i].tag.content.text
                temp = temp.substring(0, minOf(30,temp.length))
                if (temp.isEmpty()){
                    temp = "Unnamed Bookmark " + (i + 1);
                }
                deleteBookmarkArrayList.add(temp)
            }
        }
        spinner.adapter = ArrayAdapter(activity!!.applicationContext, android.R.layout.simple_spinner_item, deleteBookmarkArrayList);
    }
}