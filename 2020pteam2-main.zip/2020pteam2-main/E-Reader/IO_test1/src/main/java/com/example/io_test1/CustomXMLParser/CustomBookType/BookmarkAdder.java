package com.example.io_test1.CustomXMLParser.CustomBookType;

import com.example.io_test1.CustomXMLParser.Tags.Tags.BookmarkTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTagContent;

public class BookmarkAdder {

    public void bookmarkPage(CustomPage page, CharSequence bookmarkName){
        int[] tempTuple = findRawPos(page, 0);
        CustomBookLabel bookLabel = addBookmark(page.getSourceSection(), bookmarkName, tempTuple[0], tempTuple[1]);
        bookLabel.setPage(page);
    }

    private CustomBookLabel addBookmark(BookSection sourceSection, CharSequence bookmarkName, int rawPosition, int elementIndex){
        BookElementSplitVisitor splitVisitor = new BookElementSplitVisitor(rawPosition, rawPosition);
        BookElementTagInsertVisitor insertVisitor = new BookElementTagInsertVisitor();
        IBookElement element;

        // create new label and content to insert
        SimpleTagContent bookmarkContent = new SimpleTagContent(bookmarkName, rawPosition, rawPosition);
        BookmarkTag bookmarkTag = new BookmarkTag();
        bookmarkTag.setContent(bookmarkContent);
        CustomBookLabel bookLabel = new CustomBookLabel(bookmarkTag);

        // split and insert bookmark
        // note: could be more optimized if the insert visitor was implemented differently
        element = splitVisitor.visit(sourceSection.getElement(elementIndex));
        element = insertVisitor.insertTag(element, bookmarkTag, rawPosition);
        sourceSection.setElements(elementIndex, element);
        sourceSection.addBookmark(bookLabel);
        sourceSection.sortBookmark();
        // comment out next line to disable sorting the display bookmark
        sourceSection.outerBook.sortBookmark();
        return bookLabel;
    }

    private int[] findRawPos(CustomPage page, int pos){
        int rawPos = -1;
        int atTagIndex = -1;
        BookSection sourceSection = page.getSourceSection();
        int displayLength = page.getDisplayLength();
        StringBuilder stringBuilder = new StringBuilder();
        int startIndex = page.getStartIndex();
        int endIndex = page.getEndIndex();

        // relative position counting from the end
        int relativePos = displayLength - pos - 1;

        boolean trimmedEnd = false;
        boolean foundStartElement = false;

        // try to calculate the raw text position from the page position
        for (int i = endIndex; i >= startIndex; i--){
            IBookElement element =  sourceSection.getElement(i);
            stringBuilder.insert(0, element.getDisplayText());
            if (!trimmedEnd && stringBuilder.length() >= page.getExcessLength()){
                stringBuilder.delete(stringBuilder.length() - page.getExcessLength(), stringBuilder.length());
                trimmedEnd = true;
            }
            if (trimmedEnd){
                if (relativePos < stringBuilder.length()) {
                    element = sourceSection.getElement(i);
                    atTagIndex = i;
                    rawPos =
                            element.getRawContentStartIndex()
                                    + stringBuilder.length()
                                    - relativePos - 1;
                    break;
                }
            }
        }

        return new int[]{rawPos, atTagIndex};
    }
}
