package com.example.io_test1.CustomXMLParser.CustomBookType;

public class BookChapter extends BookSection {
    private boolean addedChapterLabel = false;

    public BookChapter(BookSection parent) {
        super(parent);
    }

    @Override
    public CharSequence getRawText() {
        StringBuilder result = new StringBuilder();
        result.append("<chapter>");
        result.append(super.getRawText());
        result.append("</chapter>");
        return result;
    }

    @Override
    public void reload() {
        this.addedChapterLabel = false;
        super.reload();
    }

    @Override
    public CustomPage next() {
        CustomPage result = super.next();
        if (result != null && !this.addedChapterLabel) {
            this.bookLabels.get(0).setPage(result);
            this.addedChapterLabel = true;
        }
        return result;
    }

    @Override
    public <ReturnType, VisitorType extends IBookVisitor<ReturnType>> ReturnType accept(VisitorType bookVisitor) {
        return bookVisitor.visitElement(this);
    }
}
