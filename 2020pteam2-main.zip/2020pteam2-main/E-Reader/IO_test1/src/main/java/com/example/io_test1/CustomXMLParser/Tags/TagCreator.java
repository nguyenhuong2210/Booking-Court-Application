package com.example.io_test1.CustomXMLParser.Tags;

import com.example.io_test1.CustomXMLParser.Tags.Tags.BoldTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BookTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BookmarkTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.ChapterTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.HighlightTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.ItalicTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.PagebreakTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.FontTag;

import java.util.HashMap;

public class TagCreator {
    // there probably is a better way of doing this;
    private static HashMap<String, TagBase> dict = new HashMap<>();

    static {
        TagBase tag;

        tag = new BookTag();
        dict.put(tag.getName(), tag);

        tag = new ChapterTag();
        dict.put(tag.getName(), tag);

        tag = new BookmarkTag();
        dict.put(tag.getName(), tag);

        tag = new FontTag();
        dict.put(tag.getName(), tag);

        tag = new BoldTag();
        dict.put(tag.getName(), tag);

        tag = new ItalicTag();
        dict.put(tag.getName(), tag);

        tag = new HighlightTag();
        dict.put(tag.getName(), tag);

        tag = new PagebreakTag();
        dict.put(tag.getName(), tag);
    }

    public static TagBase CreateTagFrom(String tagName) {
        TagBase result = dict.get(tagName);
        if (result != null){
            result = result.shallowCopy();
            result.setContent(null);
        } else {
            result = new SimpleTag(tagName);
        }
        return result;
    }
}
