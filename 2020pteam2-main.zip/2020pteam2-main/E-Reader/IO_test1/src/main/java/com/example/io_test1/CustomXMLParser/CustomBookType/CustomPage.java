package com.example.io_test1.CustomXMLParser.CustomBookType;

import android.graphics.Color;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;

public class CustomPage {
    private BookSection sourceSection;
    private int startIndex, endIndex;
    private int pageNumber, displayLength, excessLength, selectColor, tempSelectStart, tempSelectEnd;
    private CharSequence displayText;

    public CustomPage(BookSection section, int _startIndex, int _endIndex) {
        this.sourceSection = section;
        this.displayText = new SpannableStringBuilder();
        this.startIndex = _startIndex;
        this.endIndex = _endIndex;
        this.displayLength = 0;
        this.excessLength = 0;
        this.selectColor = Color.CYAN;
        this.tempSelectStart = 0;
        this.tempSelectEnd = 0;
    }

    public int getStartIndex() {
        return startIndex;
    }

    public int getEndIndex() {
        return endIndex;
    }

    public void setDisplayLength(int length){
        this.displayLength = length;
    }

    public int getDisplayLength(){
        return this.displayLength;
    }

    public void setExcessLength(int length){
        this.excessLength = length;
    }

    public int getExcessLength() {
        return this.excessLength;
    }

    public void setTempSelectStart(int index){
        this.tempSelectStart = index;
    }

    public int getTempSelectStart() {
        return this.tempSelectStart;
    }

    public void setTempSelectEnd(int index){
        this.tempSelectEnd = index;
    }

    public int getTempSelectEnd() {
        return this.tempSelectEnd;
    }

    public void setPageNumber(int number){
        this.pageNumber = number;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public BookSection getSourceSection() {
        return this.sourceSection;
    }

    public void reload(){
        // assuming the length and size has not changed
        // it would be necessary to reload the whole book otherwise
        SpannableStringBuilder stringBuilder = new SpannableStringBuilder();
        for (int index = this.startIndex; index <= this.endIndex; index++) {
            stringBuilder.append(this.sourceSection.getElement(index).getDisplayText());
        }
        int currentLength = stringBuilder.length();
        this.displayText = stringBuilder.subSequence(
                currentLength - this.displayLength - this.excessLength,
                currentLength - this.excessLength);
    }

    public CharSequence getDisplayText() {
        if (this.tempSelectEnd > this.tempSelectStart && this.tempSelectStart >= 0){
            SpannableStringBuilder stringBuilder = new SpannableStringBuilder();
            stringBuilder.append(this.displayText);
            stringBuilder.setSpan(
                    new BackgroundColorSpan(this.selectColor),
                    this.tempSelectStart, this.tempSelectEnd,
                    Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
            return stringBuilder;
        } else {
            return this.displayText;
        }
    }

    public void setDisplayText(SpannableStringBuilder _displayText) {
        this.displayText = _displayText;
    }

    public void highlightSelection(PageHighlighter pageHighlighter) {
        if (this.tempSelectEnd > this.tempSelectStart && this.tempSelectStart >= 0){
            pageHighlighter.addPage(this);
        }
    }
}
