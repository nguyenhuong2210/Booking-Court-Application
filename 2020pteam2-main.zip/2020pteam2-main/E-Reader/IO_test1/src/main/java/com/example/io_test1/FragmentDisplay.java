package com.example.io_test1;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Point;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.io_test1.CustomXMLParser.CustomBookType.BookSection;
import com.example.io_test1.CustomXMLParser.CustomBookType.BookmarkAdder;
import com.example.io_test1.CustomXMLParser.CustomBookType.CustomBook;
import com.example.io_test1.CustomXMLParser.CustomBookType.CustomBookLabel;
import com.example.io_test1.CustomXMLParser.CustomBookType.CustomPage;
import com.example.io_test1.CustomXMLParser.CustomBookType.PageHighlighter;

import org.antlr.v4.runtime.misc.ParseCancellationException;
import org.jetbrains.annotations.NotNull;

import java.io.ByteArrayInputStream;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

import static android.app.Activity.RESULT_OK;
import static androidx.core.content.ContextCompat.getSystemService;

public class FragmentDisplay extends Fragment implements IPageClickListener, IDisplaySetting {
    public static final String DEFAULT_FONT_NAME = "arial";

    private HashMap<String, Typeface> fontDict = new HashMap<>();
    private int FILE_SELECT_CODE = 111;
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private CustomPageAdapter pageAdapter;
    private CustomBook book;
    private boolean selectStartMode = false, selectEndMode = false;
    private int selectStartPage, selectEndPage, selectStartIndex, selectEndIndex;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        GlobalVariables.globalObjects.put(GlobalVariables.DISPLAY, this);

        View view = getLayoutInflater().inflate(R.layout.layout_display, container, false);
        TextView filenameDisplay = view.findViewById(R.id.textTitleDisplay);
        filenameDisplay.setText((CharSequence) GlobalVariables.globalObjects.get(GlobalVariables.FILENAME));
        this.book = (CustomBook) GlobalVariables.globalObjects.get(GlobalVariables.BOOK);

        //region load recyclerView

        //region calculate the scrollView's supposed height
        // by subtracting the device's height by the other elements
        // ref:
        // https://stackoverflow.com/questions/21926644/get-height-and-width-of-a-layout-programmatically
        // old note: add this snippet to the screen size change listener also
        // turns out it's not needed at all because this gets "re-created" so it automatically run this code again
        int height = 0;
        int width = 0;
        WindowManager wm =
                (WindowManager) view.getContext().getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();

        int deviceWidth;

        Point size = new Point();
        display.getSize(size);
        deviceWidth = size.x;

        int widthMeasureSpec = View.MeasureSpec.makeMeasureSpec(deviceWidth, View.MeasureSpec.AT_MOST);
        int heightMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        filenameDisplay.measure(widthMeasureSpec, heightMeasureSpec);
        height = size.y - filenameDisplay.getMeasuredHeight();
        width = deviceWidth;
        //endregion


        setUpFontMap(getContext());

        this.book.pageWidth = width;
        this.book.pageHeight = height;
        this.book.spacingMul = 1.0f;
        this.book.spacingAdd = 0f;
        Typeface typeFace = this.fontDict.get(this.book.fontName);
        if (typeFace == null) {
            this.book.textPaint.setTypeface(this.fontDict.get(DEFAULT_FONT_NAME));
            this.book.fontName = DEFAULT_FONT_NAME;
        }
        GlobalVariables.globalObjects.put(GlobalVariables.BOOK, this.book);

        // preload 2 pages
        this.book.tryGetPage(1);

        this.recyclerView = view.findViewById(R.id.listPages);

        this.pageAdapter = new CustomPageAdapter(this.book, this);
        this.layoutManager = new LinearLayoutManager(getContext());

        this.recyclerView.setAdapter(this.pageAdapter);
        this.recyclerView.setLayoutManager(this.layoutManager);

        // try to update the pageAdapter after scrolling to the bottom view
        // maybe this should be done in another thread to reduce stuttering?
        this.recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                FragmentUtilityMenu utilityMenu = ((FragmentUtilityMenu)GlobalVariables.globalObjects.get(GlobalVariables.UTILITY));
                int currentPage = getCurrentPage() + 1;
                if (currentPage != utilityMenu.getCurrentPage()){
                    utilityMenu.setViewCurrentPage(currentPage);
                }
            }

            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                int preloadCount = 2;
                if (book.getCurrentPageCount() - preloadCount <= layoutManager.findLastVisibleItemPosition()) {
                    boolean updated = false;
                    for (int i = 0; i < preloadCount; i++){
                        if (book.addNextPage()){
                            updated = true;
                        } else {
                            break;
                        }
                    }
                    if (updated){
                        pageAdapter.notifyDataSetChanged();
                    }

                }
            }
        });
        //endregion

        //region utility menu
        // nested fragment notes: use child fragment manager
        // ref:
        // https://stackoverflow.com/questions/7508044/android-fragment-no-view-found-for-id
        selectCancel();
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        FragmentUtilityMenu utilityMenu = new FragmentUtilityMenu();
        utilityMenu.setCurrentPage(1);
        GlobalVariables.globalObjects.put(GlobalVariables.UTILITY, utilityMenu);
        transaction.replace(R.id.UtilityFragment, utilityMenu);
        transaction.commit();
        //endregion

        return view;
    }

    @Override
    public void onStop() {
        super.onStop();
        GlobalVariables.globalObjects.put(GlobalVariables.DISPLAY, null);
    }

    private void reloadBook() throws IOException, ParseCancellationException {
        selectCancel();
        CharSequence rawBook = this.book.getRawText();
        int lastPage = this.layoutManager.findLastVisibleItemPosition();
        lastPage = Math.max(lastPage, 0);
        this.book.createBook(new ByteArrayInputStream(rawBook.toString().getBytes()));
        this.book.tryGetPage(lastPage);
    }

    @Override
    public int getCurrentPage() {
        int pageNumber = this.layoutManager.findFirstCompletelyVisibleItemPosition();
        if (pageNumber < 0){
            pageNumber = this.layoutManager.findFirstVisibleItemPosition();
        }
        // a page check because of the extra empty page
        pageNumber = Math.min(this.book.getCurrentPageCount() - 1, pageNumber);
        pageNumber = Math.max(0, pageNumber);
        return pageNumber;
    }

    @Override
    public void pageJump(int pageNumber) {
        pageNumber = Math.max(pageNumber, 0);
        int
                extraPageOffset = 2,
                lastPageCount = this.book.getCurrentPageCount(),
                currentPageCount = lastPageCount;

        if (pageNumber > lastPageCount){
            this.book.tryGetPage(pageNumber + extraPageOffset);
            currentPageCount = this.book.getCurrentPageCount();
        }

        if (lastPageCount != currentPageCount){
            this.pageAdapter.notifyDataSetChanged();
        }
        // Note: using layout manager directly to scroll is more accurate for some reasons
        this.layoutManager.scrollToPosition(Math.min(pageNumber, this.book.getCurrentPageCount() - 1));
    }

    @Override
    public void bookLabelJump(CustomBookLabel label) {
        // note: there is a bug with scrolling to newly added label
        // whenever the book is re-renderer, they stops working
        // but it's fixed after save and reloading
        while (label.isAtPage() < 0){
            if (!this.book.addNextPage())
                break;
        }
        if (label.isAtPage() >= 0) {
            pageJump(label.isAtPage());
        }
    }

    @Override
    public void setBookmark(CharSequence name) {
        BookmarkAdder bookmarkAdder = new BookmarkAdder();
        int pageNumber = getCurrentPage();
        CustomPage page = this.book.tryGetPage(pageNumber);
        if (page != null){
            bookmarkAdder.bookmarkPage(page, name);
        }
    }

    @Override
    public void deleteBookmark(CustomBookLabel bookLabel) {
        bookLabel.getTag().isDeleted = true;
        BookSection parentSection = bookLabel.getParentSection();
        if (parentSection != null){
            parentSection.removeBookmark(bookLabel);
        }
    }

    @Override
    public void setTypeFace(String fontName){
        // try to reload book after adding bookmark, highlight & unhighlight to minimize error
        try {
            reloadBook();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Typeface typeFace;
        typeFace = this.fontDict.get(fontName);
        if (typeFace == null){
            fontName = DEFAULT_FONT_NAME;
            typeFace = this.fontDict.get(fontName);
        }
        this.book.fontName = fontName;
        this.book.textPaint.setTypeface(typeFace);
        int lastPage = this.layoutManager.findLastVisibleItemPosition();
        this.book.reload();
        if (this.book.tryGetPage(lastPage + 1) == null && this.book.getCurrentPageCount() > 0) {
            pageJump(this.book.getCurrentPageCount() - 1);
        }
        this.pageAdapter.notifyDataSetChanged();
    }

    @Override
    public void setTextSize(float size) {
        if (this.book.textPaint.getTextSize() == size)
            return;

        // try to reload book after adding bookmark, highlight & unhighlight to minimize error
        try {
            reloadBook();
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.book.textPaint.setTextSize(size);
        int lastPage = this.layoutManager.findLastVisibleItemPosition();
        this.book.reload();
        if (this.book.tryGetPage(lastPage + 1) == null && this.book.getCurrentPageCount() > 0) {
            pageJump(this.book.getCurrentPageCount() - 1);
        }
        this.pageAdapter.notifyDataSetChanged();
    }

    @Override
    public void selectStart(boolean state) {
        this.selectStartMode = state;
    }

    @Override
    public void selectEnd(boolean state) {
        this.selectEndMode = state;
    }

    @Override
    public void selectCancel() {
        this.selectStartIndex = this.selectEndIndex = this.selectStartPage = this.selectEndPage = -1;
        for (int i = 0; i < this.book.getCurrentPageCount(); i++){
            CustomPage currentPage = this.book.tryGetPage(i);
            currentPage.setTempSelectStart(0);
            currentPage.setTempSelectEnd(0);
        }
        this.pageAdapter.notifyDataSetChanged();
    }

    @Override
    public void copySelected() {
        if (this.selectStartPage >= 0
                && this.selectEndPage >= 0
                && this.selectStartIndex >= 0
                && this.selectEndIndex >= 0)
        {
            StringBuilder stringBuilder = new StringBuilder();
            CustomPage currentPage = null;
            int count = 0;
            for (int i = this.selectStartPage; i <= this.selectEndPage; i++){
                currentPage = this.book.tryGetPage(i);
                stringBuilder.append(currentPage.getDisplayText());
                count++;
            }
            if ((count == 1 && this.selectStartIndex <= this.selectEndIndex) || count > 1){
                CharSequence copyText = stringBuilder.substring(
                        this.selectStartIndex,
                        stringBuilder.length()
                                - currentPage.getDisplayLength()
                                + this.selectEndIndex + 1);

                ClipboardManager clipboard = getSystemService(getContext(), ClipboardManager.class);
                ClipData clip = ClipData.newPlainText("copied", copyText);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(getContext() ,"Text Copied", Toast.LENGTH_SHORT).show();
            }

        }
    }

    @Override
    public void highlightSelected() {
        if (this.selectStartPage >= 0
                && this.selectEndPage >= 0
                && this.selectStartIndex >= 0
                && this.selectEndIndex >= 0)
        {
            PageHighlighter highlighter = new PageHighlighter();
            highlighter.setHighlightToggle(false);
            highlighter.setHighlight(true);
            for (int i = this.selectStartPage; i <= this.selectEndPage; i++){
                CustomPage currentPage = this.book.tryGetPage(i);
                currentPage.highlightSelection(highlighter);
            }
            highlighter.setHighlightPage();
            for (int i = this.selectStartPage; i <= this.selectEndPage; i++){
                CustomPage currentPage = this.book.tryGetPage(i);
                currentPage.reload();
            }
        }
    }

    @Override
    public void unhighlightSelected(){
        if (this.selectStartPage >= 0
                && this.selectEndPage >= 0
                && this.selectStartIndex >= 0
                && this.selectEndIndex >= 0)
        {
            PageHighlighter highlighter = new PageHighlighter();
            highlighter.setHighlightToggle(false);
            highlighter.setHighlight(false);
            for (int i = this.selectStartPage; i <= this.selectEndPage; i++){
                CustomPage currentPage = this.book.tryGetPage(i);
                currentPage.highlightSelection(highlighter);
            }
            highlighter.setHighlightPage();
            for (int i = this.selectStartPage; i <= this.selectEndPage; i++){
                CustomPage currentPage = this.book.tryGetPage(i);
                currentPage.reload();
            }
        }
    }

    @Override
    public void saveAs() {
        // this should use ACTION_GET_CONTENT to support older devices (APi 16 vs 19)
        // but I literally cannot figure out why using it result in a permission denial
        // while ACTION_OPEN_DOCUMENT document do it just fine
        // and that doesn't even need FLAG_GRANT_WRITE_URI_PERMISSION in some cases
        // note: it can't write to file in the recently opened files for some reasons
        // not sure if that would be the case if ACTION_GET_CONTENT also
        // note 2: turned out the permission denial is a version-specific error,
        // so that was a good day wasted trying to figure that out
        // ref:
        // https://stackoverflow.com/questions/23692675/permission-denial-when-starting-intent-using-action-get-content-with-set-type
        Intent intent = new Intent();
        intent.setType("text/*");
        if (Build.VERSION.SDK_INT < 19) {
            intent.setAction(Intent.ACTION_GET_CONTENT);
        } else {
            intent.setAction(Intent.ACTION_OPEN_DOCUMENT);
        }

        intent.setFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(intent, "Select a file"), FILE_SELECT_CODE);
    }

    private void saveFile(Uri uri){
        try {
            if (uri == null) throw new IOException();
            ParcelFileDescriptor pfd  = getContext().getContentResolver().openFileDescriptor(uri, "w");
            FileDescriptor fileDescriptor = pfd.getFileDescriptor();
            FileOutputStream fileStream = new FileOutputStream(fileDescriptor);
            CharSequence charSequence = this.book.getRawText();

            // This overrides the content of the file
            // but doesn't clear everything that goes after
            // TODO: fix this
            // note: seems to be a version-specific problem because testing on another phone
            // with lower version than the emulator doesn't have the same issue
            fileStream.write(charSequence.toString().getBytes());

            fileDescriptor.sync();

            fileStream.close();
            pfd.close();

            showAlert("File saved");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Can't write to file. Please Check file or directory.");
        }
    }

    @Override
    public void pageClicked(@NotNull View v, int pageNumber, int characterIndex) {
        //Log.d("bookPage", "Page: " + pageNumber + " at character: " + characterIndex);

        // set temp highlight character
        if (characterIndex >= 0 && (this.selectStartMode || this.selectEndMode)){
            CustomPage currentPage;
            // set and highlight chosen character
            if (this.selectStartMode){
                currentPage = this.book.tryGetPage(pageNumber);
                currentPage.setTempSelectStart(characterIndex);
                currentPage.setTempSelectEnd(characterIndex + 1);

                if (this.selectStartPage >= 0){
                    if (pageNumber != this.selectStartPage){
                        currentPage = this.book.tryGetPage(this.selectStartPage);
                        currentPage.setTempSelectStart(0);
                        currentPage.setTempSelectEnd(0);
                    }

                    for (int i = pageNumber - 1; i >= this.selectStartPage; i--){
                        currentPage = this.book.tryGetPage(i);
                        currentPage.setTempSelectStart(0);
                        currentPage.setTempSelectEnd(0);
                    }
                }
                this.selectStartPage = pageNumber;
                this.selectStartIndex = characterIndex;
            }

            if (this.selectEndMode){
                currentPage = this.book.tryGetPage(pageNumber);
                currentPage.setTempSelectStart(characterIndex);
                currentPage.setTempSelectEnd(characterIndex + 1);

                if (pageNumber != this.selectEndPage && this.selectEndPage >= 0){
                    currentPage = this.book.tryGetPage(this.selectEndPage);
                    currentPage.setTempSelectStart(0);
                    currentPage.setTempSelectEnd(0);
                }

                for (int i = this.selectEndPage; i > pageNumber; i--){
                    currentPage = this.book.tryGetPage(i);
                    currentPage.setTempSelectStart(0);
                    currentPage.setTempSelectEnd(0);
                }
                this.selectEndPage = pageNumber;
                this.selectEndIndex = characterIndex;
            }

            // check if there is a valid range to display
            if (this.selectStartPage >= 0
                    && this.selectEndPage >= 0
                    && this.selectStartIndex >= 0
                    && this.selectEndIndex >= 0)
            {
                if (this.selectStartPage == this.selectEndPage && this.selectStartIndex < this.selectEndIndex)
                {
                    currentPage = this.book.tryGetPage(this.selectStartPage);
                    currentPage.setTempSelectStart(this.selectStartIndex);
                    currentPage.setTempSelectEnd(this.selectEndIndex + 1);
                } else if (this.selectStartPage < this.selectEndPage)
                {
                    currentPage = this.book.tryGetPage(this.selectStartPage);
                    currentPage.setTempSelectStart(this.selectStartIndex);
                    currentPage.setTempSelectEnd(currentPage.getDisplayLength());

                    for (int i = this.selectStartPage + 1; i < this.selectEndPage; i++){
                        currentPage = this.book.tryGetPage(i);
                        currentPage.setTempSelectStart(0);
                        currentPage.setTempSelectEnd(currentPage.getDisplayLength());
                    }

                    currentPage = this.book.tryGetPage(this.selectEndPage);
                    currentPage.setTempSelectStart(0);
                    currentPage.setTempSelectEnd(this.selectEndIndex + 1);
                }
            }


            // there is a display bug that happens
            // when updating the adapter while both last page and its previous page is visible
            // makes the book jump back to the previous page
            // old: fix this
            // note: this seems almost like a built-in "feature" of recycler view/adapter or something
            // because even updating 1 item at the end position reset the scroll to the previous page
            // band-aid fix of auto-scrolling to the page if selecting the last page
            // unfortunately it happens every time the adapter is updated
            // note2: new "solution" is having an extra empty page
            this.pageAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_SELECT_CODE && resultCode == RESULT_OK) {
            // Write book to selected file
            Uri uri = data.getData();
            saveFile(uri);
        }
    }

    private void showAlert(String msg){
        AlertDialog.Builder alert = new AlertDialog.Builder(getContext());
        alert.setMessage(msg);
        alert.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alert.show();
    }

    private void setUpFontMap(Context context){
        fontDict.put(DEFAULT_FONT_NAME, ResourcesCompat.getFont(context, R.font.arial));
        fontDict.put("garamond", ResourcesCompat.getFont(context, R.font.garamond));
        fontDict.put("montserrat",ResourcesCompat.getFont(context, R.font.montserrat));
        fontDict.put("raleway",ResourcesCompat.getFont(context, R.font.raleway));
    }

    @Override
    public HashMap<String, Typeface> getFontDict(){
        return this.fontDict;
    }
}
