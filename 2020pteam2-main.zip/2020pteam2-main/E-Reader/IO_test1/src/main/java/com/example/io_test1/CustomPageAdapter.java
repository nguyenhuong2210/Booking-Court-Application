package com.example.io_test1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.io_test1.CustomXMLParser.CustomBookType.CustomBook;


public class CustomPageAdapter extends RecyclerView.Adapter<CustomPageHolder>{
    private CustomBook book;
    private IPageClickListener pageClickListener;

    // Click listener based on this post
    // https://stackoverflow.com/posts/28304517/revisions

    public CustomPageAdapter(CustomBook _book, IPageClickListener _pageClickListener){
        this.book = _book;
        this.pageClickListener = _pageClickListener;
    }

    @NonNull
    @Override
    public CustomPageHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_page, parent, false);
        return new CustomPageHolder(view, this.pageClickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomPageHolder holder, int position) {
        holder.bindItem(this.book);
    }

    @Override
    public int getItemCount() {
        return this.book.getCurrentPageCount() + 1;
    }

}