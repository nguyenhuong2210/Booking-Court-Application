package com.example.io_test1.CustomXMLParser.CustomBookType;

import android.text.TextPaint;

import com.example.io_test1.CustomXMLParser.Attributes.AttributeBase;
import com.example.io_test1.CustomXMLParser.Error.DefaultErrorHandler;
import com.example.io_test1.CustomXMLParser.Generated.XMLLexer;
import com.example.io_test1.CustomXMLParser.Generated.XMLParser;
import com.example.io_test1.CustomXMLParser.Tags.ITagContent;
import com.example.io_test1.CustomXMLParser.Tags.TagContentVisitor;
import com.example.io_test1.CustomXMLParser.Tags.Tags.FontTag;

import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.Lexer;
import org.antlr.v4.runtime.atn.LexerATNSimulator;
import org.antlr.v4.runtime.atn.ParserATNSimulator;
import org.antlr.v4.runtime.atn.PredictionContextCache;
import org.antlr.v4.runtime.misc.ParseCancellationException;
import org.antlr.v4.runtime.tree.ParseTree;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class CustomBook extends BookSection {
    private ArrayList<CustomPage> pages;
    public TextPaint textPaint;
    public String fontName;
    public int pageWidth;
    public int pageHeight;
    public float spacingMul;
    public float spacingAdd;

    public CustomBook(){
        super(null);
        this.outerBook = this;
        // default values
        this.textPaint = new TextPaint();
        this.textPaint.setTextSize(30);
        this.fontName = "placeholder";
        this.pageWidth = 0;
        this.pageHeight = 0;
        this.spacingMul = 1.0f;
        this.spacingAdd = 0f;
        this.pages = new ArrayList<>();
    }

    public CustomBook createBook(InputStream inputStream) throws IOException, ParseCancellationException {
        CharStream charStream = CharStreams.fromStream(inputStream);
        Lexer lexer = new XMLLexer(charStream);
        CommonTokenStream commonTokenStream = new CommonTokenStream(lexer);
        XMLParser parser = new XMLParser(commonTokenStream);
        lexer.removeErrorListeners();
        lexer.addErrorListener(DefaultErrorHandler.INSTANCE);
        parser.removeErrorListeners();
        parser.addErrorListener(DefaultErrorHandler.INSTANCE);
        ParseTree parseTree = parser.document();

        TagContentVisitor tagContentVisitor = new TagContentVisitor();
        ITagContent tagContent = tagContentVisitor.visit(parseTree);

        // assign new cache so gc can collect the old cache
        lexer.setInterpreter(new LexerATNSimulator(lexer, lexer.getATN(), lexer.getInterpreter().decisionToDFA, new PredictionContextCache()));
        parser.setInterpreter(new ParserATNSimulator(parser, parser.getATN(), parser.getInterpreter().decisionToDFA, new PredictionContextCache()));

        parser.dumpDFA();
        inputStream.close();

        return createBook(tagContent);
    }

    public CustomBook createBook(ITagContent... tags){
        this.elements.clear();
        this.bookmarks.clear();
        this.bookLabels.clear();
        this.pages.clear();

        BookSectionLoaderVisitor sectionLoaderVisitor = new BookSectionLoaderVisitor();
        for (ITagContent content: tags) {
            BookSection section = new BookSection(this);
            section.outerBook = this;
            sectionLoaderVisitor.loadTag(section, content);
            this.elements.add(section);
        }
        return this;
    }

    @Override
    public void reload() {
        this.pages.clear();
        for (CustomBookLabel label : this.bookmarks){
            label.setPage(null);
        }
        for (CustomBookLabel label : this.bookLabels){
            label.setPage(null);
        }
        super.reload();
    }

    @Override
    public CharSequence getRawText() {
        StringBuilder result = new StringBuilder();

        FontTag fontTag = new FontTag();
        fontTag.addAttribute(new AttributeBase(FontTag.SIZE, Float.toString(this.textPaint.getTextSize())));
        fontTag.addAttribute(new AttributeBase(FontTag.FONT_TYPE, this.fontName));

        result.append("<book>");

        result.append(fontTag.getRawText());

        result.append(super.getRawText());
        result.append("</book>");
        return result;
    }

    public CustomPage tryGetPage(int index){
        if (index < 0) return null;



        if (index < this.pages.size()){
            CustomPage result = this.pages.get(index);
            if (result == null){
                this.reload();
                result = tryGetPage(index);
            }
            return result;
        } else {
            for (int i = this.pages.size(); i <= index; i++){
                if (!addNextPage()){
                    return null;
                }
            }
            return this.pages.get(index);
        }

    }

    public boolean addNextPage(){
        if (hasNext()){
            this.pages.add(next());
            int latestPageNumber = this.pages.size() - 1;
            this.pages.get(latestPageNumber).setPageNumber(latestPageNumber);
            return true;
        } else {
            return false;
        }
    }

    public int getCurrentPageCount(){
        return this.pages.size();
    }

    @Override
    public void addBookmark(CustomBookLabel bookLabel){
        this.bookmarks.add(bookLabel);
    }

    @Override
    public void removeBookmark(CustomBookLabel bookLabel) {
        this.bookmarks.remove(bookLabel);
    }

    public ArrayList<CustomBookLabel> getBookmarks(){
        return this.bookmarks;
    }

    @Override
    public void addBookLabel(CustomBookLabel bookLabel){
        this.bookLabels.add(bookLabel);
    }

    public ArrayList<CustomBookLabel> getTableOfContent(){
        return this.bookLabels;
    }
}
