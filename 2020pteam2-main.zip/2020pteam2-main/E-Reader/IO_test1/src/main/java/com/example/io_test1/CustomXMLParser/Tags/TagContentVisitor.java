package com.example.io_test1.CustomXMLParser.Tags;

import com.example.io_test1.CustomXMLParser.Attributes.AttributeBase;
import com.example.io_test1.CustomXMLParser.Attributes.AttributeVisitor;
import com.example.io_test1.CustomXMLParser.Generated.XMLParser;
import com.example.io_test1.CustomXMLParser.Generated.XMLParserBaseVisitor;
import com.example.io_test1.CustomXMLParser.Tags.Tags.CompoundTagContent;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTagContent;

import org.antlr.v4.runtime.misc.ParseCancellationException;
import org.antlr.v4.runtime.tree.ParseTree;

import java.util.Stack;

import static com.example.io_test1.CustomXMLParser.Tags.TagCreator.CreateTagFrom;

public class TagContentVisitor extends XMLParserBaseVisitor<ITagContent> {
    private Stack<TagBase> tagStack = new Stack<>();
    private Stack<CompoundTagContent> tagContentStack = new Stack<>();
    private Stack<String> tagNameStack = new Stack<>();

    @Override
    public ITagContent visitDocument(XMLParser.DocumentContext ctx) {
        this.tagStack.clear();
        this.tagContentStack.clear();
        this.tagNameStack.clear();
        CompoundTagContent tagList = new CompoundTagContent();
        this.tagContentStack.add(tagList);
        for (ParseTree child: ctx.children){
            tagList.add(visit(child));
        }

        return tagList;
    }

    @Override
    public ITagContent visitProlog(XMLParser.PrologContext ctx) {
        return super.visitProlog(ctx);
    }

    @Override
    public CompoundTagContent visitContent(XMLParser.ContentContext ctx) {
        // this adds to the top of the stack instead of a local variable
        // to allow for better manipulation of the content for tag correction
        // i.e: <b>test1 <i>test2</b> test3</i>
        // would be corrected to
        // <b>test1 <i1>test2</i1></b><i2> test3</i2>
        // so if this was adding to a local variable,
        // ' test3' would also be added to the bold tag content
        // and would be harder to correct
        // more about the correction in the closeTag() method
        if (ctx.children != null){
            for (ParseTree child: ctx.children){
                ITagContent content = visit(child);
                if (content != null){
                    this.tagContentStack.peek().add(content);
                }
            }
        } else {
            this.tagContentStack.peek().add(new SimpleTagContent("", ctx.stop.getStopIndex(), ctx.stop.getStopIndex()));
        }
        return null;
    }

    @Override
    public TagBase visitDoubleTag(XMLParser.DoubleTagContext ctx) {
        String tagName = ctx.tagNames.get(0).getText();
        TagBase tag = openTag(tagName);

        AttributeVisitor attributeVisitor = new AttributeVisitor();
        for (XMLParser.AttributeContext attributeContext: ctx.tagAttributes) {
            AttributeBase attribute = attributeVisitor.visitAttribute(attributeContext);
            if (attribute != null){
                tag.addAttribute(attribute);
            }
        }

        visitContent(ctx.content());

        return closeTag(ctx.tagNames.get(1).getText());
    }

    @Override
    public TagBase visitSingleTag(XMLParser.SingleTagContext ctx) {
        TagBase tag = CreateTagFrom(ctx.Name().getText());
        AttributeVisitor attributeVisitor = new AttributeVisitor();
        for (XMLParser.AttributeContext attributeContext: ctx.tagAttributes) {
            AttributeBase attribute = attributeVisitor.visitAttribute(attributeContext);
            if (attribute != null){
                tag.addAttribute(attribute);
            }
        }

        tag.setContent(new SimpleTagContent("", ctx.stop.getStopIndex(), ctx.stop.getStopIndex()));

        return tag;
    }

    @Override
    public ITagContent visitReference(XMLParser.ReferenceContext ctx) {
        return super.visitReference(ctx);
    }

    @Override
    public ITagContent visitAttribute(XMLParser.AttributeContext ctx) {
        return super.visitAttribute(ctx);
    }

    @Override
    public ITagContent visitChardata(XMLParser.ChardataContext ctx) {
        return new SimpleTagContent(ctx.getText(), ctx.start.getStartIndex(), ctx.stop.getStopIndex());
    }

    @Override
    public ITagContent visitMisc(XMLParser.MiscContext ctx) {
        return super.visitMisc(ctx);
    }

    private TagBase openTag(String tagName){
        TagBase tag;
        tag = CreateTagFrom(tagName);
        CompoundTagContent compoundTagContent = new CompoundTagContent();
        this.tagContentStack.add(compoundTagContent);
        this.tagNameStack.add(tagName);
        this.tagStack.add(tag);
        return tag;
    }

    private TagBase closeTag(String endTagName){
        // this function detects if the end tag is the same as the tag on the top of the stack
        // if it isn't, it means that there are overlapping tags
        // and this would attempt to correct the structure of the tags
        // i.e: <b>test1 <i>test2</b> test3</i>
        // would be corrected to
        // <b>test1 <i1>test2</i1></b><i2> test3</i2>
        // note: probably would be easier with some kind of recursion
        if (!this.tagNameStack.peek().equals(endTagName)){
            Stack<String> tempNameStack = new Stack<>();
            Stack<TagBase> tempTagStack = new Stack<>();
            Stack<CompoundTagContent> tempContentStack = new Stack<>();
            String tempName;
            TagBase tempTag;
            CompoundTagContent tempContent;

            // go through the stack to find a tag of this type
            // adding the top to temp stacks
            boolean isTagFound = false;
            while (!this.tagNameStack.empty()){
                tempName = this.tagNameStack.pop();
                tempTag = this.tagStack.pop();
                tempContent = this.tagContentStack.pop();
                tempNameStack.add(tempName);
                tempTagStack.add(tempTag);
                tempContentStack.add(tempContent);
                if (tempName.equals(endTagName)){
                    isTagFound = true;
                    break;
                }
            }
            if (!isTagFound){
                // there are no opening tag of this type
                throw new ParseCancellationException();
            }

            // the one on top of the temp stacks is the tag we're looking for
            tempNameStack.pop();
            TagBase resultTag = tempTagStack.pop();
            CompoundTagContent resultTagContent = tempContentStack.pop();
            resultTag.setContent(resultTagContent);
            this.tagContentStack.peek().add(resultTag);

            // there should always be at least 1 other tag in the stacks
            // go through each tags on the temp stack and add it into the result tag content
            // with respect to their order
            // and create a copy of it with a new compound content onto the outer stack
            // since this is just moving content from 1 stack to another and back,
            // the order on the outer stack should be preserved
            while (!tempTagStack.empty()){
                String sourceName = tempNameStack.pop();
                TagBase sourceTag = tempTagStack.pop();
                CompoundTagContent sourceContent = tempContentStack.pop();

                this.tagNameStack.add(sourceName);
                this.tagStack.add(sourceTag);
                this.tagContentStack.add(new CompoundTagContent());

                tempTag = sourceTag.shallowCopy();
                tempTag.setContent(sourceContent);
                resultTagContent.add(tempTag);
                resultTagContent = sourceContent;
            }
            return null;
        } else {
            // if the tag name is the same as the tag on top of the stack,
            // attach the tag contents to the closest tag of the same type
            // i.e : <b> test1 <b>test2</b> test3</b>
            // would result in something like
            // <b1> test1 <b2>test2</b2> test3</b1>
            // and NOT
            // <b1> test1 <b2test2</b1> test3</b2>
            this.tagNameStack.pop();
            this.tagStack.peek().setContent(this.tagContentStack.pop());
            return this.tagStack.pop();
        }
    }
}
