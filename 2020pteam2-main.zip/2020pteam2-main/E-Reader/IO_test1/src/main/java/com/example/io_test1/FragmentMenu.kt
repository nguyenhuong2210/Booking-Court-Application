package com.example.io_test1

import android.app.Activity.RESULT_OK
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.fragment.app.Fragment
import com.example.io_test1.CustomXMLParser.CustomBookType.CustomBook
import org.antlr.v4.runtime.misc.ParseCancellationException
import java.io.FileInputStream
import java.io.IOException


class FragmentMenu: Fragment() {
    private val FILE_SELECT_CODE = 111

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.layout_menu, container, false)

        // Bind listeners
        val browse = view?.findViewById<View>(R.id.buttonBrowse)
        browse?.setOnClickListener {onClick(browse)}

        val test = view?.findViewById<View>(R.id.buttonTest)
        test?.setOnClickListener {onClick(test)}

        if (GlobalVariables.globalObjects.get(GlobalVariables.DISPLAY) != null){
            //parentFragmentManager.popBackStack()
            showFragment(GlobalVariables.globalObjects.get(GlobalVariables.DISPLAY) as Fragment);
        }

        return view
    }


    private fun onClick(_view : View) {
        when(_view.id){
            R.id.buttonBrowse -> {
                //showFragment(FragmentBrowse())
                val test = view?.findViewById<EditText>(R.id.textFilepath)
                test?.setText("")

                // old: make sure only certain extensions are selectable
                // after note: not possible, only general type is able to be set
                val intent = Intent()
                intent.setType("text/*")
                intent.setAction(Intent.ACTION_GET_CONTENT)
                intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(Intent.createChooser(intent, "Select a file"), FILE_SELECT_CODE)
            }
            R.id.buttonTest -> {
                showAlert("test")
//                val intent = Intent()
//                    .setType("*/*")
//                    .setAction(Intent.ACTION_CREATE_DOCUMENT)
//                startActivityForResult(Intent.createChooser(intent, "Create a file"), 112)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == FILE_SELECT_CODE && resultCode == RESULT_OK) {
            val uri = data?.data
//            val path = uri?.path

            try {
                if (uri == null) throw IOException()

                // get file name from uri
                // ref:
                // https://developer.android.com/training/secure-file-sharing/retrieve-info.html
                val cursor =
                    context!!.contentResolver.query(uri, null, null, null, null)
                /*
             * Get the column indexes of the data in the Cursor,
             * move to the first row in the Cursor, get the data,
             * and display it.
             */
                /*
             * Get the column indexes of the data in the Cursor,
             * move to the first row in the Cursor, get the data,
             * and display it.
             */
                val nameIndex = cursor!!.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                cursor.moveToFirst()
                GlobalVariables.globalObjects.put(GlobalVariables.FILENAME, cursor.getString(nameIndex))
                cursor.close()

                val pfd =
                    context!!.contentResolver.openFileDescriptor(uri, "r")
                val fileDescriptor = pfd!!.fileDescriptor
                val fileStream = FileInputStream(fileDescriptor)

                val book = CustomBook()
                book.createBook(fileStream)

                GlobalVariables.globalObjects.put(GlobalVariables.BOOK, book)

                fileStream.close()
                pfd.close()

                val fragment = FragmentDisplay()
                showFragment(fragment)
            } catch (e: ParseCancellationException){
                showAlert("Can't open file. Please re-check file content.");
                e.printStackTrace();
            } catch (e: IOException){
                showAlert("Can't open file. Please re-check file or directory.");
                e.printStackTrace();
            }
        }
    }

    private fun showAlert(msg: String){
        val alert = AlertDialog.Builder(context)
        alert.setMessage(msg)
        alert.setNegativeButton(R.string.cancel) { dialogInterface: DialogInterface, i: Int -> dialogInterface.dismiss()}
        alert.show()
    }

    private fun showFragment(_fragment : Fragment){
        val transaction = parentFragmentManager.beginTransaction()
        transaction.replace(R.id.fragment_holder, _fragment)
        transaction.addToBackStack(null)
        transaction.commit()
    }
}