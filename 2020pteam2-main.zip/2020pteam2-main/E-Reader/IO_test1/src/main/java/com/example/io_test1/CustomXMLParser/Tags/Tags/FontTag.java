package com.example.io_test1.CustomXMLParser.Tags.Tags;

import com.example.io_test1.CustomXMLParser.Attributes.AttributeBase;
import com.example.io_test1.CustomXMLParser.CustomBookType.IBookVisitor;
import com.example.io_test1.CustomXMLParser.Tags.ITagVisitor;
import com.example.io_test1.CustomXMLParser.Tags.TagBase;

public class FontTag extends TagBase {
    public static final String SIZE = "size", FONT_TYPE = "type";
    private float size = 30;
    private String fontType = "placeholder";

    @Override
    public void addAttribute(AttributeBase attribute) {
        switch (attribute.getName()){
            case SIZE:
                try {
                    this.size = Float.parseFloat(attribute.getValue().replace("\"", ""));
                } catch (NumberFormatException e){
                    e.printStackTrace();
                }
                break;
            case FONT_TYPE:
                this.fontType = attribute.getValue().replace("\"", "");
                break;
            default:
                break;
        }
    }

    @Override
    public String getName() {
        return "font";
    }

    public float getSize() {
        return size;
    }

    public String getFontType() {
        return this.fontType;
    }

    @Override
    public <ReturnType> ReturnType accept(ITagVisitor<ReturnType> tagVisitor) {
        return tagVisitor.visitTag(this);
    }

    @Override
    public CharSequence getRawText() {
        StringBuilder result = new StringBuilder();
        result.append("<");
        result.append(getName());

        result.append(" ");

        result.append(SIZE);
        result.append("=");
        result.append("\"");
        result.append(this.size);
        result.append("\"");

        result.append(" ");

        result.append(FONT_TYPE);
        result.append("=");
        result.append("\"");
        result.append(this.fontType);
        result.append("\"");

        result.append(">");

        result.append(this.content.getRawText());

        result.append("</");
        result.append(getName());
        result.append(">");

        return result;
    }

    @Override
    public CharSequence getDisplayText() {
        return "";
    }

    @Override
    public <ReturnType, VisitorType extends IBookVisitor<ReturnType>> ReturnType accept(VisitorType bookVisitor) {
        return bookVisitor.visitTag(this);
    }
}
