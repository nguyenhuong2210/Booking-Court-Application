package com.example.io_test1.CustomXMLParser.CustomBookType;

import java.util.ArrayList;

public class PageHighlighter {
    private ArrayList<CustomPage> pages;
    private boolean highlightToggle = true;
    private boolean highlight = true;

    public PageHighlighter(){
        this.pages = new ArrayList<>();
    }

    public void addPage(CustomPage page){
        this.pages.add(page);
    }

    public void setHighlight(boolean highlight) {
        this.highlight = highlight;
    }

    public void setHighlightToggle(boolean highlightToggle) {
        this.highlightToggle = highlightToggle;
    }

    public void setHighlightPage(){
        for (CustomPage page : this.pages){
            highlightPage(page);
        }
    }

    private void highlightPage(CustomPage page){
        BookSection sourceSection = page.getSourceSection();
        int splitStart = -1;
        int splitEnd = Integer.MAX_VALUE;
        int splitTagStart = -1;
        int splitTagEnd = Integer.MAX_VALUE;
        int startSelection = page.getTempSelectStart();
        int endSelection = page.getTempSelectEnd();
        int displayLength = page.getDisplayLength();
        StringBuilder stringBuilder = new StringBuilder();
        int startIndex = page.getStartIndex();
        int endIndex = page.getEndIndex();

        // relative position counting from the end
        int relativeEndSelect = displayLength - endSelection;
        int relativeStartSelect = displayLength - startSelection - 1;

        boolean trimmedEnd = false;
        boolean foundStartElement = false;
        boolean foundEndElement = false;

        // try to calculate the raw text position from the page position
        for (int i = endIndex; i >= startIndex; i--){
            IBookElement element =  sourceSection.getElement(i);
            stringBuilder.insert(0, element.getDisplayText());
            if (!trimmedEnd && stringBuilder.length() >= page.getExcessLength()){
                stringBuilder.delete(stringBuilder.length() - page.getExcessLength(), stringBuilder.length());
                trimmedEnd = true;
            }
            if (trimmedEnd){
                if (!foundStartElement && (relativeStartSelect < stringBuilder.length())) {
                    element = sourceSection.getElement(i);
                    splitTagStart = i;
                    splitStart =
                            element.getRawContentStartIndex()
                                    + stringBuilder.length()
                                    - relativeStartSelect - 1;
                    foundStartElement = true;
                }

                if (!foundEndElement && (relativeEndSelect < stringBuilder.length())) {
                    element =  sourceSection.getElement(i);
                    splitTagEnd = i;
                    splitEnd =
                            element.getRawContentStartIndex()
                                    + stringBuilder.length()
                                    - relativeEndSelect;
                    foundEndElement = true;
                }

                if (foundStartElement && foundEndElement){
                    break;
                }
            }
        }

        if (foundStartElement && foundEndElement){
            BookElementSplitVisitor splitVisitor = new BookElementSplitVisitor(splitStart, splitEnd);
            BookHighlightVisitor highlightVisitor = new BookHighlightVisitor(splitStart, splitEnd);

            if (this.highlightToggle){
                highlightVisitor.setAlwaysHighlight(false);
                highlightVisitor.setHighlight(true);
            } else {
                highlightVisitor.setHighlight(this.highlight);
                highlightVisitor.setAlwaysHighlight(this.highlight);
            }

            IBookElement element;
            for (int i = splitTagStart; i <= splitTagEnd; i++){
                element = splitVisitor.visit(sourceSection.getElement(i));
                element = highlightVisitor.visit(element);
                sourceSection.setElements(i, element);
            }
        }
        return;
    }
}
