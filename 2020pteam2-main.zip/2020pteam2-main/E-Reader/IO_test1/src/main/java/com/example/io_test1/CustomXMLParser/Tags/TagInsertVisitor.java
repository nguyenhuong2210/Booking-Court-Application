package com.example.io_test1.CustomXMLParser.Tags;

import com.example.io_test1.CustomXMLParser.Tags.Tags.CompoundTagContent;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTagContent;

public class TagInsertVisitor extends TagVisitorBase {
    private int indexBefore;
    private boolean inserted = false;
    private ITagContent insertContent;

    public TagInsertVisitor(){
    }

    public ITagContent insertTag(ITagContent tagContent, ITagContent tagInsert, int beforeIndex) {
        // note: this can potentially significantly slow the app down
        // because each time something is inserted, it creates a nested compound object
        this.inserted = false;
        this.insertContent = tagInsert;
        this.indexBefore = beforeIndex;
        ITagContent result = visit(tagContent);
        return result;
    }

    public void setInserted(boolean inserted) {
        this.inserted = inserted;
    }

    public boolean isInserted() {
        return inserted;
    }

    private ITagContent insertBefore(ITagContent tagContent){
        CompoundTagContent result = new CompoundTagContent();
        result.add(this.insertContent);
        result.add(tagContent);
        this.inserted = true;
        return result;
    }

    @Override
    protected ITagContent visitChildTags(TagBase tag){
        if (this.inserted){
            return tag;
        } else if (tag.getRawContentStartIndex() >= this.indexBefore){
            return insertBefore(tag);
        }

        CompoundTagContent result = visitTagIterator(tag.getContent().getIterator());

        if (result.getSize() == 1){
            tag.setContent(result.getContentAt(0));
        } else if (result.getSize() > 1) {
            tag.setContent(result);
        }

        return tag;
    }

    @Override
    public ITagContent visitTag(SimpleTagContent tag) {
        if (this.inserted){
            return tag;
        } else if (tag.getRawContentStartIndex() >= this.indexBefore){
            return insertBefore(tag);
        } else {
            return tag;
        }
    }
}
