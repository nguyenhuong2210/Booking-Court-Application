package com.example.io_test1.CustomXMLParser.Tags.Tags;

import com.example.io_test1.CustomXMLParser.Attributes.AttributeBase;
import com.example.io_test1.CustomXMLParser.CustomBookType.IBookVisitor;
import com.example.io_test1.CustomXMLParser.Tags.ITagVisitor;
import com.example.io_test1.CustomXMLParser.Tags.TagBase;

public class ChapterTag extends TagBase {
    @Override
    public void addAttribute(AttributeBase attribute) {

    }

    @Override
    public String getName() {
        return "chapter";
    }

    @Override
    public CharSequence getDisplayText() {
        return this.content.getDisplayText();
    }

    @Override
    public <ReturnType> ReturnType accept(ITagVisitor<ReturnType> tagVisitor) {
        return tagVisitor.visitTag(this);
    }

    @Override
    public <ReturnType, VisitorType extends IBookVisitor<ReturnType>> ReturnType accept(VisitorType bookVisitor) {
        return bookVisitor.visitTag(this);
    }
}
