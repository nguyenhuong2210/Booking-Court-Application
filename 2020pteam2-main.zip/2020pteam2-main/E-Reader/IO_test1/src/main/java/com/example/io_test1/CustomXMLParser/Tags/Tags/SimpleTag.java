package com.example.io_test1.CustomXMLParser.Tags.Tags;

import com.example.io_test1.CustomXMLParser.Attributes.AttributeBase;
import com.example.io_test1.CustomXMLParser.CustomBookType.IBookVisitor;
import com.example.io_test1.CustomXMLParser.Tags.ITagVisitor;
import com.example.io_test1.CustomXMLParser.Tags.TagBase;

import java.util.ArrayList;

public class SimpleTag extends TagBase {
    protected String name;
    protected ArrayList<AttributeBase> attributes;

    public SimpleTag(String _name) {
        this.name = _name;
        this.attributes = new ArrayList<>();
    }

    public void setName(String _name){
        this.name = _name;
    }

    @Override
    public String getName(){
        return this.name;
    }

    @Override
    public void addAttribute(AttributeBase attribute) {
        this.attributes.add(attribute);
    }

    @Override
    public CharSequence getDisplayText() {
        return this.content.getDisplayText();
    }

    @Override
    public <ReturnType> ReturnType accept(ITagVisitor<ReturnType> tagVisitor) {
        return tagVisitor.visitTag(this);
    }

    @Override
    public CharSequence getRawText() {
        StringBuilder result = new StringBuilder();
        result.append("<");
        result.append(getName());
        for (AttributeBase attr: this.attributes) {
            result.append(" ");
            result.append(attr.getName());
            result.append("=");
            result.append("\"");
            result.append(attr.getValue());
            result.append("\"");
        }
        result.append(">");

        result.append(this.content.getRawText());

        result.append("</");
        result.append(getName());
        result.append(">");

        return result;
    }

    @Override
    public <ReturnType, VisitorType extends IBookVisitor<ReturnType>> ReturnType accept(VisitorType bookVisitor) {
        return bookVisitor.visitTag(this);
    }

    @Override
    public TagBase shallowCopy() {
        SimpleTag result = (SimpleTag) super.shallowCopy();
        result.attributes = new ArrayList<>();
        return result;
    }
}
