package com.example.io_test1.CustomXMLParser.CustomBookType;

import com.example.io_test1.CustomXMLParser.Tags.ITagContent;
import com.example.io_test1.CustomXMLParser.Tags.TagContentSplitVisitor;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BoldTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BookTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BookmarkTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.ChapterTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.CompoundTagContent;
import com.example.io_test1.CustomXMLParser.Tags.Tags.FontTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.HighlightTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.ItalicTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.PagebreakTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTagContent;

public class BookElementSplitVisitor implements IBookVisitor<IBookElement> {
    private int splitStart, splitEnd;
    private TagContentSplitVisitor tagContentSplitter;

    public BookElementSplitVisitor(int start, int end){
        this.splitStart = start;
        this.splitEnd = end;
        this.tagContentSplitter = new TagContentSplitVisitor(start, end);
    }

    public void setSplitStart(int splitStart) {
        this.splitStart = splitStart;
        this.tagContentSplitter.setSplitStart(splitStart);
    }

    public void setSplitEnd(int splitEnd) {
        this.splitEnd = splitEnd;
        this.tagContentSplitter.setSplitEnd(splitEnd);
    }

    @Override
    public IBookElement visit(IBookElement element) {
        return element.accept(this);
    }

    @Override
    public IBookElement visit(ITagContent tagContent) {
        return tagContent.accept(this);
    }

    @Override
    public IBookElement visitElement(BookSection bookSection) {
        for (int i = 0; i < bookSection.getElementsCount(); i++){
            IBookElement element = bookSection.getElement(i);
            bookSection.setElements(i, visit(element));
        }
        return bookSection;
    }

    @Override
    public IBookElement visitElement(BookChapter bookChapter) {
        for (int i = 0; i < bookChapter.getElementsCount(); i++){
            IBookElement element = bookChapter.getElement(i);
            bookChapter.setElements(i, visit(element));
        }
        return bookChapter;
    }

    @Override
    public IBookElement visitElement(CompoundBookElement bookElement) {
        for (int i = 0; i < bookElement.getElementsCount(); i++){
            IBookElement element = bookElement.getElement(i);
            bookElement.setElements(i, visit(element));
        }
        return bookElement;
    }

    @Override
    public ITagContent visitTag(CompoundTagContent tag) {
        return this.tagContentSplitter.visitTag(tag);
    }

    @Override
    public ITagContent visitTag(SimpleTagContent tag) {
        return this.tagContentSplitter.visitTag(tag);
    }

    @Override
    public ITagContent visitTag(SimpleTag tag) {
        return this.tagContentSplitter.visitTag(tag);
    }

    @Override
    public ITagContent visitTag(BookTag tag) {
        return this.tagContentSplitter.visitTag(tag);
    }

    @Override
    public ITagContent visitTag(ChapterTag tag) {
        return this.tagContentSplitter.visitTag(tag);
    }

    @Override
    public ITagContent visitTag(BoldTag tag) {
        return this.tagContentSplitter.visitTag(tag);
    }

    @Override
    public ITagContent visitTag(ItalicTag tag) {
        return this.tagContentSplitter.visitTag(tag);
    }

    @Override
    public ITagContent visitTag(HighlightTag tag) {
        return this.tagContentSplitter.visitTag(tag);
    }

    @Override
    public ITagContent visitTag(BookmarkTag tag) {
        return this.tagContentSplitter.visitTag(tag);
    }

    @Override
    public ITagContent visitTag(PagebreakTag tag) {
        return this.tagContentSplitter.visitTag(tag);
    }

    @Override
    public IBookElement visitTag(FontTag tag) {
        return this.tagContentSplitter.visitTag(tag);
    }
}
