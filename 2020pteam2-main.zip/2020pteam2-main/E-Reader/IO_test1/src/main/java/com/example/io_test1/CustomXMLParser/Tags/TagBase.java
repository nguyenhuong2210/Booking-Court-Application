package com.example.io_test1.CustomXMLParser.Tags;

import com.example.io_test1.CustomXMLParser.Attributes.AttributeBase;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTagContent;

import java.util.Collections;
import java.util.Iterator;

public abstract class TagBase implements ITagContent, Cloneable {
    protected ITagContent content;
    // kinda lazy way to "delete" tag
    public boolean isDeleted = false;

    public TagBase(){
        this.content = new SimpleTagContent("");
    }

    public abstract void addAttribute(AttributeBase attribute);

    public void setContent(ITagContent _content){
        this.content = _content;
    }

    public abstract String getName();

    @Override
    public String getText() {
        return this.content.getText();
    }

    @Override
    public CharSequence getRawText() {
        String name = getName();
        StringBuilder result = new StringBuilder();
        result.append("<");
        result.append(name);
        result.append(">");

        result.append(this.content.getRawText());

        result.append("</");
        result.append(name);
        result.append(">");

        return result;
    }

    @Override
    public Iterator<ITagContent> getIterator() {
        return Collections.singleton((ITagContent)this).iterator();
    }

    @Override
    public ITagContent getContent(){
        return this.content;
    }


    @Override
    protected Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public TagBase shallowCopy()  {
        // should copy of the attributes of the tags
        // the same reference to the content
        // which should probably be set again for the clone
        // to point to a new content
        return (TagBase)clone();
    }

    @Override
    public void reload() {
        // do nothing
    }

    @Override
    public int getRawContentStartIndex() {
        return this.content.getRawContentStartIndex();
    }

    @Override
    public int getRawContentEndIndex() {
        return this.content.getRawContentEndIndex();
    }
}
