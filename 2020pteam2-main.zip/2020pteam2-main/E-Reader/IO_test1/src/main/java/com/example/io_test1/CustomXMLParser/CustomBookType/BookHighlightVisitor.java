package com.example.io_test1.CustomXMLParser.CustomBookType;

import com.example.io_test1.CustomXMLParser.Tags.ITagContent;
import com.example.io_test1.CustomXMLParser.Tags.TagHighlightVisitor;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BoldTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BookTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BookmarkTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.ChapterTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.CompoundTagContent;
import com.example.io_test1.CustomXMLParser.Tags.Tags.FontTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.HighlightTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.ItalicTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.PagebreakTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTagContent;

public class BookHighlightVisitor implements IBookVisitor<IBookElement> {
    private int highlightStart, highlightEnd;
    private boolean highlight, alwaysHighlight;
    private TagHighlightVisitor tagHighlightVisitor;

    public BookHighlightVisitor(int start, int end){
        this.highlight = true;
        this.alwaysHighlight = false;
        this.highlightStart = start;
        this.highlightEnd = end;
        this.tagHighlightVisitor = new TagHighlightVisitor();
    }

    public void setHighlight(boolean highlight) {
        this.highlight = highlight;
    }

    public void setAlwaysHighlight(boolean alwaysHighlight) {
        this.alwaysHighlight = alwaysHighlight;
        this.tagHighlightVisitor.setAlwaysHighlight(this.alwaysHighlight);
    }

    public void setHighlightStart(int highlightStart) {
        this.highlightStart = highlightStart;
        this.tagHighlightVisitor.setHighlightStart(highlightStart);
    }

    public void setHighlightEnd(int highlightEnd) {
        this.highlightEnd = highlightEnd;
        this.tagHighlightVisitor.setHighlightEnd(highlightEnd);
    }

    @Override
    public IBookElement visit(IBookElement element) {
        return element.accept(this);
    }

    private IBookElement visitCompoundBookElement(CompoundBookElement bookElement){
        // should probably include a check if it actually needs to be visited
        for (int i = 0; i < bookElement.getElementsCount(); i++){
            IBookElement element = bookElement.getElement(i);
            bookElement.setElements(i, visit(element));
        }
        return bookElement;
    }

    @Override
    public IBookElement visitElement(BookSection bookSection) {
        return visitCompoundBookElement(bookSection);
    }

    @Override
    public IBookElement visitElement(BookChapter bookChapter) {
        return visitCompoundBookElement(bookChapter);
    }

    @Override
    public IBookElement visitElement(CompoundBookElement bookElement) {
        return visitCompoundBookElement(bookElement);
    }

    @Override
    public IBookElement visit(ITagContent tagContent) {
        return tagContent.accept(this);
    }

    @Override
    public IBookElement visitTag(CompoundTagContent tag) {
        return this.tagHighlightVisitor.setHighlight(tag, this.highlight, this.highlightStart, this.highlightEnd);
    }

    @Override
    public IBookElement visitTag(SimpleTagContent tag) {
        return this.tagHighlightVisitor.setHighlight(tag, this.highlight, this.highlightStart, this.highlightEnd);
    }

    @Override
    public IBookElement visitTag(SimpleTag tag) {
        return this.tagHighlightVisitor.setHighlight(tag, this.highlight, this.highlightStart, this.highlightEnd);
    }

    @Override
    public IBookElement visitTag(BookTag tag) {
        return this.tagHighlightVisitor.setHighlight(tag, this.highlight, this.highlightStart, this.highlightEnd);
    }

    @Override
    public IBookElement visitTag(ChapterTag tag) {
        return this.tagHighlightVisitor.setHighlight(tag, this.highlight, this.highlightStart, this.highlightEnd);
    }

    @Override
    public IBookElement visitTag(BoldTag tag) {
        return this.tagHighlightVisitor.setHighlight(tag, this.highlight, this.highlightStart, this.highlightEnd);
    }

    @Override
    public IBookElement visitTag(ItalicTag tag) {
        return this.tagHighlightVisitor.setHighlight(tag, this.highlight, this.highlightStart, this.highlightEnd);
    }

    @Override
    public IBookElement visitTag(HighlightTag tag) {
        return this.tagHighlightVisitor.setHighlight(tag, this.highlight, this.highlightStart, this.highlightEnd);
    }

    @Override
    public IBookElement visitTag(BookmarkTag tag) {
        return this.tagHighlightVisitor.setHighlight(tag, this.highlight, this.highlightStart, this.highlightEnd);
    }

    @Override
    public IBookElement visitTag(PagebreakTag tag) {
        return this.tagHighlightVisitor.setHighlight(tag, this.highlight, this.highlightStart, this.highlightEnd);
    }

    @Override
    public IBookElement visitTag(FontTag tag) {
        return this.tagHighlightVisitor.setHighlight(tag, this.highlight, this.highlightStart, this.highlightEnd);
    }
}
