package com.example.io_test1;

import android.text.Layout;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.io_test1.CustomXMLParser.CustomBookType.CustomBook;
import com.example.io_test1.CustomXMLParser.CustomBookType.CustomPage;

public class CustomPageHolder extends RecyclerView.ViewHolder implements View.OnTouchListener {
    protected IPageClickListener listener;
    private int adapterPos;

    public CustomPageHolder(@NonNull View itemView, IPageClickListener _listener) {
        super(itemView);
        this.listener = _listener;
    }

    public void bindItem(CustomBook book){
        this.adapterPos = getAdapterPosition();
        TextView pageDisplay = this.itemView.findViewById(R.id.pageContent);
        CustomPage page = book.tryGetPage(getAdapterPosition());
        pageDisplay.setWidth(book.pageWidth);
        pageDisplay.setHeight(book.pageHeight);
        if (page != null){
            CharSequence pageContent = page.getDisplayText();
            pageDisplay.setTypeface(book.textPaint.getTypeface());
            // why is there a difference between textView's text size and its textPaint's text size ??
            pageDisplay.getPaint().setTextSize(book.textPaint.getTextSize());

            pageDisplay.setTextIsSelectable(false);
            pageDisplay.setText(pageContent);
            pageDisplay.setOnTouchListener(this);
            this.itemView.setVisibility(View.VISIBLE);
        } else {
            this.itemView.setVisibility(View.INVISIBLE);
        }

    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            TextView textView = (TextView) v;
            int x = (int)event.getX();
            int y = (int)event.getY();
            int offset = getCharacterOffset(textView, x, y);
            // getAdapterPosition returns -1 for action move
            // probably because it's called too fast in succession
            // saving the value to a variable and call it instead to be safe
            this.listener.pageClicked(v, this.adapterPos, offset);
        }
        return true;
    }


    // ref:
    // https://stackoverflow.com/questions/2302867/android-how-to-determine-character-index-of-a-touch-events-position-in-textvie
    private static int getCharacterOffset(TextView textView, int x, int y) {
        x += textView.getScrollX() - textView.getTotalPaddingLeft();
        y += textView.getScrollY() - textView.getTotalPaddingTop();

        final Layout layout = textView.getLayout();

        final int lineCount = layout.getLineCount();
        if (lineCount == 0 || y < layout.getLineTop(0) || y >= layout.getLineBottom(lineCount - 1))
            return -1;

        final int line = layout.getLineForVertical(y);
        if (x < layout.getLineLeft(line) || x >= layout.getLineRight(line))
            return -1;

        int start = layout.getLineStart(line);
        int end = layout.getLineEnd(line);

        while (end > start + 1) {
            int middle = start + (end - start) / 2;

            if (x >= layout.getPrimaryHorizontal(middle)) {
                start = middle;
            }
            else {
                end = middle;
            }
        }

        return start;
    }
}