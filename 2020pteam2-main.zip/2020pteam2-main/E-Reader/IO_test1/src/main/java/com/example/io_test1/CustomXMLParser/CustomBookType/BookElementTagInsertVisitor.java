package com.example.io_test1.CustomXMLParser.CustomBookType;

import com.example.io_test1.CustomXMLParser.Tags.ITagContent;
import com.example.io_test1.CustomXMLParser.Tags.TagInsertVisitor;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BoldTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BookTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.BookmarkTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.ChapterTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.CompoundTagContent;
import com.example.io_test1.CustomXMLParser.Tags.Tags.FontTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.HighlightTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.ItalicTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.PagebreakTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTag;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTagContent;

public class BookElementTagInsertVisitor implements IBookVisitor<IBookElement> {
    private int indexBefore;
    private ITagContent insertContent;
    private TagInsertVisitor tagInsertVisitor;

    public BookElementTagInsertVisitor(){
        this.tagInsertVisitor = new TagInsertVisitor();
    }

    public IBookElement insertTag(IBookElement element, ITagContent tagInsert, int beforeIndex) {
        this.tagInsertVisitor.setInserted(false);
        this.insertContent = tagInsert;
        this.indexBefore = beforeIndex;
        return visit(element);
    }

    @Override
    public IBookElement visit(IBookElement element) {
        return element.accept(this);
    }

    private IBookElement visitCompoundBookElement(CompoundBookElement bookElement){
        if (!this.tagInsertVisitor.isInserted()) {
            for (int i = 0; i < bookElement.getElementsCount(); i++){
                IBookElement element = bookElement.getElement(i);
                bookElement.setElements(i, visit(element));
            }
        }

        return bookElement;
    }

    @Override
    public IBookElement visitElement(BookSection bookSection) {
        return visitCompoundBookElement(bookSection);
    }

    @Override
    public IBookElement visitElement(BookChapter bookChapter) {
        return visitCompoundBookElement(bookChapter);
    }

    @Override
    public IBookElement visitElement(CompoundBookElement bookElement) {
        return visitCompoundBookElement(bookElement);
    }

    @Override
    public IBookElement visit(ITagContent tagContent) {
        return tagContent.accept(this);
    }

    @Override
    public IBookElement visitTag(CompoundTagContent tag) {
        return this.tagInsertVisitor.insertTag(tag, this.insertContent, this.indexBefore);
    }

    @Override
    public IBookElement visitTag(SimpleTagContent tag) {
        return this.tagInsertVisitor.insertTag(tag, this.insertContent, this.indexBefore);
    }

    @Override
    public IBookElement visitTag(SimpleTag tag) {
        return this.tagInsertVisitor.insertTag(tag, this.insertContent, this.indexBefore);
    }

    @Override
    public IBookElement visitTag(BookTag tag) {
        return this.tagInsertVisitor.insertTag(tag, this.insertContent, this.indexBefore);
    }

    @Override
    public IBookElement visitTag(ChapterTag tag) {
        return this.tagInsertVisitor.insertTag(tag, this.insertContent, this.indexBefore);
    }

    @Override
    public IBookElement visitTag(BoldTag tag) {
        return this.tagInsertVisitor.insertTag(tag, this.insertContent, this.indexBefore);
    }

    @Override
    public IBookElement visitTag(ItalicTag tag) {
        return this.tagInsertVisitor.insertTag(tag, this.insertContent, this.indexBefore);
    }

    @Override
    public IBookElement visitTag(HighlightTag tag) {
        return this.tagInsertVisitor.insertTag(tag, this.insertContent, this.indexBefore);
    }

    @Override
    public IBookElement visitTag(BookmarkTag tag) {
        return this.tagInsertVisitor.insertTag(tag, this.insertContent, this.indexBefore);
    }

    @Override
    public IBookElement visitTag(PagebreakTag tag) {
        return this.tagInsertVisitor.insertTag(tag, this.insertContent, this.indexBefore);
    }

    @Override
    public IBookElement visitTag(FontTag tag) {
        return this.tagInsertVisitor.insertTag(tag, this.insertContent, this.indexBefore);
    }
}
