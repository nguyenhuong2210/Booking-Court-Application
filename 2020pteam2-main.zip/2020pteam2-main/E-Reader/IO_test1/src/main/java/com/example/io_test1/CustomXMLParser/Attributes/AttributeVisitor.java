package com.example.io_test1.CustomXMLParser.Attributes;


import com.example.io_test1.CustomXMLParser.Generated.XMLParser;
import com.example.io_test1.CustomXMLParser.Generated.XMLParserBaseVisitor;

public class AttributeVisitor extends XMLParserBaseVisitor<AttributeBase> {
    @Override
    public AttributeBase visitAttribute(XMLParser.AttributeContext ctx) {
        AttributeBase attribute = new AttributeBase(ctx.Name().getText(), ctx.STRING().getText());
        return attribute;
    }
}
