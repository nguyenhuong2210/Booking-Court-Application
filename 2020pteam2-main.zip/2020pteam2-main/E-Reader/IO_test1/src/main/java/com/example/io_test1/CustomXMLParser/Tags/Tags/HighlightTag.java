package com.example.io_test1.CustomXMLParser.Tags.Tags;

import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;

import com.example.io_test1.CustomXMLParser.Attributes.AttributeBase;
import com.example.io_test1.CustomXMLParser.CustomBookType.IBookVisitor;
import com.example.io_test1.CustomXMLParser.Tags.ITagVisitor;
import com.example.io_test1.CustomXMLParser.Tags.TagBase;

public class HighlightTag extends TagBase {
    @Override
    public void addAttribute(AttributeBase attribute) {

    }

    @Override
    public String getName() {
        return "h";
    }

    @Override
    public CharSequence getDisplayText() {
        SpannableStringBuilder stringBuilder = new SpannableStringBuilder();
        stringBuilder.append(this.content.getDisplayText());
        // placeholder color
        // TODO: get color from attribute
        stringBuilder.setSpan(
                new BackgroundColorSpan(0xFFFFFF00),
                0, stringBuilder.length(),
                Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        return stringBuilder;
    }

    @Override
    public <ReturnType> ReturnType accept(ITagVisitor<ReturnType> tagVisitor) {
        return tagVisitor.visitTag(this);
    }

    @Override
    public <ReturnType, VisitorType extends IBookVisitor<ReturnType>> ReturnType accept(VisitorType bookVisitor) {
        return bookVisitor.visitTag(this);
    }
}
