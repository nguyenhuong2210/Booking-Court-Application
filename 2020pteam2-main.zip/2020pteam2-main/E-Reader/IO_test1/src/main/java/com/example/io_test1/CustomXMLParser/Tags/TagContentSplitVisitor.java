package com.example.io_test1.CustomXMLParser.Tags;

import com.example.io_test1.CustomXMLParser.Tags.ITagContent;
import com.example.io_test1.CustomXMLParser.Tags.TagBase;
import com.example.io_test1.CustomXMLParser.Tags.TagSplitVisitor;
import com.example.io_test1.CustomXMLParser.Tags.Tags.CompoundTagContent;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTagContent;

public class TagContentSplitVisitor extends TagSplitVisitor {
    // Split tag from position into 2 tags
    // i.e: <b>0123456</b>
    // split at -1 or bigger than the last index: return the tag again
    // split at 0: return the tag again
    // split at 1: return <b>0</b> and <b>123456/b>
    // split at 6: return <b>012345</b> and <b>6</b>
    private int splitStart, splitEnd;

    public TagContentSplitVisitor(int start, int end){
        this.splitStart = start;
        this.splitEnd = end;
    }

    public void setSplitStart(int splitStart) {
        this.splitStart = splitStart;
    }

    public void setSplitEnd(int splitEnd) {
        this.splitEnd = splitEnd;
    }

    protected SimpleTagContent[] splitTagAtPosition(SimpleTagContent simpleTagContent, int position){
        if (position > simpleTagContent.getRawContentStartIndex() && position <= simpleTagContent.getRawContentEndIndex()) {
            SimpleTagContent[] result = new SimpleTagContent[2];
            CharSequence text1, text2, content;
            int
                    relativeSplitPos = position - simpleTagContent.getRawContentStartIndex(),
                    length = simpleTagContent.getRawContentEndIndex() - simpleTagContent.getRawContentStartIndex() + 1;

            content = simpleTagContent.getText();
            text1 = content.subSequence(0, relativeSplitPos);
            text2 = content.subSequence(relativeSplitPos, length);

            result[0] = new SimpleTagContent(text1, simpleTagContent.getRawContentStartIndex(), position - 1);
            result[1] = new SimpleTagContent(text2, position, simpleTagContent.getRawContentEndIndex());
            return result;
        } else {
            SimpleTagContent[] result = new SimpleTagContent[1];
            result[0] = simpleTagContent;
            return result;
        }

    }

    @Override
    protected ITagContent visitChildTags(TagBase tag) {
        // not a necessary check but it'd be better for performance
        if (tag.getRawContentStartIndex() < this.splitEnd && tag.getRawContentEndIndex() >= this.splitStart)
        {
            return super.visitChildTags(tag);
        } else {
            return tag;
        }
    }

    @Override
    public ITagContent visitTag(SimpleTagContent tag) {
        if (tag.getRawContentStartIndex() < this.splitEnd && tag.getRawContentEndIndex() >= this.splitStart){
            CompoundTagContent compoundTagContent = new CompoundTagContent();
            for (SimpleTagContent content: splitTagAtPosition(tag, this.splitEnd)){
                for (SimpleTagContent inner: splitTagAtPosition(content, this.splitStart)){
                    compoundTagContent.add(inner);
                }
            }
            if (compoundTagContent.getSize() > 1) {
                return compoundTagContent;
            } else {
                return tag;
            }

        } else {
            return tag;
        }
    }
}
