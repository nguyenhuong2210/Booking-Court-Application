package com.example.io_test1.CustomXMLParser.CustomBookType;

import com.example.io_test1.CustomXMLParser.Tags.ITagVisitor;

public interface IBookVisitor<ReturnType> extends ITagVisitor<ReturnType> {
    ReturnType visit(IBookElement element);
    ReturnType visitElement(BookSection bookSection);
    ReturnType visitElement(BookChapter bookChapter);
    ReturnType visitElement(CompoundBookElement bookElement);
}
