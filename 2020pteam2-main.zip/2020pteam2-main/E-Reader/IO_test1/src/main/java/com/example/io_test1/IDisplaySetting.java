package com.example.io_test1;

import android.graphics.Typeface;

import com.example.io_test1.CustomXMLParser.CustomBookType.CustomBookLabel;

import java.util.HashMap;

public interface IDisplaySetting {
    int getCurrentPage();
    void pageJump(int pageNumber);
    void bookLabelJump(CustomBookLabel label);
    void setBookmark(CharSequence name);
    void deleteBookmark(CustomBookLabel bookLabel);
    void saveAs();
    void setTextSize(float size);
    void setTypeFace(String fontName);
    HashMap<String, Typeface> getFontDict();
    void selectStart(boolean state);
    void selectEnd(boolean state);
    void selectCancel();
    void copySelected();
    void highlightSelected();
    void unhighlightSelected();
}