package com.example.io_test1;

import android.graphics.Typeface;
import android.text.SpannableStringBuilder;
import android.text.style.BackgroundColorSpan;
import android.text.style.StyleSpan;
import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.io_test1.CustomXMLParser.Tags.BoldTag;
import com.example.io_test1.CustomXMLParser.Tags.CompoundTagContent;
import com.example.io_test1.CustomXMLParser.Tags.HighlightTag;
import com.example.io_test1.CustomXMLParser.Tags.ITagContent;
import com.example.io_test1.CustomXMLParser.Tags.ItalicTag;
import com.example.io_test1.CustomXMLParser.Tags.SimpleTagContent;
import com.example.io_test1.CustomXMLParser.Tags.TagBase;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class ItalicTagTest {
    // <i>flamingo</i>
    @Test
    public void getDisplayTextTest1(){
        ITagContent simpleTagContent = new SimpleTagContent("flamingo",3,11);
        TagBase italicTag = new ItalicTag();
        italicTag.setContent(simpleTagContent);
        CharSequence c = italicTag.getDisplayText();
        checkSubSpanString(c,0,c.length(),false,true,false,"flamingo");
    }

    // <i>fla<b>min</b>go</i>
    @Test
    public void getDisplayTextTest2(){
        ITagContent simpleTagContent1 = new SimpleTagContent("min",9,12);
        ITagContent simpleTagContent2 = new SimpleTagContent("fla",3,6);
        ITagContent simpleTagContent3 = new SimpleTagContent("go",16,18);
        TagBase boldTag1 = new BoldTag();
        boldTag1.setContent(simpleTagContent1);
        CompoundTagContent compoundTagContent = new CompoundTagContent();
        compoundTagContent.add(simpleTagContent2);
        compoundTagContent.add(boldTag1);
        compoundTagContent.add(simpleTagContent3);
        TagBase italicTag = new ItalicTag();
        italicTag.setContent(compoundTagContent);
        CharSequence c = italicTag.getDisplayText();
        checkSubSpanString(c,0,3,false,true,false,"fla");
        checkSubSpanString(c,3,6,true,true,false,"min");
        checkSubSpanString(c,6,8,false,true,false,"go");
    }

    // <i>fla<h>min</h>go</i>
    @Test
    public void getDisplayTextTest3(){
        ITagContent simpleTagContent1 = new SimpleTagContent("min",9,12);
        ITagContent simpleTagContent2 = new SimpleTagContent("fla",3,6);
        ITagContent simpleTagContent3 = new SimpleTagContent("go",16,18);
        HighlightTag highlightTag = new HighlightTag();
        highlightTag.setContent(simpleTagContent1);
        CompoundTagContent compoundTagContent = new CompoundTagContent();
        compoundTagContent.add(simpleTagContent2);
        compoundTagContent.add(highlightTag);
        compoundTagContent.add(simpleTagContent3);
        TagBase italicTag = new ItalicTag();
        italicTag.setContent(compoundTagContent);
        CharSequence c = italicTag.getDisplayText();
        checkSubSpanString(c,0,3,false,true,false,"fla");
        checkSubSpanString(c,3,6,false,true,true,"min");
        checkSubSpanString(c,6,8,false,true,false,"go");
    }

    // <i><b>fl<h>am</h>in</b>go</i>
    @Test
    public void getDisplayTextTest4(){
        ITagContent simpleTagContent1 = new SimpleTagContent("fl",6,8);
        ITagContent simpleTagContent2 = new SimpleTagContent("am",11,13);
        ITagContent simpleTagContent3 = new SimpleTagContent("in",15,17);
        ITagContent simpleTagContent4 = new SimpleTagContent("go",21,23);
        HighlightTag highlightTag = new HighlightTag();
        highlightTag.setContent(simpleTagContent2);
        CompoundTagContent compoundTagContent1 = new CompoundTagContent();
        compoundTagContent1.add(simpleTagContent1);
        compoundTagContent1.add(highlightTag);
        compoundTagContent1.add(simpleTagContent3);
        TagBase boldTag = new BoldTag();
        boldTag.setContent(compoundTagContent1);
        CompoundTagContent compoundTagContent2 = new CompoundTagContent();
        compoundTagContent2.add(boldTag);
        compoundTagContent2.add(simpleTagContent4);
        TagBase italicTag = new ItalicTag();
        italicTag.setContent(compoundTagContent2);
        CharSequence c = italicTag.getDisplayText();
        SpannableStringBuilder spannableStringBuilder = (SpannableStringBuilder) c;

        for (int i = 0; i < 1; i++){
            StyleSpan styleSpan[] = spannableStringBuilder.getSpans(i,i + 1, StyleSpan.class);
            Log.d("count", String.valueOf(styleSpan[0].getStyle()));}
        checkSubSpanString(c,0,2,true,true,false,"fl");
        checkSubSpanString(c,2,4,true,true,true,"am");
        checkSubSpanString(c,4,6,true,true,false,"in");
        checkSubSpanString(c,6,8,false,true,false,"go");
    }

    // <i><b>flamin</b>go</i>
    @Test
    public void getDisplayTextTest5(){
        ITagContent simpleTagContent1 = new SimpleTagContent("flamin",6,12);
        ITagContent simpleTagContent2 = new SimpleTagContent("go",16,18);
        TagBase boldTag = new BoldTag();
        boldTag.setContent(simpleTagContent1);
        CompoundTagContent compoundTagContent1 = new CompoundTagContent();
        compoundTagContent1.add(boldTag);
        compoundTagContent1.add(simpleTagContent2);
        TagBase italicTag = new ItalicTag();
        italicTag.setContent(compoundTagContent1);
        CharSequence c = italicTag.getDisplayText();
        checkSubSpanString(c,0,6,true,true,false,"flamin");
        checkSubSpanString(c,6,8,false,true,false,"go");
    }

    private void checkSubSpanString(CharSequence displayText, int startIndex, int endIndex, boolean isExpectedBold, boolean isExpectedItalic, boolean isExpectedHighlight, String expectedStringValue){
        SpannableStringBuilder spannableStringBuilder = (SpannableStringBuilder) displayText;

        for (int i = startIndex; i < endIndex; i++){
            StyleSpan styleSpan[] = spannableStringBuilder.getSpans(i,i + 1, StyleSpan.class);
            if (isExpectedBold && isExpectedItalic){
                Assert.assertEquals(styleSpan[0].getStyle() + styleSpan[1].getStyle(), 3);
            } else if (isExpectedBold && !isExpectedItalic) {
                for (int j = 0; j < styleSpan.length; j++){
                    Assert.assertEquals(styleSpan[j].getStyle() , Typeface.BOLD);
                    Assert.assertNotEquals(styleSpan[j].getStyle() , Typeface.ITALIC);
                }
            } else if (!isExpectedBold && isExpectedItalic) {
                for (int j = 0; j < styleSpan.length; j++){
                    Assert.assertEquals(styleSpan[j].getStyle() , Typeface.ITALIC);
                    Assert.assertNotEquals(styleSpan[j].getStyle() , Typeface.BOLD);
                }
            } else Assert.assertEquals(styleSpan.length, 0);

            BackgroundColorSpan backgroundColorSpan[] = spannableStringBuilder.getSpans(i,i + 1, BackgroundColorSpan.class);
            Assert.assertEquals(backgroundColorSpan.length > 0, isExpectedHighlight);
        }
        Assert.assertEquals(displayText.subSequence(startIndex,endIndex).toString(),expectedStringValue);
    }
}
