package com.example.io_test1;

import android.content.Context;
import android.graphics.Typeface;
import android.text.SpannableStringBuilder;
import android.text.style.BackgroundColorSpan;
import android.text.style.StyleSpan;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import com.example.io_test1.CustomXMLParser.Error.DefaultErrorHandler;
import com.example.io_test1.CustomXMLParser.Generated.XMLLexer;
import com.example.io_test1.CustomXMLParser.Generated.XMLParser;
import com.example.io_test1.CustomXMLParser.Tags.ITagContent;
import com.example.io_test1.CustomXMLParser.Tags.TagContentVisitor;
import com.example.io_test1.CustomXMLParser.Tags.Tags.CompoundTagContent;
import com.example.io_test1.CustomXMLParser.Tags.Tags.SimpleTagContent;

import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.Lexer;
import org.antlr.v4.runtime.tree.ParseTree;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;
import java.io.InputStream;


//https://stackoverflow.com/questions/52924431/androidx-test-instrumentationregistry-is-deprecated
//this have to be instrumentation, since data is got from assets
@RunWith(AndroidJUnit4.class)
public class FragmentDisplayTest {
    ITagContent iTagContent1;
    ITagContent iTagContent2;
    ITagContent iTagContent3;
    ITagContent iTagContent4;
    Context ctx;

    @Before public void setUp() throws IOException {
        ctx = InstrumentationRegistry.getInstrumentation().getTargetContext();

        InputStream fileStream1 = ctx.getResources().getAssets().open("testBookVNeseWithBold.txt");
        iTagContent1 = getContentFromInputStream(fileStream1);

        InputStream fileStream2 = ctx.getResources().getAssets().open("testBookJPeseWithItalic.txt");
        iTagContent2 = getContentFromInputStream(fileStream2);

        //can read ../> but cannot read ../<
        InputStream fileStream3 = ctx.getResources().getAssets().open("testBookWithSymbols.txt");
        iTagContent3 = getContentFromInputStream(fileStream3);

        InputStream fileStream4 = ctx.getResources().getAssets().open("testBookOverlapTags.txt");
        iTagContent4 = getContentFromInputStream(fileStream4);
    }

    @Test public void getTextContentFromAssets() throws IOException {

        String text1 = iTagContent1.getText();
        Assert.assertEquals(text1,"con mèo bụng bự");
        Assert.assertNotEquals(text1,"con meo bung bu");

        String text2 = iTagContent2.getText();
        Assert.assertEquals(text2,"あとは時が経つのを待つばかり、ってね");
        Assert.assertNotEquals(text2,"あとは阿蘇にいを待つばかり、ってね");

        String text3 = iTagContent3.getText();
        Assert.assertEquals(text3,"../>");
        Assert.assertNotEquals(text3,"..>");
    }


    //read \n as 2 char
    @Test public void getDisplayTextTest() {

        CharSequence displayText = "";
        if (iTagContent4.getClass() == CompoundTagContent.class){
            displayText = ((CompoundTagContent) iTagContent4).getDisplayText();
        }
        if (iTagContent4.getClass() == SimpleTagContent.class){
            displayText = ((SimpleTagContent) iTagContent4).getDisplayText();
        }
        SpannableStringBuilder spannableStringBuilder = (SpannableStringBuilder) displayText;

        //check spanned style in "Mustard ga"
        checkSubSpanString(displayText,0,10,true,true,false,"Mustard ga");

        //check spanned style in "s"
        checkSubSpanString(displayText,10,11,true,false,false,"s");

        //check spanned style in ", is the prototypical substance of the "
        checkSubSpanString(displayText,13,52,false,false,false,", is the prototypical substance of the ");
        //Log.d("count", (String) iTagContent4.getText().subSequence(11,12));

        //check spanned style in "sulfur-based"
        checkSubSpanString(displayText,52,64,true,false,true,"sulfur-based");

        //check spanned style in " family"
        checkSubSpanString(displayText,64,71,false,false,true," family");

        //check spanned style in "."
        checkSubSpanString(displayText,71,72,false,false,false,".");

    }

    private void checkSubSpanString(CharSequence displayText, int startIndex, int endIndex, boolean isExpectedBold, boolean isExpectedItalic, boolean isExpectedHighlight, String expectedStringValue){
        SpannableStringBuilder spannableStringBuilder = (SpannableStringBuilder) displayText;

        for (int i = startIndex; i < endIndex; i++){
            StyleSpan styleSpan[] = spannableStringBuilder.getSpans(i,i + 1, StyleSpan.class);
            if (isExpectedBold && isExpectedItalic){
                Assert.assertEquals(styleSpan[0].getStyle() + styleSpan[1].getStyle(), 3);
            } else if (isExpectedBold && !isExpectedItalic) {
                for (int j = 0; j < styleSpan.length; j++){
                    Assert.assertEquals(styleSpan[j].getStyle() , Typeface.BOLD);
                    Assert.assertNotEquals(styleSpan[j].getStyle() , Typeface.ITALIC);
                }
            } else if (!isExpectedBold && isExpectedItalic) {
                for (int j = 0; j < styleSpan.length; j++){
                    Assert.assertEquals(styleSpan[j].getStyle() , Typeface.ITALIC);
                    Assert.assertNotEquals(styleSpan[j].getStyle() , Typeface.BOLD);
                }
            } else Assert.assertEquals(styleSpan.length, 0);

            BackgroundColorSpan backgroundColorSpan[] = spannableStringBuilder.getSpans(i,i + 1, BackgroundColorSpan.class);
            Assert.assertEquals(backgroundColorSpan.length > 0, isExpectedHighlight);
        }
        Assert.assertEquals(displayText.subSequence(startIndex,endIndex).toString(),expectedStringValue);
    }

    private ITagContent getContentFromInputStream(InputStream fileStream) throws IOException {
        CharStream charStream = CharStreams.fromStream(fileStream);
        Lexer lexer = new XMLLexer(charStream);
        CommonTokenStream commonTokenStream = new CommonTokenStream(lexer);
        XMLParser parser = new XMLParser(commonTokenStream);
        lexer.removeErrorListeners();
        lexer.addErrorListener(DefaultErrorHandler.INSTANCE);
        parser.removeErrorListeners();
        parser.addErrorListener(DefaultErrorHandler.INSTANCE);
        ParseTree parseTree = parser.document();

        TagContentVisitor tagContentVisitor = new TagContentVisitor();
        ITagContent tagContent = tagContentVisitor.visit(parseTree);

        parser.dumpDFA();
        fileStream.close();

        return tagContent;
    }

}