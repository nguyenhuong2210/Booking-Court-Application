# Documentation

## Diagrams

### Use case diagrams



### Class diagrams



### Sequence diagrams



### Activity diagrams





## Design patterns

### Composite pattern

The book format supported by this application is a hierarchical structure, starting with the tag `<book>`and then consisting of many other tags, which always act as children of some other type and parents of some third or fourth.

With this kind of recursion structure, we use the Composite structure to build a tree structure for syntax content: 

* the leaf class `SimpleTagContent`: represents the content without tags

* the leaf class `TagBase`: each object represents a tag pair, for example `<i>...</i>`

  `TagBase` is extended into other classes, each class represents one type element

* the composite class `CompoundTagContent`

In later on, we can introduce new element types, such as a new type of tag or image, into the app without breaking the existing code, which now works with the object tree. // đúng ko nhỉ vụ thêm tag á, t thấy có tagBase generalize mấy cái tag r mà nhỉ


![alt text](img/E-Reader-composite.png "Tag and Content Structure")



In the real context, there are cases that the tag-pair overlaps with others. We also implement methods for handling this and bring the syntax content into the hierarchical structure

### Visitor
To read all tags of book in the Composite structure, we use Visitor pattern so that we can not only implementing those following tasks but also not modifying the tree structure above by visiting each of the elements of a data structure without the need of having an upfront knowledge on the structure :

* `TagSeparatorVisitor` : to separate `CompoundTagContent` and `SimpleTagContent` and `TagBase`

* `BookLoaderVisitor` : to load and display the book with tags 


![alt text](img/visitor.png "Visitor")


You can use Visitor to execute an operation over an entire Composite tree.

A visitor object can accumulate some useful information while working with various objects. This is quite god for traversing through complex object structure, in this case is the tree of `TagBase` objects, and apply the visitor to each object of this structure.

You can introduce a new behavior that can work with objects of different classes without changing these classes. // Có hông, có thì phân tích ra nah

You can introduce a new behavior that can work with objects of different classes without changing these classes. // Cái này là app 1 lần nên t cũng ko bk sao nữa, nhưng mà chắc đúng trong trường hợp thầy tự nhiên dòi thêm function gì đó

You can use Visitor along with Iterator to traverse a complex data structure and execute some operation over its elements, even if they all have different classes.
Dispite having Iterator pattern, we also use visitor pattern because of its power (nghe kì quá :v). Using an iterator may be less efficient than going through elements by using visitor (đúng hông ta?)

### Factory

To create a desired tags, we use Factory pattern so that we can create a `Tag` object by just only input a name as a string:

`TagCreator` is a class that calls `TagBase` to create the desired tag.


![alt text](img/FactoryPattern.png "Factory")


You avoid tight coupling between the creator and the concrete products. // err, why have to avoid in this case?

Single Responsibility Principle. By moving the product (`TagBase` objects) creation code into one place in the program, the code is easier to support. 

The optimal way to put all the product in one place by using `HashMap<String, TagBase>`. Well, since Hashmap is the fastest way to access the table in O(1).

```Java
private static HashMap<String, TagBase> dict = new HashMap<>();

    static {
        dict.put("book", new BookTag());
        dict.put("chapter", new ChapterTag());
        dict.put("bookmark", new BookmarkTag());
        dict.put("pagebreak", new PagebreakTag());
        dict.put("b", new BoldTag());
        dict.put("i", new ItalicTag());
        dict.put("h", new HighlightTag());
    }
```

Method `CreateTagFrom(String)` is created to pass the input string "Desired Tag" into it then return a `Tag` object
```Java
public static TagBase CreateTagFrom(String tagName) {
        TagBase result = dict.get(tagName);
        if (result != null){
            result = result.shallowCopy();
            result.setContent(null);
        } else {
            result = new SimpleTag(tagName);
        }
        return result;
    }
```

Open/Closed Principle. You can introduce new types of `TagBase` object  into the program without breaking existing client code.

Since we already have `TagBase` subclasses, implementing Factor pattern is not making the code more complicated

### Prototype

`TagBase` is the abstract class for representing tags in book. 




![alt text](img/E-Reader-prototype.png "TagBase")



Methods `clone()` and `shallowCopy()` are created to copy of the `attributes` and the same reference to the `content` of the tags.

* Method `clone()` is used to create `shallowCopy()`

```java
public TagBase shallowCopy()  {
	return (TagBase)clone();
}
```

Below is how `clone()` is defined

```java
@Override
    protected Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }
```



* Method `shallowCopy()` is used in:

  * `closeTag()` method in `TagContentVisitor` class

    `closeTag()` detects and corrects the overlapping tags. 

    For example `<b>test1 <i>test2</b> test3</i>` would be corrected to `<b>test1 <i1>test2</i1></b><i2> test3</i2>`. In this example case, the `TagBase` object `<i>..</i>` is duplicated in method `closeTag()` and is reassigned `content` attribute to point to a new content. 
  
  * `visitChildTags(TagBase tag)` in class `TagHighlightVisitor`     
     `visitChildTags(TagBase tag)` is the main function to build other `visit(<T> t)` methods, with `<T>`type can be `ItalicTag`, `BookmarkTag`, etc.
     
  * `shallowCopy()` in class `SimpleTag`
    
  * `CreateTagFrom(String tagName)`

    // Tại sao mình lại phải clone rồi set content là null, t tưởng new object là null rồi?
    
     The  `shallowCopy()` is used to create the copy of the tag-pair in these cases. 

By using prototypes pattern, `TagBase` object (tag pair) can be created new without knowing the specific type of tag (còn j nữa ko?). Although with some type of Tag or methods, a part of object attributes is reassigned.

The app designs has a heavy use of Composite. Applying Composite pattern lets us clone complex structures instead of re-constructing them from scratch.

We use both Factory pattern and Prototype pattern. By using Prototype, we can easily recreate a clone complex structure, while Factory returns us "empty" objects

### Iterator

Iterator in `BookLoaderVisitor` class provides an easier way for traversing through the collection of `CustomPage`, which represents pages in a book.


```java
public boolean hasNext() {
	return (this.remainingBuffer.length() > 0 || this.nextElementIndex < this.bookElements.size());
}
```
`hasNext()` returns value determine if the next `CustomPage` is available by checking whether any content of the book is has not displayed

```java
public CustomPage next(TextPaint textPaint, int pageWidth, int pageHeight, float spacingMult, float spacingAdd) {
	if (hasNext()){
		//Calculate and return CustomPage that fits with screen with continuing content 
        ...
        
		return new CustomPage<>(appendText);
	} else {return null;}
}
```

From the information about page sizing elements and undisplayed content, `next()` method calculates and return `CustomPage` that fits with screen with continuing styled content.

With each book, we can use `addNextPage()` for checking and getting next page

```java
public boolean addNextPage(){
	if (this.bookLoader.hasNext()){
		addPage(this.bookLoader.next(this.textPaint, this.pageWidth, this.pageHeight, this.spacingMult, this.spacingAdd));
		return true;
	} else {
		return false;
	}
}
```

When rendering the book, `addNextPage()` is called according to the scroll action of user, so that the `CustomPage` object is only created when needed.

It helps to satisfy the Single Responsibility Principle. You can clean up the client code and the collections by extracting bulky traversal algorithms into separate classes. And in this case, by packing the `next()` methods which calculates the next page, the client cde is much cleaner.

Open/Closed Principle. You can implement new types of collections and iterators and pass them to existing code without breaking anything. //có ko ta? t ko bk

You can iterate over the same collection in parallel because each iterator object contains its own iteration state.// có khúc nào mình parallel ko ta?

Since each iterator object contains its own iteration state, you can delay an iteration and continue it when needed. For this reason, `CustomPage` object can be only created when needed.

// Cái iterator của ITagContent là sao z bây, sao t ko thấy?