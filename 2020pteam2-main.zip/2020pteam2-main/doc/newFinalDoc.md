

# Project Report



## Table of content



## Introduction

* Background
* Project Task



## Overview

### 3 layers of reality

<img src="img/3layers.png">



The source text file is only accessed in 2 cases: when user choose to browse it, and when it is chose to be overwrote for file saving.

After the source file is selected, if the file content is match with the restricted book format of the application, source file content will be the input for creating `CustomBook` object, which represents for the book

All operations (viewing content, use table-of-content, use/create/delete bookmarks, (un)highlighting) are took place between user, display layer, and object `CustomBook`. Book source file is not required to be read to execute these operations.

When user request to save book, the raw text that matches with `CustomBook` object is created and overwrote into selected save file



### Use case diagram

<img src="img/E-Reader-Use Cases.png">



## Book replication

### 1. Pages

<img src="img/CustomPage.png" width="400">

**What is "Page"**

`CustomPage`  is used for representing a page object.

`CustomPage` class includes:

* attribute `displayText`: formatted text that can be fit into the text display region
* attribute `sourceSection`: book section that this page belongs to

From the user perspective, a page is the display of `displayText` on `TextView`



**Display page on device**

We use `RecyclerView` to display pages with each page is an item  `TextView` with its `text` is the `displayText` of `CustomPage`.

**[RecyclerView introduction: ]( https://google-developer-training.github.io/android-developer-fundamentals-course-concepts-v2/unit-2-user-experience/lesson-4-user-interaction/4-5-c-recyclerview/4-5-c-recyclerview.html)**
​	A `RecyclerView` uses a limited number of `View` items that are **reused** when they go off-screen. This saves memory and makes it faster to update list items as the user scrolls through data, because it is not necessary to create a new View for every item that appears.
​	In general, the `RecyclerView` keeps as many `View` items as can fit on the screen, plus a few extra at each end of the list to make sure that scrolling is fast and smooth.



**Creating page**

* **Getting size of the page**:

  Androids supports methods for calculating the screen size of the device. 

  From this, we calculate the size of display text region by subtracting the device's size by the size of of other elements in screen. 

  To account for error, the size use in page calculating is slightly smaller than the size of display text region

* **Calculating the Spannable string that can fit into a page**

  We use `StaticLayout` for measuring how big multiline text would be after being laid out. 

  The idea is:
  * try to render spannable string in the static layout with given width

  * try to get the line with highest index but still satisfy condition that the vertical position of the bottom of the that line smaller than the height of the page. Let call this `lastVisibleLine`, and all the lines that from this line above are considered as "visible" lines 

  * get number of char can be display in page by looping though all "visible" line and getting number of char in each lines

```pseudocode
  spannableStringCanBeFit = givenSpannableString.subSequence(0,numberOfCharCanBeDisplay)
  remainSpannableString = givenSpannableString.delete(0,numberOfCharCanBeDisplay)
```

​		The remain spannable string is used to calculating next page

​		The general idea is displaying the content and selecting the fitting part, which means in the case that the current page is not the last page of the chapter, the height of text display in `StaticLayout` should be longer or equal to the page height, otherwise there will be the blank part at the end of the display page. With buffer size 4000, we can ensure ~~this~~ with all types of content, fonts and sizes supported by an e-book reader



The `StaticLayout` will be create with the parameters that affects to the lines counting and the display of the text. These parameters include:

* width of `StaticLayout` (from previous calculating)
* `TextPaint` (depends on text size and text font) used in `StaticLayout`

For this reason, **the `CustomPage` is recreated when**

<img src="img/E-Reader-page reload.png">



**Page Iterator**

Iterator provides an easier way for traversing through the collection of `CustomPage`, which represents pages in a book.

* `hasNext()` returns value determine if the next `CustomPage` is available by checking whether any content of the book is has not displayed

* From the information about page sizing elements and undisplayed content, `next()` method calculates and return `CustomPage` that fits with screen with continuing styled content.

In `CustomBook` object, we can use `addNextPage()` for checking and appending next page to array list `pages` of `CustomBook`



### 2. `CustomBookLabel`

`CustomBookLabel` is created to make it easier to navigate to specified position, like bookmarks or the beginning of chapter. 

It has the attribute `tag`  and attributes `bookSection` and `page` index represent its location inside `CustomBook`



<img src="img/CustomBookLabel.png">



#### Creating `CustomBookLabel`

* From input file

  **Create functional bookmark**

  * When the `CustomBook` is created, `BookmarkTag`is visited by `BookSectioLoaderVisitor` and creates `CustomBookLabel` with `tag` is the current `BookmarkTag` and `atPage` null. 
  * `CustomBookLabel` is added into `bookmarks` list of their `sourceSection` and `bookmarks` list of `CustomBook` keeping `sourceSection`
  * When the `CustomPage`s are created in `BookSection`, `IBookElement`s are visited by `visitTag()` methods in `BookSection`. If the `BookmarkTag` is visited, the `CustomBookLabel` links to that `BookmarkTag` will be set `atPage` with the current creating `CustomPage`

  **Create `CustomBookLabel` for chapter**

  * When the `CustomBook` is created, `ChapterTag`is visited by `BookSectioLoaderVisitor` and creates `CustomBookLabel` with `tag` is the current `ChapterTag` and `atPage` null. 
  * `CustomBookLabel` is added into `booklabels` list of `CustomBook`
  * When the `CustomPage`s are created in `BookChapter`, the first `CustomPage` of `BookChapter` is set for the `CustomBookLabel` representing current chapter

  

* When user request to create bookmark

  **Create functional bookmark**: this will be mentioned in section "Functionalities - 3.2. Adding bookmark"



#### Using `CustomBookLabel`: 

This will be mentioned in section "Functionalities - 2. View and Jump - Table Of Content/ Bookmarks"



### 3. `CustomBook`

<img src="img/CustomBook2.png" width = "450">



`CustomBook` is the object represents for the book.

`IBookElement` objects in the `CustomBook` by themselves can be used to recreate the content of the book source. Beside `IBookElement`s , `CustomBook` also has `CustomBookLabel` and `CustomPage` objects for easier to handle and retrieve data.

#### Steps create `CustomBook` object

* **Step 1:** read source file (if the file is readable)

* **Step 2:** the input string will be handle by `XMLParser` to create a `ParserTree` object corresponding to its content 

* **Step 3:** `ParserTree` object is visited by `TagContentVisitor` to create `ITagContent` objects corresponding to it

* **Step 4:** `ITagContent` objects will be visited by `BookSectionLoaderVisitor`to create `CustomBook` object

  

#### Reading XML-based string

Using library `XMLParser` of Java for handling this task

#### Create `ITagContent` Component Structure

The book format supported by this application is a hierarchical structure, starting with the tag `<book>`and then consisting of many other tags, which always act as children of some other type and parents of some third or fourth.

With this kind of recursion structure, we use the Composite structure to build a tree structure for syntax content: 



<img src="img/ITagContentCompositeUpdate.png" width="900">



* the component interface `ITagContent`

* the leaf class `SimpleTagContent`: represents the content without tags

* the composite/leaf class `TagBase`: each object represents the content with a tag pair

  `TagBase` is extended into other classes, each class represents one type element

  
  
  <img src="img/updateTagBase.png">
  
  


* the composite class `CompoundTagContent`: has sub-`ITagContent`-elements in order

Example 1: 

`<i>abc<b>xyz</b></i>` is an `ItalicTag` object, with `content` attribute is the `CompoundTagContent` of `abc<b>xyz</b>`. 

The `CompoundTagContent` of `abc<b>xyz</b>` has 2 sub elements in order: `SimpleTagContent` of `abc` and `BoldTag` of `<b>xyz</b>`



In the real context, there are cases that the tag-pair overlaps with others. We also implement methods for handling this and bring the syntax content into the hierarchical structure.

**`TagContentVisitor`**

`TagContentVisitor` utilizes the visitor template generated by ANTLR4 to go through the document as `Context` objects and create the appropriate `ITagContent`.

* `DocumentContext`: represents the whole document. When visited returns a `CompoundTagContent` consisting of its children as `ITagContent`, provided they are not null.
* `ChardataContext`: represents the inner most characters inside a tag. Returns a `SimpleTagContent` with the characters, the indices in the document where this starts and ends.
* `SingleTagContext`: represents a tag with only a single tag `<TagName Attribute/>`. Returns a tag with an empty `SimpleTagContent` as its content, the start and end index of which is the same as the end index of this tag.
* `DoubleTagContext`: represents a tag with separate open and close tag, with the content in between them. When visited it will create a new tag on the stack, add its attributes by a `AttributeVisitor` object, visit the `ContentContext`, then attempt to close the tag. Since a tag is only defined generally as `<OpenTagName Attributes> Tag Content </CloseTagName>`, we need to handle cases when the open and close tag are different, violating the hierarchical structure. This error handling occurs in the `closeTag()` method.
* `ContentContext`: represents the tag content. When visited it attempts to add the non-null visit result of its children to the compound tag content on top of the stack. This allows its children to manipulate the stack inside of their visit methods, and change which tag they get added to. Returns `null`.
* `PrologContext`: unused. Returns `null`.
* `ReferenceContext`: unused. Returns `null`.
* `AttributeContext`: represents the tag attribute. This is never processed in this visitor, returns `null` if ever visited.
* `MiscContext`: represents the miscellaneous characters outside of every tag. Returns `null`.

**Handle unhierarchical structure**

`closeTag()` method

The `closeTag` method first checks if the end tag is the same type as the start tag. 

* If they are the same, the method will pop the stacks once and assign the tag content to the tag and return it.
* If they are different, the method will attempt to search through the stack for the correct start tag. It will then add a copy of all the tags before the start tag in the stack with the appropriate tag content to the start tag, then add the start tag to the current compound tag content on top of the stack, and re-add all the other tags to the stack. This effectively ends the start tag with all the overlapping inside it, then open another set of tags without the start tag. If the stack runs out before the correct tag is found, the method will throw an error and stop parsing process.

This may present some ambiguity regarding how the same tag with different attributes should be handled. `<tag attribute="1"> section 1 <tag attribute="2"> section 2 </tag> section 3 </tag>` will be read as `<tag1> section 1 <tag2> section 2 </tag2> section 3 </tag1>`, but it may also be interpreted as `<tag1> section 1 <tag2> section 2 </tag2></tag1><tag2> section 3 </tag2>` by some. It is discouraged to over rely on this error handling system to make decision on how tags should be read.




#### Handle `ITagContents` objects into `CustomBook` object

**`BookSection`**

`ITagContent` objects are enough for representing the content of source book file. However for getting information easier to handle, we binding these objects with appropriate `BookSection` object.



<img src="img/IBookElementUpdate.png">

`CustomBook` represents a whole book, `BookChapter` represents a chapter, and `BookSection` is a general super class for them, represents for a book block.

Since `BookSection` can contains other `BookSection`s and `ITagContent`s, we create an interface `IBookElement` as super interface of `ITagcontent` and `CompoundBookeElement`

`BookSection` is also a `IBookElement` that  contains a part of `CustomBook` to load the book section by section, instead of loading all of the book which consume a lot of time and also handle tags in each section easier.



**`BookSectionLoaderVisitor`**

<img src="img/BookSectionLoaderVisitorV&A.png" width="800">

`BookSectionLoaderVisitor` is created to load book sections. It contains a stack of `BookSection` and when a `BookSection` is loaded every single tag belonged to that section is visited. 

* `BookTag`: When the head of `BookTag` is visited, all child tags (`ChapterTag`,`BookmarkTag`,`BoldTag`, `ItalicTag`, `HighlightTag`, `PagebreakTag`,`FontTag`,`SimpleTagContent`,`CompoundTagContent`, `SimpleTag`) are also visited. When the tail of `BookTag` is visited, it ends to current `BookSection` and load the next `BookSection`
* `ChapterTag`: When the head of `ChapterTag` is visited, all child tags (`BookmarkTag`,`BoldTag`, `ItalicTag`, `HighlightTag`, `PagebreakTag`,`FontTag`,`SimpleTagContent`,`CompoundTagContent`, `SimpleTag`) are also visited. When the tail `ChapterTag` is visited, then it ends to current section and load the next section.   
* `BookmarkTag`: When the  `BookmarkTag` is visited, it adds the `BookmarkTag` as a new `CustomBookLabel`.
* `FontTag`: When the `FontTag` is visited, it sets the size and font for the book.
* `PagebreakTag`: When the `PagebreakTag` is visited, it adds that tag as a new element.



## Functionalities

### 1. Get display text

<img src="img/E-Reader-getDisplayText.png">

We have implemented classes holding the content inside book follows the Composite pattern. So that we can use recursions to get the display text of the book

**`getDisplayText()` method in each class:**

* In `TagBase `  sub-classes:

  * In `BoldTag`, `getDisplayText()` method return char sequence `content` in bold format 
  * In `ItalicTag`, `getDisplayText()` method return char sequence `content` in italic format 
  * In `HiglightTag`, `getDisplayText()` method return char sequence `content` in highlight
  * In other `TagBase` sub-classes,   `getDisplayText()` method return `""`

* In `SimpleTagContent`, `getDisplayText()` returns the simple string `content`

* In `CompoundTagContent`, `getDisplayText()` get the display texts of elements of `contents`, and then append these strings in the correct order. 

* In `CompoundBookElement` , `getDisplayText()` get the display texts of elements of `elements`, and then append these strings in the correct order. 




### 2. View and Jump - Table Of Content/ Bookmarks

**`boolean tryToGetPage(int pageNumber)` method**

This method first calculate the number of page need to be added, then using the for loop to call method for creating next `CustomPages`. The for loop shall breaks if there is no `CustomPage` can be created and will return `false`, otherwise `true`

**`pageJump(int pageNumber)` method**

<img src="img/E-Reader-pageJump.png" width="700">

#### Using/viewing table of content/bookmark list

As mentioned in the section "Book replication - 2. CustomBookLabel", when the `CustomBook` is created, `BookmarkTag`s and `ChapterTag`s are visited



### 3. Adding/removing bookmarks

#### 3.1. What is bookmark

*  Bookmark is also a `CustomBookLabel` which contains  the section and page that  the `BookmarkTag`  belongs  to. 
* `BookmarkTag` is in front of  the text which has the font and size ,when user choose add bookmark on the UI,  at the beginning of the current page.
*  The format of the `BookmarkTag` is `<bookmark>bookmark name</bookmark>`



#### 3.2. Adding bookmarks

##### 3.2.1. What is ''raw position''

Raw start position of char `A` is defined as start position of char `A` in the display spannable string of `sourceSection` that contains char `A` . Respectively with raw end position

Raw start position is stored by attributes `rawStartPos` and can be retrieve/calculate by method `getRawContentStartIndex()`. With raw end position is attributes `rawEndPos` and method `getRawContentEndIndex()` respectively.

We have implemented classes holding the content inside book follows the Composite pattern. So that we can use recursions to find raw positions of `IBookElement` inside book.

##### 3.2.2. `BookElementSplitVisitor` 

<img src="img/BookElementSplitVisitorV&A.png" width="900">

`BookElementSplitVisitor` is created to split `IBookElement` at the given start position and end  position by visiting

* `IBookElement`: If a `IBookElement` is visited, it returns that element. 

* `ITagContent`: If a `ITagContent` is visited, it splits the `ITagContent` at the given position. 

  For example: Split this tag from position into 2 tags: `<b>0123456</b>`

  * Split at 1: return `<b>0</b>` and `<b>123456/b>`
  * Split at 6: return `<b>012345</b>` and `<b>6</b>`

##### 3.2.3. `BookElementInsertVisitor` 

<img src="img/BookElementInsertVisitorV&A.png" width="900">

`BookElementInsertVisitor` is created to insert the given tag before the given position by visiting

* Elements: If a element is visited, it returns that element's `CompoundBookElement`
* Tags: If a tag is visited, it inserts the tag and tag `content` at the given position



##### 3.2.4. Adding bookmark process

<img src="img/E-Reader-addBookmarkAD.png" width="900">



A Facade class `BookmarkAdder` is created to make adding bookmarks more convenient.
**`BookmarkAdder` class** 

Method `bookmarkPage()` get the  current page `CustomPage` and bookmark name, then: 

* Get `rawPosition` = raw position of first character of current page, by method `findRawPos()`. 
* Get element index from `rawPosition`
* Create `CustomBookLabel` by calling method `addBookmark(BookSection sourceSection, CharSequence bookmarkName, int rawPosition, int elementIndex)`:
	* Create a `SimpleTagContent` object with `content` = `bookmarkName` and `rawStartPos` = `rawEndPos` = `rawposition`
	* Create a `BookmarkTag` object with `content` is the created ``SimpleTagContent` 
	* Create new `CustomBookLabel` contains `BookmarkTag`
	* Split other `IBookElement`s at the `rawPostion`  using `BookElementSplitVistior` and insert using `BookElementInsertVistior` the `BookmarkTag`  at that position.
	* At the current `BookSection`and other `BookSection`s cover the current one, add `CustomBookLabel` into their `bookmarks` lists.
	* After adding bookmark, we sort bookmarks in ascending order. The bookmark list is sorted by comparing `getRawContentStartIndex()` of `BookmarkTag` of `CustomBookLabel` in `bookmarks` list
* Set current page for the above `CustomBookLabel` by method `setPage(page)`.



#### 3.3. Removing bookmarks

**`removeBookmark(CustomBookLabel bookmark)` method** in `BookSection`

* the `BookmarkTag` link to that  `CustomBookLabel` (`bookmark.getTag()`) is set attribute `isDeleted` = `true`

* remove `bookmark` from `bookmarks` list of this `BookSection`
* set `parentSection` (`BookSection` that contains directly this `CustomBookLabel`) of `bookmark` into `null` 
* call `removeBookmark(CustomBookLabel bookmark)`  of this outer `BookSection` ( `CustomBook` )

##### Removing bookmark process

When removing the bookmark:

* `CustomBookLabel` will be recursively removed from `bookmarks` list of every  `BookSection` that used to contain it. 
* the `BookmarkTag` links to that  `CustomBookLabel` (`bookmark.getTag()`) is set attribute `isDeleted` = `true`. When saving file, since the `BookmarkTag` is set `isDeleted`, so that the deleted `BookmarkTag` will not be write into file



### 4. Adding/removing highlights

#### 4.1. Introduction

The general idea of this process is going into the `SimpleTagContent` that need to be highlighted/unighlighted, and then set/remove `HighlightTag` point to that `SimpleTagContent`. 

To avoid the duplicate when creating `HighlighTag` (many `HighlighTag` has the same `content`), and make it possible to remove `HighlightTag` , there is a `bolean` stack to determine when to set highlight (when element of stack is `true`) or remove highlight (when element of stack is `false`). Elements in stack are determined by parameter `highlight` from client code (`true` if wanting to set highlights, `false` if wanting to remove highlights), and modified when visiting `HighlightTag`.



`TagHihlightVisitor` and `BookElementVisitor` are created to do these task. If some "splitting" job is required (only a part of `SimplaTagContent` is request to be highlighted), these visitor will handle it.

##### 4.1.1 `TagHighlightVisitor`

<img src="img/TagHighlightVisitorV&A.png" width="900">

`TagHighlightVisitor` is created to traverse through the `ITagContent` Composite Structure to highlight/unhighlight.

* `TagHighlightVisitor` contains position of `highlightStart` and `highlightEnd` , attribute `highlight` (`true` if wanting to set highlights, `false` if wanting to remove highlights) and a `bolean` stack to determine when to set highlight.
* It uses `Iterator` to traverse through `ITagContent` by method `visitTagIterator()`.
  * If the `ITagContent` is visited and belongs to the highlight region then it is added to the stack. After that, it visits `ITagContent`  belonged to that  `ITagContent` and add to the `CompoundTagContent` above. In contrast, there is no `ITagContent` belonged to that `ITagContent`, the `ITagContent` will be popped from the stack.
  * If that `ITagContent`is visited and does not belong to the region that need to be handled, it adds the `ITagContent` to  the `CompoundTagContent`     
  * It returns the `CompoundTagContent`
* When it visits `SimpleTagContent` (content is the plain text), if the stack contains this `SimpleTagContent`, then create new `HighlightTag` and `setContent`  is current `SimpleTagContent`. If not, it just returns that `SimpleTagContent`.
* When it visits `HighlightTag`, this tag will be popped from the stack and add `false` to the stack then visit other tag belonging to current `HighlightTag`.

##### 4.1.2 `BookHighlightVisitor`

<img src="img/BookHighlightVisitorV&A.png" width="900">

`BookHighlightVisitor` uses `TagHighlightVisitor` to highlight the `IBookElement`

* It set the position of starting and ending highlight region of `TagHighlightVisitor` as same as  `BookHighlightVisitor` 
* When it visits `visitCompoundBookElement`, it visits every `IBookElement` belonged to this `CompoundBookElement`. If it visits other `IBookElement`, it returns visiting its `CompoundBookElement`.
* When it visits `ITagContent`, it returns the `ITagContent` as  a `IBookElement` and is highlighted by using `TagHighlightVisitor` .



A Facade `PageHighlighter` class is created to make adding/removing highlights process more convenient

##### 4.1.3 `PageHighlighter`

`PageHighlighter` is created so that user is able to highlight/unhighlight through pages ( `CustomPage` ), even chapters.

* It contains a `Arraylist<>` of pages ( `CustomPage`)  that need to be highlighted/unhighlighted, attribute `highlight` (`true` if wanting to set highlights, `false` if wanting to remove highlights) .
* Method `highlightPage()`:
  * Calculate the raw text positions that need to be handled from the page position 
  * Split every `IBookElement` by visiting it using `IBookElementSplitVisitor` then call `setHighlight(boolean highlight)` using `BookHighlightVisitor`, with `highlight` is determine the request of user (`true` if user asks to highlight, `false` if user asks to unhighlight)

We recall that `CustomPage` object has attributes `tempSelectStart` and `tempSelectEnd` are the `selectionStart`  and `selectionEnd` of that page, so client does not need to pass `selectionStart`  and `selectionEnd` for `PageHighlighter`



#### 4.2 Adding highlights

<img src="img/E-Reader-add highlightAD.png" width="700">



#### 4.3. Removing highlights

This process alike "highlight" process, but it need user to request for "unhighlight", and client code calls `PageHighlighter` with parameter `highlight` = `false`


### 5. Change app orientation

`LayoutManager` `layoutManager` is the attribute of class `FragmentDisplay` being responsible for displaying book content and handle user interaction with these content

When user changes the orientation of the app, `onStop()` is called, which trigger `onCreateView()` to be called again, but the state of `layoutManager` is saved.

* `onCreateView()` responses for calculating device sizes and taking it as input for creating pages for books.

* Scrolling action involves with the call of creating new page. `layoutManager` responses for scrolling action, so that new pages are created, and the action of creating new pages is also checked

So that when `onStop()` called, pages is recalculated and `layoutManager` scroll to the previous page location if applicable, or the end of the book.


### 6. Changing font, size

#### 6.1. `reloadBook()` method

<img src="img/reloadBook.png" width="800">
#### 6.2. Changing font, size process

<img src="img/sizefont.png" width="800">
### 7. Select region of text

The Ebook Reader gives user 2 buttons for selecting first and last character that user wants to select. By implementing this, user is applicable to select the long range of text

### 8. Copy text

It is applicable to copy the text between pages. By knowing start/end page and start/end index of selection, the app calculates selected string, and then copies it into system clipboard

### 9. Current page index display
<img src="img/displayPageIndex.png">

### 10. Page jump
<img src="img/pageJump.png" width="610">

Method `pageJump(int pageNumber)` is mentioned in section "Functionalities - 2. View and Jump - Table Of Content/ Bookmarks"

### 11. Save file
<img src="img/saveFile.png" width="800">


#### Get book raw text

<img src="img/E-Reader-getRawText.png">

We have implemented classes holding the content inside book follows the Composite pattern. So that we can use recursions to get the raw text of the book

**`getRawText()` method in each class:**

* With other `TagBase` classes beside `BookmarkTag`,  `getRawText()` method creates head-tag and tail-tag strings by using `getName()` method, get the raw text of `content`, and then append these char sequences in the correct order. 
* In `BookmarkTag`, if the `isDelete` of the `BookmarkTag` is `true`, then `getRawText()` return `""` string, otherwise it returns the same way as other `TagBase` classes
* In `SimpleTagContent`, `getRawText()` returns the simple char sequence `content`(string without styled)
* In `CompoundTagContent`, `getRawText()` get the raw texts of elements of `contents`, and then append these char sequences in the correct order. 
* In `CompoundBookElement` , `getRawText()` get the raw texts of elements of `elements`, and then append these char sequences in the correct order. 
* In `CustomBook`,  `getRawText()` method get the raw text of other `IBookElement` that it contains directly by calling `super.getRawText()`, and put this char sequence between head-tag `<book>` and tail-tag `</book>` strings.
* In `BookChapter`,  `getRawText()` method get the raw text of other `IBookElement` that it contains directly by calling `super.getRawText()`, and put this char sequence between head-tag `<chapter>` and tail-tag `</chapter>` strings.




## Design Pattern Overview
This part for summarizing design pattern in this project, some of which may be partially mentioned above, and reasons for usage.
### Composite

Composite pattern is used in the way we construct `ITagContent` structure and `IBookElement` structure

* `ITagContent` Composite structure: 

<img src="img/ITagContentCompositeUpdate.png" width="900">

* `IBookElement` Composite structure:

<img src="img/IBookElement CompositeStruct.png" width="500">



<img src="img/IBookElementUpdate.png">

The detail about these class structure is mentioned in section "Book Replication - 2. CustomBookLabel"

**Reasons** for organizing objects follow Composite structure:

* It is "natural" to represent XML based object follow composite structure.
* Be able to use recursions in getting raw text (mentioned in section "Functionalities - 10.Save file - Get book raw text"), getting display text (mentioned in section "Functionalities - 1. Get display text"), and getting raw positions.
* Composite structure goes along with Visitor pattern allows us to handle different types of tag in different ways. 

* In later on, we can introduce new element types, such as a new type of tag or image, into the app without breaking the existing code, which now works with the object tree. 


### Visitor

To read all tags and elements of book in the Composite structure, we use Visitor pattern so that we can not only implementing those following tasks but also not modifying the tree structure above by visiting each of the elements of a data structure without the need of having an upfront knowledge on the structure.

| Class Visitor                 | Usage                                                        |
| ----------------------------- | ------------------------------------------------------------ |
| `ITagVisitor`                 | Interface to traverse through `ITagContent` composite structure |
| `TagVisitorBase`              | Abstract class to traverse through `ITagContent` composite structure which implements `ItagVisitor` |
| `TagHighlightVisitor`         | Extend from `TagVisitorBase` which traverse through `ITagContent` composite structure to highlight every `ITagContent` belongs to highlight region |
| `TagInsertVisitor`            | Extend from `TagVisitorBase` which traverse through `ITagContent` composite structure to insert `ITagContent` before the given position |
| `TagSplitVisitor`             | Extend from `TagVisitorBase` which traverse through `ITagContent` composite structure to split `ITagContent` with multiple nested `ITagContent` into separate `ITagContent` |
| `TagContentSplitVisitor`      | Extend from `TagVisitorBase` which traverse through `ITagContent` composite structure to split `ITagContent` from position into 2 `ITagContent`s |
| `BookSectionLoaderVisitor`    | Extend from `TagVisitorBase` which traverse through `ITagContent` composite structure to load `ITagContent` into `IBookElement` composite structure for each `BookSection`, expect `BookmarkTag` into `CustomBookLabel` |
| `IBookVisitor`                | Interface to traverse through `IBookElement` composite structure |
| `BookHighlightVisitor`        | Traverse through `ITagContent` composite structure and `IBookElement` composite structure to highlight every `ITagContent` in `IBookElement` using `TagHighlightVisitor` |
| `BookElementSplitVisitor`     | Traverse through `ITagContent` composite structure and `IBookElement` composite structure to split every `ITagContent` in `IBookElement` with given start position and end position using `TagContentSplitVisitor` |
| `BookElementTagInsertVisitor` | Traverse through `ITagContent` composite structure and `IBookElement` composite structure to insert a `ITagContent` in `IBookElement` before given  position using `TagInsertVisitor` |



**Diagrams about "Visitors" and "Acceptors" classes**

* `ITagVisitor` 
<p>
    <img src="img/ITagVisitorVisitors.png" width="600">
</p>
<p>
    <em>ITagVisitor Visitors </em>
</p>

* Details:
<p>
	<img src="img/BookElementInsertVisitorV&A.png" width="500">
	<img src="img/BookElementSplitVisitorV&A.png" width="500">
	<img src="img/BookHighlightVisitorV&A.png" width="500">
	<img src="img/BookSectionLoaderVisitorV&A.png" width="500">
	<img src="img/TagContentSplitVisitorV&A.png" width="500">
	<img src="img/TagSplitVisitorV&A.png" width="500">
	<img src="img/TagHighlightVisitorV&A.png" width="500">
	<img src="img/TagInsertVisitorV&A.png" width="500">
</p>
<p>
    <em>ITagVisitor Visitors detail </em>
</p>
<p>
    <img src="img/ITagVisitorAcceptors.png" width="1200">
</p>
<p>
    <em>ITagVisitor Acceptors </em>
</p>

* `IBookVisitor`
<p>
<img src="img/IBookVisitorVisitors.png" width="600"> 
</p>
<p>
    <em>IBookVisitor Visitors </em>
</p>
<p>
<img src="img/IBookVisitorAcceptors.png" width="400" >
</p>
<p>
    <em>IBookVisitor Acceptors </em>
</p>


**Reasons: **

* Visitor is used to execute an operation over an entire Composite tree.

* A visitor object can accumulate some useful information while working with various objects. This is quite god for traversing through complex object structure, in this case is the tree of `IBookElement`objects, `ITagContent` objects, and apply the visitor to each object of this structure.

* Easier to introduce a new behavior that can work with objects of different classes without changing these classes. 

* In some methods, we use Visitor along with Iterator to traverse a complex data structure and execute some operation over its elements



### Factory

To create a desired tags, we use Factory pattern so that we can create a `Tag` object by just only input a name as a string:

`TagCreator` is a class that calls `TagBase` to create the desired tag.

The optimal way to put all the product in one place by using `HashMap<String, TagBase>`, since `HashMap` is the fastest way to access the table in O(1).

```Java
private static HashMap<String, TagBase> dict = new HashMap<>();

    static {
        TagBase tag;
        tag = new BookTag();
        dict.put(tag.getName(), tag);
        tag = new ChapterTag();
        dict.put(tag.getName(), tag);
        tag = new BookmarkTag();
        dict.put(tag.getName(), tag);
        tag = new FontTag();
        dict.put(tag.getName(), tag);
        tag = new BoldTag();
        dict.put(tag.getName(), tag);
        tag = new ItalicTag();
        dict.put(tag.getName(), tag);
        tag = new HighlightTag();
        dict.put(tag.getName(), tag);
        tag = new PagebreakTag();
        dict.put(tag.getName(), tag);
    }
```

Method `CreateTagFrom(String)` is created to pass the input string "Desired Tag" into it then return a `Tag` object

```Java
public static TagBase CreateTagFrom(String tagName) {
        TagBase result = dict.get(tagName);
        if (result != null){
            result = result.shallowCopy();
            result.setContent(null);
        } else {
            result = new SimpleTag(tagName);
        }
        return result;
    }
```

Method `CreateTagFrom(String)` is created to pass the input string "Desired Tag" into it then return a `ITagContent` 



**Reasons:**

* You can introduce new types of `TagBase` object  into the program without breaking existing client code.
* By moving the product (`TagBase` objects) creation code into one place in the program, the code is easier to support. 

Since we already have `TagBase` subclasses, implementing Factor pattern is not making the code more complicated



### Iterator

**List of `Itertor` use in this application:**

* Iterator for getting next `CustomPage` in `BookSection`

Iterator provides an easier way for traversing through the collection of `CustomPage`, which represents pages in a book.

* Iterator for traversing `ITagContent` //TODO

**Reasons:**

* Since each iterator object contains its own iteration state, we can delay an iteration and continue it when needed. For this reason, `CustomPage` object can be only created when needed.



### Prototype

Methods `clone()` and `shallowCopy()` are created to copy of the `attributes` and the same reference to the `content` of the `ITagContent` objects. There are some methods require this duplication, such as method for handling the overlap tag

**Reasons**: 

* By using prototypes pattern, `TagBase` object (tag pair) can be created new without knowing the specific type of tag. Although with some type of Tag or methods, a part of object attributes is reassigned.

* The E-book Reader designs has a heavy use of Composite. Applying Composite pattern lets us clone complex structures instead of re-constructing them from scratch.

We use both Factory pattern and Prototype pattern. By using Prototype, we can easily recreate a clone complex structure, while Factory returns us "empty" objects



### Facade
**List of `Facade` classes use in this application:**

* `BookmarkAdder`

  //pic

  When creating a bookmark, client code calls `BookmarkAdder` with input parameters are current `CustomPage` and name of the bookmark. Details about `BookmarkAdder` usage is mentioned in section "Functionalities - 3.2.4. Adding bookmark process"

* `PageHighlighter`
  //pic

  When setting/removing highlights, client code calls `PageHighlighter` with input parameters are current `CustomPage` and name of the bookmark. Details about `PageHighlighter` usage is mentioned in section "Functionalities - 4.1.3. `PageHighlighter`"

**Reasons**:

* With complex composite structure and visitor system, providing simple interfaces for client to use to do tasks is recommended