# User Manual

## E-book Reader Specification

### Specification for book file

The suggested format for the book file is text file with `.txt` extension.

The structure for the book source file:

```xml
<book>
<font size="size" type="fontname"</font>
    Introduction of the book if available
<chapter>
    Content of chapter 1 is here
</chapter>
<chapter>
    Content of chapter 2 is here
</chapter>
...
<chapter>
    Content of the last chapter
</chapter>
</book>
```

Below is the example source code of the book:

```xml
<book><font size="80.0" type="arial"></font>
<b>THE LITTLE PRINCE</b>
<chapter>
	<b>Chapter 1</b>

	Once when I was six years old I saw a magnificent picture in a book, called <i><b>True Stories from Nature</b></i>, about the primeval forest. It was a picture of a boa constrictor in the act of swallowing an animal. Here is a copy of the drawing.en on

	In the book it said: <i>'Boa constrictors swallow their prey whole, without chewing it. After that they are not able to move, and they sleep through the six months that they need for digestion.'</i>
</chapter>
<chapter>
    <b>Chapter 2</b>
 	<i>'If you please--draw me a sheep!'
	'What!'
	'Draw me a sheep!'</i>

    I jumped to my feet, completely thunderstruck. I <h>blinked my eyes hard</h>. I looked carefully all around me. And I saw a most extraordinary small person, who stood there examining me with great seriousness. Here you may see the best portrait that, later, I was able to make of him. But my drawing is certainly very much less charming than its model.
</chapter>
</book>
```

**Notation about font and size setting of the book:**

* The part `<font...></font>` can be absent from the book source file. 
* If no declaration about font or size is found, the default font and default size will be applied. Default font is Arial and default size is 30.0
* The range of provided size adjustment of the e-book reader is from 30.0 to 80.0. If the setting text size of the book is out that range:
  *  If user has not used the size adjustment of the app, the the size setting in book source still remained, text size use for displaying the content is the size in book source
  *  If user has used the size adjustment of the app, the the size setting in book source would be changed, and in the range from 30.0 to 80.0
* E-book Reader supports 4 fonts: Arial, Montserrat, Garamond, and Raleway. If the setting font of the book is not in that list, the e-book reader will use default font for displaying

**Notation about tags in book source:**

| Tags                                                         | Usage                               |
| ------------------------------------------------------------ | ----------------------------------- |
| `<book>...</book>`                                           | delimiter for a book                |
| `<chapter>...</chapter>`                                     | delimiter for a chapter             |
| `<font size="`<i>size number in float</i>`" type="`<i>font name</i>`"></font>` | delimiter for font and size setting |
| `<b>`<b>content to bold</b>`</b>`                            | delimiter for bold text region      |
| `<i>`<i>content to italic</i>`</i>`                          | delimiter for italic text region    |
| `<h>`<mark>content to high light</mark>`</h>`                | delimiter for highlight text region |
| `<bookmark>`<i>bookmark name</i>`</bookmark>`                | delimiter for bookmark              |

### Specification for Android version

Compatibility: 

* Requires Android 4.1 and up 
* Requires API 16 and up

## E-book Reader Running Guide

### First steps for running the app
* Open the app

* Click into button `BROWSE` for selecting file to read from the device

<img src="usecaseImg/SelectFileToOpen.PNG" width="200">

  * Case 1: The selected file cannot be read or its content is not matching with the recommended book structure

  Error warning message from the application

<img src="usecaseImg/ErrorReadFile.PNG" width="200">

  * Case 2: The file is successfully opened
    
    The content of the book is display

<img src="usecaseImg/DisplayBook.PNG" width="200">

### Introduction to Ultility Menu

Press button `+` to display and hide ultillty menu

<img src="usecaseImg/Toogle1.png" width="200">

<img src="usecaseImg/Toogle2.PNG" width="200">



<img src="usecaseImg/Buttons.png" width="700">

### Table of content

* Click into the chapter spinner for viewing the table of content
* Select chapter to jump to

<img src="usecaseImg/tableOfContent.PNG" alt="alt text" title="Table Of Content" style="zoom:60%;" width="200"/>

### Bookmark list

* Click into the bookmark spinner for viewing the available bookmark list
* Select bookmark to jump to

<img src="usecaseImg/bookmarkList.PNG" width="200">

### Add bookmark

* Click into button `ADD BOOKMARK` to start adding bookmark

Note: the bookmark is created based on your current location inside text

A dialog for entering the title for bookmark shows up

<img src="usecaseImg/addBookmark.PNG" alt="alt text" title="Add bookmark Dialog" style="zoom:60%;" width="200" />

* Press `Cancel` for canceling the creating the bookmark
* Press `Create` without entering the title will create bookmark with name "Unnamed Bookmark" with its relative order among bookmarks. This is not recommended.
* Press `Create` after entering the title will create bookmark with name is the entered text

### Delete bookmark

* Click into button `DELETE BOOKMARK` to start deleting bookmark

A dialog for selecting and deleting bookmark shows up

<img src="usecaseImg/deleteBookmark2.PNG" alt="alt text" title="Delete Bookmark Dialog" style="zoom:60%;" width="200"/>

* Select bookmark to delete from the spinner

<img src="usecaseImg/deleteBookmark1.PNG" alt="alt text" title="Delete Bookmark Spinner" style="zoom:60%;" width="200"/>

* Press `Cancel` for canceling deleting the bookmark
* Press `Delete` to delete selected bookmark. 

<img src="usecaseImg/deleteBookmark3.PNG" alt="alt text" title="Successfully delete th bookmark" style="zoom:60%;" width="200" />

If user has not selected bookmark and the bookmark list is not null, then the first bookmark in the bookmark list will be deleted.

If the bookmark list is null, user cannot see the bookmark list and the `Delete` button does not cause anything.

### Adjust size of text
Adjust the seek bar to adjust the size of the text

### Adjust the font of text
* Click into the font spinner
* Select the wanted font

<img src="usecaseImg/fontSelect.PNG" alt="alt text" title="Font Spinner" style="zoom:100%;" width="200"/>


### Jump to page function
* Click into the `JUMP` button

A dialog for entering the page index that the user wants to jump to shows up

<img src="usecaseImg/JumpDialog.PNG" alt="alt text" title="Jump Dialog" style="zoom:60%;" width="200"/>

* Enter the page index that the user wants to jump into the text box
* Press `Cancel` for canceling the jump request
* Press `Jump` to jump to the intended page.

If user has entered invalid input (null, value is not a number), application will notify user about that error

<img src="usecaseImg/ErrorJump.PNG" alt="alt text" title="Error when entering invalid input" style="zoom:60%;" width="200" />

If user has entered the number bigger than the number of pages in the book, then user will jump to the end of the book

### Highlight the text
* Click button `Select first`
* Click the start position of the text that user wants to highlight
* Click button `Select last`
* Click the end position of the text that user wants to highlight
* Press `Highlight` button to highlight the text
* Press  `Cancel` after finish the highlighting

**Note**: From step 1 to step 4, user can press `Cancel` button to cancel highlight process

### Unhighlight the text
* Click button `Select first`
* Click the start position of the text that user wants to unhighlight
* Click button `Select last`
* Click the end position of the text that user wants to unhighlight
* Press `Unhighlight` button to unhighlight the text
* Press  `Cancel` after finish the unhighlighting

Note: From step 1 to step 4, user can press `Cancel` button to cancel unhighlight process

### Copy the text
* Click button `Select first`
* Click the start position of the text that user wants to copy
* Click button `Select last`
* Click the end position of the text that user wants to copy
* Press `COPY` button to copy the text
* Press  `Cancel` after finish the copying

The text user wants to copy is now in user's clipboard

Note: From step 1 to step 4, user can press `Cancel` button to cancel copy process

### Save file
All the adjustment (bookmarks, highlights, font, size) of user will only be saved if user clicks `Save as`

* Click button `Save as`

Application switches to screen for user to choose the file to overwrite. It is suggested to select the `.txt` file. User can choose the current book file

<img src="usecaseImg/SelectFileToOpen.PNG" alt="alt text" title="Select file to overwrite" style="zoom:60%;" width="200" />

* Choose the file to save into

A dialog to notify whether the file is saved

<img src="usecaseImg/SaveFile2.PNG" alt="alt text" title="Success Message" style="zoom:60%;" width="200"/>

## Errors

* **Error message:** Can't open file. Please re-check the file content

**Reason:** The selected file cannot be read or its content is not matching with the recommended book structure

<img src="usecaseImg/ErrorReadFile.PNG" alt="alt text" title="Error message when selecting file to open" style="zoom:60%;" width="200"/>

* **Error message:** Invalid input

**Reason:** User has entered invalid input (null, values is not a number)

<img src="usecaseImg/ErrorJump.PNG" alt="alt text" title="Error when entering invalid input" style="zoom:60%;" width="200"/>
