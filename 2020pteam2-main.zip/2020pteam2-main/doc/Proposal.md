# Proposal

To:         Manuel Clavel
From:     Team 2
Date:      16 October 2020
Subject:  Proposal for development of a Book Reader for an Android mobile device

The following is in response to your 12 October 2020 requirement that we generate a proposal describing our software engineering project. For our project requirement, we would like to design an application on mobile to read books. The following proposal discusses the schedule and resource estimation, the quality planning, the risk management, and project monitoring plan.


## Schedule and Resource estimation

### Iterative process

#### Iteration 1: Display the hierachical text file in correct format 

**User Story**

* As a user/reader, I want to read book with styled text

**Acceptance tests**

* Successfully read text with tag in hierachical structure
  * Precondition: The text file has content and tags in hierachical structure.
  * Action: User opens the text file
  * Expected result: The text is displayed with styled text corresponding to source file

* Successfully read text with overlapping tags
  * Precondition: The text file has content and tags in hierachical structure or overlapping tags.
  * Action: User opens the text file
  * Expected result: The text is displayed with styled text corresponding to source file

**Constraints**

* Book with image cannot be read

#### Iteration 2: Select the book to read from a library (locally stored in the device) 

**User Story**

* As a user/reader, I want to browse my existing books (books are provided by app publisher) so I can read it

**Acceptance tests**

* Successfully open the book in correct format
  * Precondition: The book is in the correct format.
  * Action: User asks to open the book by selecting that book from the library
  * Expected result: The book is opened and displayed

* Error warning when trying to open the book in wrong format
  * Precondition: The book is in the wrong format.
  * Action: User asks to open the book by selecting that book from the library
  * Expected result: Warning alert dilog appears 

**Constraints**

* Can only read books having restricted format

#### Iteration 3: Select and copy regions of the text

**User Story**

As a user/reader, I want to select and copy regions of the text so that I can take note of that information or search for further information about it on the internet

**Acceptance tests**

* The text can be selected
  * Precondition:
  * Action: User asks to select a region of text by using long clicked into the text field	
  * Expected result: That region of text will be highlighted so that the user will know that part is selected

* The selected text can be coppied
  * Precondition:
  * Action: User selects the text and asks to copy the text
  * Expected result: The text will be copied into the clipboard. It can be tested by trying to paste the content into an editable field

#### Iteration 4: Set/delete highlight in the text

**User Story**

* As a user/reader, I want to hightlight important keywords in the book so that I can effectively review that information later.

**Acceptance tests**

* Successfully create highlight on selected unhighlighted text
  * Precondition: The highlight for wanted text region has not been created
  * Action: Users selecs text and asks to highlight
  * Expected result: The new highlight will be created on seleced text

* Successfully create highlight on selected text overlapping with highlighted text
  * Precondition: The wanted text region has part(s) of it was highlighted
  * Action: Users selecs text and asks to highlight
  * Expected result: 

* The highlights of the book are reserved when app closing
  * Precondition: Some text ares in book are highlighted
  * Action: User closes the app, and reopens it
  * Expected result: Highlighted text areas remain the same

* Successfully unhighlight on selected highlighted text
  * Precondition: The book has highlghted text
  * Action: Users selecs highlighted text and asks to unhighligted
  * Expected result: The seleced text will be unhighlighted

* Successfully unhighlight on selected text that has part(s) of it was unhighlighted
  * Precondition: The wanted text region has part(s) of it was unhighlighted
  * Action: Users selecs highlighted text and asks to unhighligted
  * Expected result: 

#### Iteration 3: Create Page Mod View

**User Story**

As a user/reader, I want to see the books content page by page, each page is fit with the screen of the device (mobile)

**Acceptance tests**

* The text can be selected
  * Precondition: The book is displayed
  * Action: User changes fonts of the text	
  * Expected result: Book content will be correctly displayed on pages: correct selected font and size, no missing or duplicating content, text is uniformly displayed in screen

* The selected text can be coppied
  * Precondition: The book is displayed
  * Action: User changes fonts of the text	
  * Expected result: Book content will be correctly displayed on pages: correct selected font and size, no missing or duplicating content, text is uniformly displayed in screen

#### Iteration 5: Use the “table of contents” to jump to the beginning of each part/chapter.

**User Story**

* As a user/reader, I want to have a quick view of the content of the book by seeing its table of content and jump to the interesting chapter

**Acceptance tests**

* Successfully create table of content corresponding to given source book file
  * Precondition: The source book file with clearly defined chapters by tags `<chapter>` `</chapter>`
  * Action: Users asks to view table of content
  * Expected result: The table of content is match with chapters defined in given source book file

* Successfully move to wanted chapter
  * Precondition:The table of content is match with chapters defined in given source book file
  * Action: User asks to go back/jump to chapter A	
  * Expected result: Users moves to the beginning of chapter A

#### Iteration 6: Set/delete bookmarks in the text, and go back/jump to any bookmark.

**User Story**

* As a user/reader, I want to save my favorite position in the book so that I can easily access it later

**Acceptance tests**

* Successfully create bookmark on selected text
  * Precondition: The bookmark for wanted text region has not been created
  * Action: Users selecs text and asks to create bookmark
  * Expected result: The new bookmark will be created base on the location of seleced text and having the title is selected text

* The bookmarks of the book are reserved when app closing
  * Precondition: Some bookmarks are created
  * Action: User closes the app, and reopens it
  * Expected result: Created bookmarks remain the same

* Successfully delete bookmark from bookmark list
  * Precondition: Some bookmarks are created
  * Action: Users selecs bookmark frm the list and asks to delete it
  * Expected result: That bookmark is deleted from the list

#### Iteration 8: Change the font and size of the text.

**User Story**

* As a user/reader, I want to change the size of the text so that I can easily have a clear look at the text with big size text, or have a quick overview of the book with small size text

**Acceptance tests**

* The font/size of the book is identical in every text/page/chapter
  * Precondition: The book is displayed in font/size A
  * Action:
  * Expected result: All content of the book is in font/size A

* Successfully change the font/size of the book
  * Precondition: The book is displayed in font/size A
  * Action: User changes font/size of the book into B by using function for changing font/size in E-book reader
  * Expected result: All content of the book is in font/size A

* The font and the size of the book are dependent with others
  * Precondition: The book1 and book2 are displayed in font/size A
  * Action: User changes font/size of the book1 into B
  * Expected result: The content of the book2 is in font/size A

* The font/size of the book is reserved when app closing
  * Precondition: The book is displayed in font/size A
  * Action: User closes the app, and reopens it
  * Expected result: All content of the book is still in font/size A

**Constraints**

* The font can be used for changing the font feature is limited. The list of applicable fonts will be updated later.
* The range of text size is limited

### Schedule
**Week 1**

* Iteration 1
* Iteration 2
* Iteration 3

**Week 2**

* Iteration 4
* Iteration 5
* Iteration 6
* Iteration 7

**Week 3**

* Iteration 8

## Quality Planning

### Requirement Scope

The Book Reader of the project allows the user/reader to read and perform simple tasks on books. By using the Book Reader, the user/reader can:

* Select the book to read from a library (locally stored in the device)
* Change the font and size of the text.
* Select and copy regions of the text. 
* Highlight/Unhighlight the text
* Use the “table of contents” to jump to the beginning of each part/chapter.
* Set/delete bookmarks in the text, and go back/jump to any bookmark.
* Bookmarks, font, size, and highlights are specified for each books 
* Having page view that fits to screen of device

To satisfy the initial requirements, the app should be able to:

* Display books with appropriate format to view file the device
* Display the content of the book
* Change the font and size of the text.
* Remember the set font and size, and apply it to the whole app. It means that if the user changes text/font into text/font A when using a book1, when he switches to another book (let says book2) with or without closing the app, the text/font of the book2 is text/font A
* Allow user to select and copy regions of the text. 
* Having the “table of contents”, which allows users to jump to the beginning of each part/chapter.
* Having page view that fits to screen of device. Page is recalculated and displayed after changes in font and size.
* Allow users to create bookmarks, and the created and non-deleted bookmarks should always available even if the book or app is closed. It means that if the user bookmarks a text in a book, closes that book and reopens it, the bookmark is still available. The bookmark can be deleted by user. The deleted bookmarks are not available for viewing and using
* Having a method for storing bookmarks and chapters information.
* Allow users to go back/jump to any bookmark.


### Solution Overview 

* Define the format of the book in the hierachical structure
* Find the way to browse book file on the device and display them on the RecyclerView
* Stored the content and tags of book in appropriate composite structure for processing. Using visitors to visit objects and render the content of the book.
* Create highlight feature from the text, which can be created, deleted by users
  The information of highlght text is stored directly in the source file of the book by using `<h></h>` tag

* Create the “table of contents” to jump to the beginning of each part/chapter.
* Create page view mode
* Create bookmarks feature from the text, which can be created, deleted and used by users
  The information of bookmarks is stored directly in the source file of the book by using `<bookmark></bookmark>` tag

* Create a function to change the font and size of the text.
* Allow the application to use the select/copy function of the Android system

## Risk Management

|Risk description|Probability of Occurrence|Risk Impact|Risk Exposure|Resolution|
|-------------------|-------------------------------|---------|-----------|--------|
|Failure to meet perfectly the requirements|Medium|Medium|Medium|Clarify every requirement before starting programming and members of team test again after finishing that requirement |
|Failure to finish on time|Low|High|Medium|Assign tasks efficiently for each member and schedule plan with exactly deadline and keep track of work|
|Conflict between codes of member|Low|Medium|Low|Use git and always check again code|
|Lack of unit test|Medium|Medium|Medium|Think of every test cases before and note them down|
|Incompatibility with some outdated android versions|Low|Low|Low|Write a restriction about unsuitable android versions before user use it|





## Project monitoring plans
###	1st Week

| Task  | Member                                                       |
| ---- | ------------------------------------------------------------- |
|Discuss and clarify the requirements| Team|
|Write proposal|Lien , Huong |
|Implement classes to browse book from library| Khoi|
|Implement classes to display book as epub/html/xhtml format|Khoi |
|Test all developed functions and fix bugs by making unit testes|Thang|


### 2nd Week 
| Task  | Member                                                       |
| ---- | ------------------------------------------------------------- |
|Implement function to select and copy regions of the text|Khoi |
|Implement classes to create table of contents| Khoi|
|Implement classes to change font and size of the text| Khoi|
|Test all developed functions and fix bugs by making unit testes|Thang|
|Writing documentation|Lien, Huong, Thang|


### 3d Week
| Task  | Member                                                       |
| ---- | ------------------------------------------------------------- |
|Implement function to set and delete bookmarks| Lien|
|Implement friendly user interface|Thang, Lien|
|Implement extra features|Khoi|
|Test all developed functions and fix bugs by making unit testes|Thang|
|Writing documentation|Lien, Huong, Thang|

### 4th Week 
| Task  | Member                                                       |
| ---- | ------------------------------------------------------------- |
|Writing documentation|Lien, Huong, Thang|
|Test all functions of the application and fix bugs by making unit testes|Thang|
|Do internal test the application as end-user|Team|
|Proof read report|Khoi|

